
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model users
 * 
 */
export type users = $Result.DefaultSelection<Prisma.$usersPayload>
/**
 * Model access_permission_group
 * 
 */
export type access_permission_group = $Result.DefaultSelection<Prisma.$access_permission_groupPayload>
/**
 * Model access_permission_group_items
 * 
 */
export type access_permission_group_items = $Result.DefaultSelection<Prisma.$access_permission_group_itemsPayload>
/**
 * Model settings
 * 
 */
export type settings = $Result.DefaultSelection<Prisma.$settingsPayload>
/**
 * Model ipgs
 * 
 */
export type ipgs = $Result.DefaultSelection<Prisma.$ipgsPayload>
/**
 * Model reuqestcodes
 * 
 */
export type reuqestcodes = $Result.DefaultSelection<Prisma.$reuqestcodesPayload>
/**
 * Model baseData
 * 
 */
export type baseData = $Result.DefaultSelection<Prisma.$baseDataPayload>
/**
 * Model members
 * 
 */
export type members = $Result.DefaultSelection<Prisma.$membersPayload>
/**
 * Model members_product_items
 * 
 */
export type members_product_items = $Result.DefaultSelection<Prisma.$members_product_itemsPayload>
/**
 * Model imageSlider
 * 
 */
export type imageSlider = $Result.DefaultSelection<Prisma.$imageSliderPayload>
/**
 * Model profileImageSlider
 * 
 */
export type profileImageSlider = $Result.DefaultSelection<Prisma.$profileImageSliderPayload>
/**
 * Model upload_document_template
 * 
 */
export type upload_document_template = $Result.DefaultSelection<Prisma.$upload_document_templatePayload>
/**
 * Model uploadedDocuments
 * 
 */
export type uploadedDocuments = $Result.DefaultSelection<Prisma.$uploadedDocumentsPayload>
/**
 * Model rejectionTemplates
 * 
 */
export type rejectionTemplates = $Result.DefaultSelection<Prisma.$rejectionTemplatesPayload>
/**
 * Model markets
 * 
 */
export type markets = $Result.DefaultSelection<Prisma.$marketsPayload>
/**
 * Model market_desks
 * 
 */
export type market_desks = $Result.DefaultSelection<Prisma.$market_desksPayload>
/**
 * Model reversed_markets
 * 
 */
export type reversed_markets = $Result.DefaultSelection<Prisma.$reversed_marketsPayload>

/**
 * ##  Prisma Client ʲˢ
 * 
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Users
 * const users = await prisma.users.findMany()
 * ```
 *
 * 
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  T extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  U = 'log' extends keyof T ? T['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<T['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   * 
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Users
   * const users = await prisma.users.findMany()
   * ```
   *
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<T, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): void;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

  /**
   * Add a middleware
   * @deprecated since 4.16.0. For new code, prefer client extensions instead.
   * @see https://pris.ly/d/extensions
   */
  $use(cb: Prisma.Middleware): void

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<'extends', Prisma.TypeMapCb, ExtArgs>

      /**
   * `prisma.users`: Exposes CRUD operations for the **users** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Users
    * const users = await prisma.users.findMany()
    * ```
    */
  get users(): Prisma.usersDelegate<ExtArgs>;

  /**
   * `prisma.access_permission_group`: Exposes CRUD operations for the **access_permission_group** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Access_permission_groups
    * const access_permission_groups = await prisma.access_permission_group.findMany()
    * ```
    */
  get access_permission_group(): Prisma.access_permission_groupDelegate<ExtArgs>;

  /**
   * `prisma.access_permission_group_items`: Exposes CRUD operations for the **access_permission_group_items** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Access_permission_group_items
    * const access_permission_group_items = await prisma.access_permission_group_items.findMany()
    * ```
    */
  get access_permission_group_items(): Prisma.access_permission_group_itemsDelegate<ExtArgs>;

  /**
   * `prisma.settings`: Exposes CRUD operations for the **settings** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Settings
    * const settings = await prisma.settings.findMany()
    * ```
    */
  get settings(): Prisma.settingsDelegate<ExtArgs>;

  /**
   * `prisma.ipgs`: Exposes CRUD operations for the **ipgs** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Ipgs
    * const ipgs = await prisma.ipgs.findMany()
    * ```
    */
  get ipgs(): Prisma.ipgsDelegate<ExtArgs>;

  /**
   * `prisma.reuqestcodes`: Exposes CRUD operations for the **reuqestcodes** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Reuqestcodes
    * const reuqestcodes = await prisma.reuqestcodes.findMany()
    * ```
    */
  get reuqestcodes(): Prisma.reuqestcodesDelegate<ExtArgs>;

  /**
   * `prisma.baseData`: Exposes CRUD operations for the **baseData** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more BaseData
    * const baseData = await prisma.baseData.findMany()
    * ```
    */
  get baseData(): Prisma.baseDataDelegate<ExtArgs>;

  /**
   * `prisma.members`: Exposes CRUD operations for the **members** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Members
    * const members = await prisma.members.findMany()
    * ```
    */
  get members(): Prisma.membersDelegate<ExtArgs>;

  /**
   * `prisma.members_product_items`: Exposes CRUD operations for the **members_product_items** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Members_product_items
    * const members_product_items = await prisma.members_product_items.findMany()
    * ```
    */
  get members_product_items(): Prisma.members_product_itemsDelegate<ExtArgs>;

  /**
   * `prisma.imageSlider`: Exposes CRUD operations for the **imageSlider** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more ImageSliders
    * const imageSliders = await prisma.imageSlider.findMany()
    * ```
    */
  get imageSlider(): Prisma.imageSliderDelegate<ExtArgs>;

  /**
   * `prisma.profileImageSlider`: Exposes CRUD operations for the **profileImageSlider** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more ProfileImageSliders
    * const profileImageSliders = await prisma.profileImageSlider.findMany()
    * ```
    */
  get profileImageSlider(): Prisma.profileImageSliderDelegate<ExtArgs>;

  /**
   * `prisma.upload_document_template`: Exposes CRUD operations for the **upload_document_template** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Upload_document_templates
    * const upload_document_templates = await prisma.upload_document_template.findMany()
    * ```
    */
  get upload_document_template(): Prisma.upload_document_templateDelegate<ExtArgs>;

  /**
   * `prisma.uploadedDocuments`: Exposes CRUD operations for the **uploadedDocuments** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more UploadedDocuments
    * const uploadedDocuments = await prisma.uploadedDocuments.findMany()
    * ```
    */
  get uploadedDocuments(): Prisma.uploadedDocumentsDelegate<ExtArgs>;

  /**
   * `prisma.rejectionTemplates`: Exposes CRUD operations for the **rejectionTemplates** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more RejectionTemplates
    * const rejectionTemplates = await prisma.rejectionTemplates.findMany()
    * ```
    */
  get rejectionTemplates(): Prisma.rejectionTemplatesDelegate<ExtArgs>;

  /**
   * `prisma.markets`: Exposes CRUD operations for the **markets** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Markets
    * const markets = await prisma.markets.findMany()
    * ```
    */
  get markets(): Prisma.marketsDelegate<ExtArgs>;

  /**
   * `prisma.market_desks`: Exposes CRUD operations for the **market_desks** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Market_desks
    * const market_desks = await prisma.market_desks.findMany()
    * ```
    */
  get market_desks(): Prisma.market_desksDelegate<ExtArgs>;

  /**
   * `prisma.reversed_markets`: Exposes CRUD operations for the **reversed_markets** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Reversed_markets
    * const reversed_markets = await prisma.reversed_markets.findMany()
    * ```
    */
  get reversed_markets(): Prisma.reversed_marketsDelegate<ExtArgs>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError
  export import NotFoundError = runtime.NotFoundError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql

  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics 
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 5.15.1
   * Query Engine version: e9771e62de70f79a5e1c604a2d7c8e2a0a874b48
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion 

  /**
   * Utility Types
   */

  /**
   * From https://github.com/sindresorhus/type-fest/
   * Matches a JSON object.
   * This type can be useful to enforce some input to be JSON-compatible or as a super-type to be extended from. 
   */
  export type JsonObject = {[Key in string]?: JsonValue}

  /**
   * From https://github.com/sindresorhus/type-fest/
   * Matches a JSON array.
   */
  export interface JsonArray extends Array<JsonValue> {}

  /**
   * From https://github.com/sindresorhus/type-fest/
   * Matches any valid JSON value.
   */
  export type JsonValue = string | number | boolean | JsonObject | JsonArray | null

  /**
   * Matches a JSON object.
   * Unlike `JsonObject`, this type allows undefined and read-only properties.
   */
  export type InputJsonObject = {readonly [Key in string]?: InputJsonValue | null}

  /**
   * Matches a JSON array.
   * Unlike `JsonArray`, readonly arrays are assignable to this type.
   */
  export interface InputJsonArray extends ReadonlyArray<InputJsonValue | null> {}

  /**
   * Matches any valid value that can be used as an input for operations like
   * create and update as the value of a JSON field. Unlike `JsonValue`, this
   * type allows read-only arrays and read-only object properties and disallows
   * `null` at the top level.
   *
   * `null` cannot be used as the value of a JSON field because its meaning
   * would be ambiguous. Use `Prisma.JsonNull` to store the JSON null value or
   * `Prisma.DbNull` to clear the JSON value and set the field to the database
   * NULL value instead.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-by-null-values
   */
  export type InputJsonValue = string | number | boolean | InputJsonObject | InputJsonArray | { toJSON(): unknown }

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    * 
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    * 
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    * 
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    * 
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    * 
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    * 
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? K : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    users: 'users',
    access_permission_group: 'access_permission_group',
    access_permission_group_items: 'access_permission_group_items',
    settings: 'settings',
    ipgs: 'ipgs',
    reuqestcodes: 'reuqestcodes',
    baseData: 'baseData',
    members: 'members',
    members_product_items: 'members_product_items',
    imageSlider: 'imageSlider',
    profileImageSlider: 'profileImageSlider',
    upload_document_template: 'upload_document_template',
    uploadedDocuments: 'uploadedDocuments',
    rejectionTemplates: 'rejectionTemplates',
    markets: 'markets',
    market_desks: 'market_desks',
    reversed_markets: 'reversed_markets'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }


  interface TypeMapCb extends $Utils.Fn<{extArgs: $Extensions.InternalArgs}, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs']>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    meta: {
      modelProps: 'users' | 'access_permission_group' | 'access_permission_group_items' | 'settings' | 'ipgs' | 'reuqestcodes' | 'baseData' | 'members' | 'members_product_items' | 'imageSlider' | 'profileImageSlider' | 'upload_document_template' | 'uploadedDocuments' | 'rejectionTemplates' | 'markets' | 'market_desks' | 'reversed_markets'
      txIsolationLevel: Prisma.TransactionIsolationLevel
    },
    model: {
      users: {
        payload: Prisma.$usersPayload<ExtArgs>
        fields: Prisma.usersFieldRefs
        operations: {
          findUnique: {
            args: Prisma.usersFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$usersPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.usersFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$usersPayload>
          }
          findFirst: {
            args: Prisma.usersFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$usersPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.usersFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$usersPayload>
          }
          findMany: {
            args: Prisma.usersFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$usersPayload>[]
          }
          create: {
            args: Prisma.usersCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$usersPayload>
          }
          createMany: {
            args: Prisma.usersCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.usersDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$usersPayload>
          }
          update: {
            args: Prisma.usersUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$usersPayload>
          }
          deleteMany: {
            args: Prisma.usersDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.usersUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.usersUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$usersPayload>
          }
          aggregate: {
            args: Prisma.UsersAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateUsers>
          }
          groupBy: {
            args: Prisma.usersGroupByArgs<ExtArgs>,
            result: $Utils.Optional<UsersGroupByOutputType>[]
          }
          count: {
            args: Prisma.usersCountArgs<ExtArgs>,
            result: $Utils.Optional<UsersCountAggregateOutputType> | number
          }
        }
      }
      access_permission_group: {
        payload: Prisma.$access_permission_groupPayload<ExtArgs>
        fields: Prisma.access_permission_groupFieldRefs
        operations: {
          findUnique: {
            args: Prisma.access_permission_groupFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$access_permission_groupPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.access_permission_groupFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$access_permission_groupPayload>
          }
          findFirst: {
            args: Prisma.access_permission_groupFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$access_permission_groupPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.access_permission_groupFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$access_permission_groupPayload>
          }
          findMany: {
            args: Prisma.access_permission_groupFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$access_permission_groupPayload>[]
          }
          create: {
            args: Prisma.access_permission_groupCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$access_permission_groupPayload>
          }
          createMany: {
            args: Prisma.access_permission_groupCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.access_permission_groupDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$access_permission_groupPayload>
          }
          update: {
            args: Prisma.access_permission_groupUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$access_permission_groupPayload>
          }
          deleteMany: {
            args: Prisma.access_permission_groupDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.access_permission_groupUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.access_permission_groupUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$access_permission_groupPayload>
          }
          aggregate: {
            args: Prisma.Access_permission_groupAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateAccess_permission_group>
          }
          groupBy: {
            args: Prisma.access_permission_groupGroupByArgs<ExtArgs>,
            result: $Utils.Optional<Access_permission_groupGroupByOutputType>[]
          }
          count: {
            args: Prisma.access_permission_groupCountArgs<ExtArgs>,
            result: $Utils.Optional<Access_permission_groupCountAggregateOutputType> | number
          }
        }
      }
      access_permission_group_items: {
        payload: Prisma.$access_permission_group_itemsPayload<ExtArgs>
        fields: Prisma.access_permission_group_itemsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.access_permission_group_itemsFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$access_permission_group_itemsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.access_permission_group_itemsFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$access_permission_group_itemsPayload>
          }
          findFirst: {
            args: Prisma.access_permission_group_itemsFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$access_permission_group_itemsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.access_permission_group_itemsFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$access_permission_group_itemsPayload>
          }
          findMany: {
            args: Prisma.access_permission_group_itemsFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$access_permission_group_itemsPayload>[]
          }
          create: {
            args: Prisma.access_permission_group_itemsCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$access_permission_group_itemsPayload>
          }
          createMany: {
            args: Prisma.access_permission_group_itemsCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.access_permission_group_itemsDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$access_permission_group_itemsPayload>
          }
          update: {
            args: Prisma.access_permission_group_itemsUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$access_permission_group_itemsPayload>
          }
          deleteMany: {
            args: Prisma.access_permission_group_itemsDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.access_permission_group_itemsUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.access_permission_group_itemsUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$access_permission_group_itemsPayload>
          }
          aggregate: {
            args: Prisma.Access_permission_group_itemsAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateAccess_permission_group_items>
          }
          groupBy: {
            args: Prisma.access_permission_group_itemsGroupByArgs<ExtArgs>,
            result: $Utils.Optional<Access_permission_group_itemsGroupByOutputType>[]
          }
          count: {
            args: Prisma.access_permission_group_itemsCountArgs<ExtArgs>,
            result: $Utils.Optional<Access_permission_group_itemsCountAggregateOutputType> | number
          }
        }
      }
      settings: {
        payload: Prisma.$settingsPayload<ExtArgs>
        fields: Prisma.settingsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.settingsFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$settingsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.settingsFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$settingsPayload>
          }
          findFirst: {
            args: Prisma.settingsFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$settingsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.settingsFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$settingsPayload>
          }
          findMany: {
            args: Prisma.settingsFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$settingsPayload>[]
          }
          create: {
            args: Prisma.settingsCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$settingsPayload>
          }
          createMany: {
            args: Prisma.settingsCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.settingsDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$settingsPayload>
          }
          update: {
            args: Prisma.settingsUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$settingsPayload>
          }
          deleteMany: {
            args: Prisma.settingsDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.settingsUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.settingsUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$settingsPayload>
          }
          aggregate: {
            args: Prisma.SettingsAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateSettings>
          }
          groupBy: {
            args: Prisma.settingsGroupByArgs<ExtArgs>,
            result: $Utils.Optional<SettingsGroupByOutputType>[]
          }
          count: {
            args: Prisma.settingsCountArgs<ExtArgs>,
            result: $Utils.Optional<SettingsCountAggregateOutputType> | number
          }
        }
      }
      ipgs: {
        payload: Prisma.$ipgsPayload<ExtArgs>
        fields: Prisma.ipgsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ipgsFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ipgsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ipgsFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ipgsPayload>
          }
          findFirst: {
            args: Prisma.ipgsFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ipgsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ipgsFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ipgsPayload>
          }
          findMany: {
            args: Prisma.ipgsFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ipgsPayload>[]
          }
          create: {
            args: Prisma.ipgsCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ipgsPayload>
          }
          createMany: {
            args: Prisma.ipgsCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.ipgsDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ipgsPayload>
          }
          update: {
            args: Prisma.ipgsUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ipgsPayload>
          }
          deleteMany: {
            args: Prisma.ipgsDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.ipgsUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.ipgsUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ipgsPayload>
          }
          aggregate: {
            args: Prisma.IpgsAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateIpgs>
          }
          groupBy: {
            args: Prisma.ipgsGroupByArgs<ExtArgs>,
            result: $Utils.Optional<IpgsGroupByOutputType>[]
          }
          count: {
            args: Prisma.ipgsCountArgs<ExtArgs>,
            result: $Utils.Optional<IpgsCountAggregateOutputType> | number
          }
        }
      }
      reuqestcodes: {
        payload: Prisma.$reuqestcodesPayload<ExtArgs>
        fields: Prisma.reuqestcodesFieldRefs
        operations: {
          findUnique: {
            args: Prisma.reuqestcodesFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$reuqestcodesPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.reuqestcodesFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$reuqestcodesPayload>
          }
          findFirst: {
            args: Prisma.reuqestcodesFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$reuqestcodesPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.reuqestcodesFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$reuqestcodesPayload>
          }
          findMany: {
            args: Prisma.reuqestcodesFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$reuqestcodesPayload>[]
          }
          create: {
            args: Prisma.reuqestcodesCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$reuqestcodesPayload>
          }
          createMany: {
            args: Prisma.reuqestcodesCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.reuqestcodesDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$reuqestcodesPayload>
          }
          update: {
            args: Prisma.reuqestcodesUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$reuqestcodesPayload>
          }
          deleteMany: {
            args: Prisma.reuqestcodesDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.reuqestcodesUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.reuqestcodesUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$reuqestcodesPayload>
          }
          aggregate: {
            args: Prisma.ReuqestcodesAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateReuqestcodes>
          }
          groupBy: {
            args: Prisma.reuqestcodesGroupByArgs<ExtArgs>,
            result: $Utils.Optional<ReuqestcodesGroupByOutputType>[]
          }
          count: {
            args: Prisma.reuqestcodesCountArgs<ExtArgs>,
            result: $Utils.Optional<ReuqestcodesCountAggregateOutputType> | number
          }
        }
      }
      baseData: {
        payload: Prisma.$baseDataPayload<ExtArgs>
        fields: Prisma.baseDataFieldRefs
        operations: {
          findUnique: {
            args: Prisma.baseDataFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$baseDataPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.baseDataFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$baseDataPayload>
          }
          findFirst: {
            args: Prisma.baseDataFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$baseDataPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.baseDataFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$baseDataPayload>
          }
          findMany: {
            args: Prisma.baseDataFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$baseDataPayload>[]
          }
          create: {
            args: Prisma.baseDataCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$baseDataPayload>
          }
          createMany: {
            args: Prisma.baseDataCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.baseDataDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$baseDataPayload>
          }
          update: {
            args: Prisma.baseDataUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$baseDataPayload>
          }
          deleteMany: {
            args: Prisma.baseDataDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.baseDataUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.baseDataUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$baseDataPayload>
          }
          aggregate: {
            args: Prisma.BaseDataAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateBaseData>
          }
          groupBy: {
            args: Prisma.baseDataGroupByArgs<ExtArgs>,
            result: $Utils.Optional<BaseDataGroupByOutputType>[]
          }
          count: {
            args: Prisma.baseDataCountArgs<ExtArgs>,
            result: $Utils.Optional<BaseDataCountAggregateOutputType> | number
          }
        }
      }
      members: {
        payload: Prisma.$membersPayload<ExtArgs>
        fields: Prisma.membersFieldRefs
        operations: {
          findUnique: {
            args: Prisma.membersFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$membersPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.membersFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$membersPayload>
          }
          findFirst: {
            args: Prisma.membersFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$membersPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.membersFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$membersPayload>
          }
          findMany: {
            args: Prisma.membersFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$membersPayload>[]
          }
          create: {
            args: Prisma.membersCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$membersPayload>
          }
          createMany: {
            args: Prisma.membersCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.membersDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$membersPayload>
          }
          update: {
            args: Prisma.membersUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$membersPayload>
          }
          deleteMany: {
            args: Prisma.membersDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.membersUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.membersUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$membersPayload>
          }
          aggregate: {
            args: Prisma.MembersAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateMembers>
          }
          groupBy: {
            args: Prisma.membersGroupByArgs<ExtArgs>,
            result: $Utils.Optional<MembersGroupByOutputType>[]
          }
          count: {
            args: Prisma.membersCountArgs<ExtArgs>,
            result: $Utils.Optional<MembersCountAggregateOutputType> | number
          }
        }
      }
      members_product_items: {
        payload: Prisma.$members_product_itemsPayload<ExtArgs>
        fields: Prisma.members_product_itemsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.members_product_itemsFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$members_product_itemsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.members_product_itemsFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$members_product_itemsPayload>
          }
          findFirst: {
            args: Prisma.members_product_itemsFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$members_product_itemsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.members_product_itemsFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$members_product_itemsPayload>
          }
          findMany: {
            args: Prisma.members_product_itemsFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$members_product_itemsPayload>[]
          }
          create: {
            args: Prisma.members_product_itemsCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$members_product_itemsPayload>
          }
          createMany: {
            args: Prisma.members_product_itemsCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.members_product_itemsDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$members_product_itemsPayload>
          }
          update: {
            args: Prisma.members_product_itemsUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$members_product_itemsPayload>
          }
          deleteMany: {
            args: Prisma.members_product_itemsDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.members_product_itemsUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.members_product_itemsUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$members_product_itemsPayload>
          }
          aggregate: {
            args: Prisma.Members_product_itemsAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateMembers_product_items>
          }
          groupBy: {
            args: Prisma.members_product_itemsGroupByArgs<ExtArgs>,
            result: $Utils.Optional<Members_product_itemsGroupByOutputType>[]
          }
          count: {
            args: Prisma.members_product_itemsCountArgs<ExtArgs>,
            result: $Utils.Optional<Members_product_itemsCountAggregateOutputType> | number
          }
        }
      }
      imageSlider: {
        payload: Prisma.$imageSliderPayload<ExtArgs>
        fields: Prisma.imageSliderFieldRefs
        operations: {
          findUnique: {
            args: Prisma.imageSliderFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$imageSliderPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.imageSliderFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$imageSliderPayload>
          }
          findFirst: {
            args: Prisma.imageSliderFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$imageSliderPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.imageSliderFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$imageSliderPayload>
          }
          findMany: {
            args: Prisma.imageSliderFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$imageSliderPayload>[]
          }
          create: {
            args: Prisma.imageSliderCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$imageSliderPayload>
          }
          createMany: {
            args: Prisma.imageSliderCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.imageSliderDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$imageSliderPayload>
          }
          update: {
            args: Prisma.imageSliderUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$imageSliderPayload>
          }
          deleteMany: {
            args: Prisma.imageSliderDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.imageSliderUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.imageSliderUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$imageSliderPayload>
          }
          aggregate: {
            args: Prisma.ImageSliderAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateImageSlider>
          }
          groupBy: {
            args: Prisma.imageSliderGroupByArgs<ExtArgs>,
            result: $Utils.Optional<ImageSliderGroupByOutputType>[]
          }
          count: {
            args: Prisma.imageSliderCountArgs<ExtArgs>,
            result: $Utils.Optional<ImageSliderCountAggregateOutputType> | number
          }
        }
      }
      profileImageSlider: {
        payload: Prisma.$profileImageSliderPayload<ExtArgs>
        fields: Prisma.profileImageSliderFieldRefs
        operations: {
          findUnique: {
            args: Prisma.profileImageSliderFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$profileImageSliderPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.profileImageSliderFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$profileImageSliderPayload>
          }
          findFirst: {
            args: Prisma.profileImageSliderFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$profileImageSliderPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.profileImageSliderFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$profileImageSliderPayload>
          }
          findMany: {
            args: Prisma.profileImageSliderFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$profileImageSliderPayload>[]
          }
          create: {
            args: Prisma.profileImageSliderCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$profileImageSliderPayload>
          }
          createMany: {
            args: Prisma.profileImageSliderCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.profileImageSliderDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$profileImageSliderPayload>
          }
          update: {
            args: Prisma.profileImageSliderUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$profileImageSliderPayload>
          }
          deleteMany: {
            args: Prisma.profileImageSliderDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.profileImageSliderUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.profileImageSliderUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$profileImageSliderPayload>
          }
          aggregate: {
            args: Prisma.ProfileImageSliderAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateProfileImageSlider>
          }
          groupBy: {
            args: Prisma.profileImageSliderGroupByArgs<ExtArgs>,
            result: $Utils.Optional<ProfileImageSliderGroupByOutputType>[]
          }
          count: {
            args: Prisma.profileImageSliderCountArgs<ExtArgs>,
            result: $Utils.Optional<ProfileImageSliderCountAggregateOutputType> | number
          }
        }
      }
      upload_document_template: {
        payload: Prisma.$upload_document_templatePayload<ExtArgs>
        fields: Prisma.upload_document_templateFieldRefs
        operations: {
          findUnique: {
            args: Prisma.upload_document_templateFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$upload_document_templatePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.upload_document_templateFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$upload_document_templatePayload>
          }
          findFirst: {
            args: Prisma.upload_document_templateFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$upload_document_templatePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.upload_document_templateFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$upload_document_templatePayload>
          }
          findMany: {
            args: Prisma.upload_document_templateFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$upload_document_templatePayload>[]
          }
          create: {
            args: Prisma.upload_document_templateCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$upload_document_templatePayload>
          }
          createMany: {
            args: Prisma.upload_document_templateCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.upload_document_templateDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$upload_document_templatePayload>
          }
          update: {
            args: Prisma.upload_document_templateUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$upload_document_templatePayload>
          }
          deleteMany: {
            args: Prisma.upload_document_templateDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.upload_document_templateUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.upload_document_templateUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$upload_document_templatePayload>
          }
          aggregate: {
            args: Prisma.Upload_document_templateAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateUpload_document_template>
          }
          groupBy: {
            args: Prisma.upload_document_templateGroupByArgs<ExtArgs>,
            result: $Utils.Optional<Upload_document_templateGroupByOutputType>[]
          }
          count: {
            args: Prisma.upload_document_templateCountArgs<ExtArgs>,
            result: $Utils.Optional<Upload_document_templateCountAggregateOutputType> | number
          }
        }
      }
      uploadedDocuments: {
        payload: Prisma.$uploadedDocumentsPayload<ExtArgs>
        fields: Prisma.uploadedDocumentsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.uploadedDocumentsFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$uploadedDocumentsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.uploadedDocumentsFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$uploadedDocumentsPayload>
          }
          findFirst: {
            args: Prisma.uploadedDocumentsFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$uploadedDocumentsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.uploadedDocumentsFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$uploadedDocumentsPayload>
          }
          findMany: {
            args: Prisma.uploadedDocumentsFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$uploadedDocumentsPayload>[]
          }
          create: {
            args: Prisma.uploadedDocumentsCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$uploadedDocumentsPayload>
          }
          createMany: {
            args: Prisma.uploadedDocumentsCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.uploadedDocumentsDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$uploadedDocumentsPayload>
          }
          update: {
            args: Prisma.uploadedDocumentsUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$uploadedDocumentsPayload>
          }
          deleteMany: {
            args: Prisma.uploadedDocumentsDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.uploadedDocumentsUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.uploadedDocumentsUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$uploadedDocumentsPayload>
          }
          aggregate: {
            args: Prisma.UploadedDocumentsAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateUploadedDocuments>
          }
          groupBy: {
            args: Prisma.uploadedDocumentsGroupByArgs<ExtArgs>,
            result: $Utils.Optional<UploadedDocumentsGroupByOutputType>[]
          }
          count: {
            args: Prisma.uploadedDocumentsCountArgs<ExtArgs>,
            result: $Utils.Optional<UploadedDocumentsCountAggregateOutputType> | number
          }
        }
      }
      rejectionTemplates: {
        payload: Prisma.$rejectionTemplatesPayload<ExtArgs>
        fields: Prisma.rejectionTemplatesFieldRefs
        operations: {
          findUnique: {
            args: Prisma.rejectionTemplatesFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$rejectionTemplatesPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.rejectionTemplatesFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$rejectionTemplatesPayload>
          }
          findFirst: {
            args: Prisma.rejectionTemplatesFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$rejectionTemplatesPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.rejectionTemplatesFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$rejectionTemplatesPayload>
          }
          findMany: {
            args: Prisma.rejectionTemplatesFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$rejectionTemplatesPayload>[]
          }
          create: {
            args: Prisma.rejectionTemplatesCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$rejectionTemplatesPayload>
          }
          createMany: {
            args: Prisma.rejectionTemplatesCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.rejectionTemplatesDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$rejectionTemplatesPayload>
          }
          update: {
            args: Prisma.rejectionTemplatesUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$rejectionTemplatesPayload>
          }
          deleteMany: {
            args: Prisma.rejectionTemplatesDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.rejectionTemplatesUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.rejectionTemplatesUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$rejectionTemplatesPayload>
          }
          aggregate: {
            args: Prisma.RejectionTemplatesAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateRejectionTemplates>
          }
          groupBy: {
            args: Prisma.rejectionTemplatesGroupByArgs<ExtArgs>,
            result: $Utils.Optional<RejectionTemplatesGroupByOutputType>[]
          }
          count: {
            args: Prisma.rejectionTemplatesCountArgs<ExtArgs>,
            result: $Utils.Optional<RejectionTemplatesCountAggregateOutputType> | number
          }
        }
      }
      markets: {
        payload: Prisma.$marketsPayload<ExtArgs>
        fields: Prisma.marketsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.marketsFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$marketsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.marketsFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$marketsPayload>
          }
          findFirst: {
            args: Prisma.marketsFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$marketsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.marketsFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$marketsPayload>
          }
          findMany: {
            args: Prisma.marketsFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$marketsPayload>[]
          }
          create: {
            args: Prisma.marketsCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$marketsPayload>
          }
          createMany: {
            args: Prisma.marketsCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.marketsDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$marketsPayload>
          }
          update: {
            args: Prisma.marketsUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$marketsPayload>
          }
          deleteMany: {
            args: Prisma.marketsDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.marketsUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.marketsUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$marketsPayload>
          }
          aggregate: {
            args: Prisma.MarketsAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateMarkets>
          }
          groupBy: {
            args: Prisma.marketsGroupByArgs<ExtArgs>,
            result: $Utils.Optional<MarketsGroupByOutputType>[]
          }
          count: {
            args: Prisma.marketsCountArgs<ExtArgs>,
            result: $Utils.Optional<MarketsCountAggregateOutputType> | number
          }
        }
      }
      market_desks: {
        payload: Prisma.$market_desksPayload<ExtArgs>
        fields: Prisma.market_desksFieldRefs
        operations: {
          findUnique: {
            args: Prisma.market_desksFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$market_desksPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.market_desksFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$market_desksPayload>
          }
          findFirst: {
            args: Prisma.market_desksFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$market_desksPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.market_desksFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$market_desksPayload>
          }
          findMany: {
            args: Prisma.market_desksFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$market_desksPayload>[]
          }
          create: {
            args: Prisma.market_desksCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$market_desksPayload>
          }
          createMany: {
            args: Prisma.market_desksCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.market_desksDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$market_desksPayload>
          }
          update: {
            args: Prisma.market_desksUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$market_desksPayload>
          }
          deleteMany: {
            args: Prisma.market_desksDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.market_desksUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.market_desksUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$market_desksPayload>
          }
          aggregate: {
            args: Prisma.Market_desksAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateMarket_desks>
          }
          groupBy: {
            args: Prisma.market_desksGroupByArgs<ExtArgs>,
            result: $Utils.Optional<Market_desksGroupByOutputType>[]
          }
          count: {
            args: Prisma.market_desksCountArgs<ExtArgs>,
            result: $Utils.Optional<Market_desksCountAggregateOutputType> | number
          }
        }
      }
      reversed_markets: {
        payload: Prisma.$reversed_marketsPayload<ExtArgs>
        fields: Prisma.reversed_marketsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.reversed_marketsFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$reversed_marketsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.reversed_marketsFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$reversed_marketsPayload>
          }
          findFirst: {
            args: Prisma.reversed_marketsFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$reversed_marketsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.reversed_marketsFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$reversed_marketsPayload>
          }
          findMany: {
            args: Prisma.reversed_marketsFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$reversed_marketsPayload>[]
          }
          create: {
            args: Prisma.reversed_marketsCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$reversed_marketsPayload>
          }
          createMany: {
            args: Prisma.reversed_marketsCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.reversed_marketsDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$reversed_marketsPayload>
          }
          update: {
            args: Prisma.reversed_marketsUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$reversed_marketsPayload>
          }
          deleteMany: {
            args: Prisma.reversed_marketsDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.reversed_marketsUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.reversed_marketsUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$reversed_marketsPayload>
          }
          aggregate: {
            args: Prisma.Reversed_marketsAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateReversed_markets>
          }
          groupBy: {
            args: Prisma.reversed_marketsGroupByArgs<ExtArgs>,
            result: $Utils.Optional<Reversed_marketsGroupByOutputType>[]
          }
          count: {
            args: Prisma.reversed_marketsCountArgs<ExtArgs>,
            result: $Utils.Optional<Reversed_marketsCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<'define', Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Defaults to stdout
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events
     * log: [
     *   { emit: 'stdout', level: 'query' },
     *   { emit: 'stdout', level: 'info' },
     *   { emit: 'stdout', level: 'warn' }
     *   { emit: 'stdout', level: 'error' }
     * ]
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type GetLogType<T extends LogLevel | LogDefinition> = T extends LogDefinition ? T['emit'] extends 'event' ? T['level'] : never : never
  export type GetEvents<T extends any> = T extends Array<LogLevel | LogDefinition> ?
    GetLogType<T[0]> | GetLogType<T[1]> | GetLogType<T[2]> | GetLogType<T[3]>
    : never

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  /**
   * These options are being passed into the middleware as "params"
   */
  export type MiddlewareParams = {
    model?: ModelName
    action: PrismaAction
    args: any
    dataPath: string[]
    runInTransaction: boolean
  }

  /**
   * The `T` type makes sure, that the `return proceed` is not forgotten in the middleware implementation
   */
  export type Middleware<T = any> = (
    params: MiddlewareParams,
    next: (params: MiddlewareParams) => $Utils.JsPromise<T>,
  ) => $Utils.JsPromise<T>

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type Access_permission_groupCountOutputType
   */

  export type Access_permission_groupCountOutputType = {
    users: number
  }

  export type Access_permission_groupCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    users?: boolean | Access_permission_groupCountOutputTypeCountUsersArgs
  }

  // Custom InputTypes
  /**
   * Access_permission_groupCountOutputType without action
   */
  export type Access_permission_groupCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Access_permission_groupCountOutputType
     */
    select?: Access_permission_groupCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * Access_permission_groupCountOutputType without action
   */
  export type Access_permission_groupCountOutputTypeCountUsersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: usersWhereInput
  }


  /**
   * Models
   */

  /**
   * Model users
   */

  export type AggregateUsers = {
    _count: UsersCountAggregateOutputType | null
    _min: UsersMinAggregateOutputType | null
    _max: UsersMaxAggregateOutputType | null
  }

  export type UsersMinAggregateOutputType = {
    id: string | null
    username: string | null
    password: string | null
    name: string | null
    family: string | null
    fatherName: string | null
    creationTime: Date | null
    isDeleted: boolean | null
    metaData: string | null
    creatorId: string | null
    accessPermissionGroupId: string | null
  }

  export type UsersMaxAggregateOutputType = {
    id: string | null
    username: string | null
    password: string | null
    name: string | null
    family: string | null
    fatherName: string | null
    creationTime: Date | null
    isDeleted: boolean | null
    metaData: string | null
    creatorId: string | null
    accessPermissionGroupId: string | null
  }

  export type UsersCountAggregateOutputType = {
    id: number
    username: number
    password: number
    name: number
    family: number
    fatherName: number
    creationTime: number
    isDeleted: number
    metaData: number
    creatorId: number
    accessPermissionGroupId: number
    _all: number
  }


  export type UsersMinAggregateInputType = {
    id?: true
    username?: true
    password?: true
    name?: true
    family?: true
    fatherName?: true
    creationTime?: true
    isDeleted?: true
    metaData?: true
    creatorId?: true
    accessPermissionGroupId?: true
  }

  export type UsersMaxAggregateInputType = {
    id?: true
    username?: true
    password?: true
    name?: true
    family?: true
    fatherName?: true
    creationTime?: true
    isDeleted?: true
    metaData?: true
    creatorId?: true
    accessPermissionGroupId?: true
  }

  export type UsersCountAggregateInputType = {
    id?: true
    username?: true
    password?: true
    name?: true
    family?: true
    fatherName?: true
    creationTime?: true
    isDeleted?: true
    metaData?: true
    creatorId?: true
    accessPermissionGroupId?: true
    _all?: true
  }

  export type UsersAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which users to aggregate.
     */
    where?: usersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of users to fetch.
     */
    orderBy?: usersOrderByWithRelationInput | usersOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: usersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned users
    **/
    _count?: true | UsersCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UsersMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UsersMaxAggregateInputType
  }

  export type GetUsersAggregateType<T extends UsersAggregateArgs> = {
        [P in keyof T & keyof AggregateUsers]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUsers[P]>
      : GetScalarType<T[P], AggregateUsers[P]>
  }




  export type usersGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: usersWhereInput
    orderBy?: usersOrderByWithAggregationInput | usersOrderByWithAggregationInput[]
    by: UsersScalarFieldEnum[] | UsersScalarFieldEnum
    having?: usersScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UsersCountAggregateInputType | true
    _min?: UsersMinAggregateInputType
    _max?: UsersMaxAggregateInputType
  }

  export type UsersGroupByOutputType = {
    id: string
    username: string | null
    password: string | null
    name: string | null
    family: string | null
    fatherName: string | null
    creationTime: Date
    isDeleted: boolean
    metaData: string | null
    creatorId: string | null
    accessPermissionGroupId: string
    _count: UsersCountAggregateOutputType | null
    _min: UsersMinAggregateOutputType | null
    _max: UsersMaxAggregateOutputType | null
  }

  type GetUsersGroupByPayload<T extends usersGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UsersGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UsersGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UsersGroupByOutputType[P]>
            : GetScalarType<T[P], UsersGroupByOutputType[P]>
        }
      >
    >


  export type usersSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    username?: boolean
    password?: boolean
    name?: boolean
    family?: boolean
    fatherName?: boolean
    creationTime?: boolean
    isDeleted?: boolean
    metaData?: boolean
    creatorId?: boolean
    accessPermissionGroupId?: boolean
    permissionGroupId?: boolean | users$permissionGroupIdArgs<ExtArgs>
  }, ExtArgs["result"]["users"]>


  export type usersSelectScalar = {
    id?: boolean
    username?: boolean
    password?: boolean
    name?: boolean
    family?: boolean
    fatherName?: boolean
    creationTime?: boolean
    isDeleted?: boolean
    metaData?: boolean
    creatorId?: boolean
    accessPermissionGroupId?: boolean
  }

  export type usersInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    permissionGroupId?: boolean | users$permissionGroupIdArgs<ExtArgs>
  }

  export type $usersPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "users"
    objects: {
      permissionGroupId: Prisma.$access_permission_groupPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      username: string | null
      password: string | null
      name: string | null
      family: string | null
      fatherName: string | null
      creationTime: Date
      isDeleted: boolean
      metaData: string | null
      creatorId: string | null
      accessPermissionGroupId: string
    }, ExtArgs["result"]["users"]>
    composites: {}
  }

  type usersGetPayload<S extends boolean | null | undefined | usersDefaultArgs> = $Result.GetResult<Prisma.$usersPayload, S>

  type usersCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<usersFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: UsersCountAggregateInputType | true
    }

  export interface usersDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['users'], meta: { name: 'users' } }
    /**
     * Find zero or one Users that matches the filter.
     * @param {usersFindUniqueArgs} args - Arguments to find a Users
     * @example
     * // Get one Users
     * const users = await prisma.users.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends usersFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, usersFindUniqueArgs<ExtArgs>>
    ): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one Users that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {usersFindUniqueOrThrowArgs} args - Arguments to find a Users
     * @example
     * // Get one Users
     * const users = await prisma.users.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends usersFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, usersFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usersFindFirstArgs} args - Arguments to find a Users
     * @example
     * // Get one Users
     * const users = await prisma.users.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends usersFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, usersFindFirstArgs<ExtArgs>>
    ): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first Users that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usersFindFirstOrThrowArgs} args - Arguments to find a Users
     * @example
     * // Get one Users
     * const users = await prisma.users.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends usersFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, usersFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usersFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Users
     * const users = await prisma.users.findMany()
     * 
     * // Get first 10 Users
     * const users = await prisma.users.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const usersWithIdOnly = await prisma.users.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends usersFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, usersFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a Users.
     * @param {usersCreateArgs} args - Arguments to create a Users.
     * @example
     * // Create one Users
     * const Users = await prisma.users.create({
     *   data: {
     *     // ... data to create a Users
     *   }
     * })
     * 
    **/
    create<T extends usersCreateArgs<ExtArgs>>(
      args: SelectSubset<T, usersCreateArgs<ExtArgs>>
    ): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many Users.
     * @param {usersCreateManyArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const users = await prisma.users.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
    **/
    createMany<T extends usersCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, usersCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Users.
     * @param {usersDeleteArgs} args - Arguments to delete one Users.
     * @example
     * // Delete one Users
     * const Users = await prisma.users.delete({
     *   where: {
     *     // ... filter to delete one Users
     *   }
     * })
     * 
    **/
    delete<T extends usersDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, usersDeleteArgs<ExtArgs>>
    ): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one Users.
     * @param {usersUpdateArgs} args - Arguments to update one Users.
     * @example
     * // Update one Users
     * const users = await prisma.users.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends usersUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, usersUpdateArgs<ExtArgs>>
    ): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more Users.
     * @param {usersDeleteManyArgs} args - Arguments to filter Users to delete.
     * @example
     * // Delete a few Users
     * const { count } = await prisma.users.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends usersDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, usersDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usersUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Users
     * const users = await prisma.users.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends usersUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, usersUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Users.
     * @param {usersUpsertArgs} args - Arguments to update or create a Users.
     * @example
     * // Update or create a Users
     * const users = await prisma.users.upsert({
     *   create: {
     *     // ... data to create a Users
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Users we want to update
     *   }
     * })
    **/
    upsert<T extends usersUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, usersUpsertArgs<ExtArgs>>
    ): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usersCountArgs} args - Arguments to filter Users to count.
     * @example
     * // Count the number of Users
     * const count = await prisma.users.count({
     *   where: {
     *     // ... the filter for the Users we want to count
     *   }
     * })
    **/
    count<T extends usersCountArgs>(
      args?: Subset<T, usersCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UsersCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UsersAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UsersAggregateArgs>(args: Subset<T, UsersAggregateArgs>): Prisma.PrismaPromise<GetUsersAggregateType<T>>

    /**
     * Group by Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usersGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends usersGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: usersGroupByArgs['orderBy'] }
        : { orderBy?: usersGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, usersGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUsersGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the users model
   */
  readonly fields: usersFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for users.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__usersClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';

    permissionGroupId<T extends users$permissionGroupIdArgs<ExtArgs> = {}>(args?: Subset<T, users$permissionGroupIdArgs<ExtArgs>>): Prisma__access_permission_groupClient<$Result.GetResult<Prisma.$access_permission_groupPayload<ExtArgs>, T, 'findUniqueOrThrow'> | null, null, ExtArgs>;

    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the users model
   */ 
  interface usersFieldRefs {
    readonly id: FieldRef<"users", 'String'>
    readonly username: FieldRef<"users", 'String'>
    readonly password: FieldRef<"users", 'String'>
    readonly name: FieldRef<"users", 'String'>
    readonly family: FieldRef<"users", 'String'>
    readonly fatherName: FieldRef<"users", 'String'>
    readonly creationTime: FieldRef<"users", 'DateTime'>
    readonly isDeleted: FieldRef<"users", 'Boolean'>
    readonly metaData: FieldRef<"users", 'String'>
    readonly creatorId: FieldRef<"users", 'String'>
    readonly accessPermissionGroupId: FieldRef<"users", 'String'>
  }
    

  // Custom InputTypes
  /**
   * users findUnique
   */
  export type usersFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * Filter, which users to fetch.
     */
    where: usersWhereUniqueInput
  }

  /**
   * users findUniqueOrThrow
   */
  export type usersFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * Filter, which users to fetch.
     */
    where: usersWhereUniqueInput
  }

  /**
   * users findFirst
   */
  export type usersFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * Filter, which users to fetch.
     */
    where?: usersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of users to fetch.
     */
    orderBy?: usersOrderByWithRelationInput | usersOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for users.
     */
    cursor?: usersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of users.
     */
    distinct?: UsersScalarFieldEnum | UsersScalarFieldEnum[]
  }

  /**
   * users findFirstOrThrow
   */
  export type usersFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * Filter, which users to fetch.
     */
    where?: usersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of users to fetch.
     */
    orderBy?: usersOrderByWithRelationInput | usersOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for users.
     */
    cursor?: usersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of users.
     */
    distinct?: UsersScalarFieldEnum | UsersScalarFieldEnum[]
  }

  /**
   * users findMany
   */
  export type usersFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * Filter, which users to fetch.
     */
    where?: usersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of users to fetch.
     */
    orderBy?: usersOrderByWithRelationInput | usersOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing users.
     */
    cursor?: usersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` users.
     */
    skip?: number
    distinct?: UsersScalarFieldEnum | UsersScalarFieldEnum[]
  }

  /**
   * users create
   */
  export type usersCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * The data needed to create a users.
     */
    data: XOR<usersCreateInput, usersUncheckedCreateInput>
  }

  /**
   * users createMany
   */
  export type usersCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many users.
     */
    data: usersCreateManyInput | usersCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * users update
   */
  export type usersUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * The data needed to update a users.
     */
    data: XOR<usersUpdateInput, usersUncheckedUpdateInput>
    /**
     * Choose, which users to update.
     */
    where: usersWhereUniqueInput
  }

  /**
   * users updateMany
   */
  export type usersUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update users.
     */
    data: XOR<usersUpdateManyMutationInput, usersUncheckedUpdateManyInput>
    /**
     * Filter which users to update
     */
    where?: usersWhereInput
  }

  /**
   * users upsert
   */
  export type usersUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * The filter to search for the users to update in case it exists.
     */
    where: usersWhereUniqueInput
    /**
     * In case the users found by the `where` argument doesn't exist, create a new users with this data.
     */
    create: XOR<usersCreateInput, usersUncheckedCreateInput>
    /**
     * In case the users was found with the provided `where` argument, update it with this data.
     */
    update: XOR<usersUpdateInput, usersUncheckedUpdateInput>
  }

  /**
   * users delete
   */
  export type usersDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * Filter which users to delete.
     */
    where: usersWhereUniqueInput
  }

  /**
   * users deleteMany
   */
  export type usersDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which users to delete
     */
    where?: usersWhereInput
  }

  /**
   * users.permissionGroupId
   */
  export type users$permissionGroupIdArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group
     */
    select?: access_permission_groupSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: access_permission_groupInclude<ExtArgs> | null
    where?: access_permission_groupWhereInput
  }

  /**
   * users without action
   */
  export type usersDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
  }


  /**
   * Model access_permission_group
   */

  export type AggregateAccess_permission_group = {
    _count: Access_permission_groupCountAggregateOutputType | null
    _min: Access_permission_groupMinAggregateOutputType | null
    _max: Access_permission_groupMaxAggregateOutputType | null
  }

  export type Access_permission_groupMinAggregateOutputType = {
    id: string | null
    title: string | null
    name: string | null
    isDeletable: boolean | null
    createDate: Date | null
  }

  export type Access_permission_groupMaxAggregateOutputType = {
    id: string | null
    title: string | null
    name: string | null
    isDeletable: boolean | null
    createDate: Date | null
  }

  export type Access_permission_groupCountAggregateOutputType = {
    id: number
    title: number
    name: number
    isDeletable: number
    createDate: number
    _all: number
  }


  export type Access_permission_groupMinAggregateInputType = {
    id?: true
    title?: true
    name?: true
    isDeletable?: true
    createDate?: true
  }

  export type Access_permission_groupMaxAggregateInputType = {
    id?: true
    title?: true
    name?: true
    isDeletable?: true
    createDate?: true
  }

  export type Access_permission_groupCountAggregateInputType = {
    id?: true
    title?: true
    name?: true
    isDeletable?: true
    createDate?: true
    _all?: true
  }

  export type Access_permission_groupAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which access_permission_group to aggregate.
     */
    where?: access_permission_groupWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of access_permission_groups to fetch.
     */
    orderBy?: access_permission_groupOrderByWithRelationInput | access_permission_groupOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: access_permission_groupWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` access_permission_groups from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` access_permission_groups.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned access_permission_groups
    **/
    _count?: true | Access_permission_groupCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Access_permission_groupMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Access_permission_groupMaxAggregateInputType
  }

  export type GetAccess_permission_groupAggregateType<T extends Access_permission_groupAggregateArgs> = {
        [P in keyof T & keyof AggregateAccess_permission_group]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAccess_permission_group[P]>
      : GetScalarType<T[P], AggregateAccess_permission_group[P]>
  }




  export type access_permission_groupGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: access_permission_groupWhereInput
    orderBy?: access_permission_groupOrderByWithAggregationInput | access_permission_groupOrderByWithAggregationInput[]
    by: Access_permission_groupScalarFieldEnum[] | Access_permission_groupScalarFieldEnum
    having?: access_permission_groupScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Access_permission_groupCountAggregateInputType | true
    _min?: Access_permission_groupMinAggregateInputType
    _max?: Access_permission_groupMaxAggregateInputType
  }

  export type Access_permission_groupGroupByOutputType = {
    id: string
    title: string | null
    name: string
    isDeletable: boolean
    createDate: Date
    _count: Access_permission_groupCountAggregateOutputType | null
    _min: Access_permission_groupMinAggregateOutputType | null
    _max: Access_permission_groupMaxAggregateOutputType | null
  }

  type GetAccess_permission_groupGroupByPayload<T extends access_permission_groupGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Access_permission_groupGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Access_permission_groupGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Access_permission_groupGroupByOutputType[P]>
            : GetScalarType<T[P], Access_permission_groupGroupByOutputType[P]>
        }
      >
    >


  export type access_permission_groupSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    title?: boolean
    name?: boolean
    isDeletable?: boolean
    createDate?: boolean
    users?: boolean | access_permission_group$usersArgs<ExtArgs>
    _count?: boolean | Access_permission_groupCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["access_permission_group"]>


  export type access_permission_groupSelectScalar = {
    id?: boolean
    title?: boolean
    name?: boolean
    isDeletable?: boolean
    createDate?: boolean
  }

  export type access_permission_groupInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    users?: boolean | access_permission_group$usersArgs<ExtArgs>
    _count?: boolean | Access_permission_groupCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $access_permission_groupPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "access_permission_group"
    objects: {
      users: Prisma.$usersPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      title: string | null
      name: string
      isDeletable: boolean
      createDate: Date
    }, ExtArgs["result"]["access_permission_group"]>
    composites: {}
  }

  type access_permission_groupGetPayload<S extends boolean | null | undefined | access_permission_groupDefaultArgs> = $Result.GetResult<Prisma.$access_permission_groupPayload, S>

  type access_permission_groupCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<access_permission_groupFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: Access_permission_groupCountAggregateInputType | true
    }

  export interface access_permission_groupDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['access_permission_group'], meta: { name: 'access_permission_group' } }
    /**
     * Find zero or one Access_permission_group that matches the filter.
     * @param {access_permission_groupFindUniqueArgs} args - Arguments to find a Access_permission_group
     * @example
     * // Get one Access_permission_group
     * const access_permission_group = await prisma.access_permission_group.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends access_permission_groupFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, access_permission_groupFindUniqueArgs<ExtArgs>>
    ): Prisma__access_permission_groupClient<$Result.GetResult<Prisma.$access_permission_groupPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one Access_permission_group that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {access_permission_groupFindUniqueOrThrowArgs} args - Arguments to find a Access_permission_group
     * @example
     * // Get one Access_permission_group
     * const access_permission_group = await prisma.access_permission_group.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends access_permission_groupFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, access_permission_groupFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__access_permission_groupClient<$Result.GetResult<Prisma.$access_permission_groupPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first Access_permission_group that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {access_permission_groupFindFirstArgs} args - Arguments to find a Access_permission_group
     * @example
     * // Get one Access_permission_group
     * const access_permission_group = await prisma.access_permission_group.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends access_permission_groupFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, access_permission_groupFindFirstArgs<ExtArgs>>
    ): Prisma__access_permission_groupClient<$Result.GetResult<Prisma.$access_permission_groupPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first Access_permission_group that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {access_permission_groupFindFirstOrThrowArgs} args - Arguments to find a Access_permission_group
     * @example
     * // Get one Access_permission_group
     * const access_permission_group = await prisma.access_permission_group.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends access_permission_groupFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, access_permission_groupFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__access_permission_groupClient<$Result.GetResult<Prisma.$access_permission_groupPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more Access_permission_groups that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {access_permission_groupFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Access_permission_groups
     * const access_permission_groups = await prisma.access_permission_group.findMany()
     * 
     * // Get first 10 Access_permission_groups
     * const access_permission_groups = await prisma.access_permission_group.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const access_permission_groupWithIdOnly = await prisma.access_permission_group.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends access_permission_groupFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, access_permission_groupFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$access_permission_groupPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a Access_permission_group.
     * @param {access_permission_groupCreateArgs} args - Arguments to create a Access_permission_group.
     * @example
     * // Create one Access_permission_group
     * const Access_permission_group = await prisma.access_permission_group.create({
     *   data: {
     *     // ... data to create a Access_permission_group
     *   }
     * })
     * 
    **/
    create<T extends access_permission_groupCreateArgs<ExtArgs>>(
      args: SelectSubset<T, access_permission_groupCreateArgs<ExtArgs>>
    ): Prisma__access_permission_groupClient<$Result.GetResult<Prisma.$access_permission_groupPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many Access_permission_groups.
     * @param {access_permission_groupCreateManyArgs} args - Arguments to create many Access_permission_groups.
     * @example
     * // Create many Access_permission_groups
     * const access_permission_group = await prisma.access_permission_group.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
    **/
    createMany<T extends access_permission_groupCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, access_permission_groupCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Access_permission_group.
     * @param {access_permission_groupDeleteArgs} args - Arguments to delete one Access_permission_group.
     * @example
     * // Delete one Access_permission_group
     * const Access_permission_group = await prisma.access_permission_group.delete({
     *   where: {
     *     // ... filter to delete one Access_permission_group
     *   }
     * })
     * 
    **/
    delete<T extends access_permission_groupDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, access_permission_groupDeleteArgs<ExtArgs>>
    ): Prisma__access_permission_groupClient<$Result.GetResult<Prisma.$access_permission_groupPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one Access_permission_group.
     * @param {access_permission_groupUpdateArgs} args - Arguments to update one Access_permission_group.
     * @example
     * // Update one Access_permission_group
     * const access_permission_group = await prisma.access_permission_group.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends access_permission_groupUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, access_permission_groupUpdateArgs<ExtArgs>>
    ): Prisma__access_permission_groupClient<$Result.GetResult<Prisma.$access_permission_groupPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more Access_permission_groups.
     * @param {access_permission_groupDeleteManyArgs} args - Arguments to filter Access_permission_groups to delete.
     * @example
     * // Delete a few Access_permission_groups
     * const { count } = await prisma.access_permission_group.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends access_permission_groupDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, access_permission_groupDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Access_permission_groups.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {access_permission_groupUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Access_permission_groups
     * const access_permission_group = await prisma.access_permission_group.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends access_permission_groupUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, access_permission_groupUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Access_permission_group.
     * @param {access_permission_groupUpsertArgs} args - Arguments to update or create a Access_permission_group.
     * @example
     * // Update or create a Access_permission_group
     * const access_permission_group = await prisma.access_permission_group.upsert({
     *   create: {
     *     // ... data to create a Access_permission_group
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Access_permission_group we want to update
     *   }
     * })
    **/
    upsert<T extends access_permission_groupUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, access_permission_groupUpsertArgs<ExtArgs>>
    ): Prisma__access_permission_groupClient<$Result.GetResult<Prisma.$access_permission_groupPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of Access_permission_groups.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {access_permission_groupCountArgs} args - Arguments to filter Access_permission_groups to count.
     * @example
     * // Count the number of Access_permission_groups
     * const count = await prisma.access_permission_group.count({
     *   where: {
     *     // ... the filter for the Access_permission_groups we want to count
     *   }
     * })
    **/
    count<T extends access_permission_groupCountArgs>(
      args?: Subset<T, access_permission_groupCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Access_permission_groupCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Access_permission_group.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Access_permission_groupAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Access_permission_groupAggregateArgs>(args: Subset<T, Access_permission_groupAggregateArgs>): Prisma.PrismaPromise<GetAccess_permission_groupAggregateType<T>>

    /**
     * Group by Access_permission_group.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {access_permission_groupGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends access_permission_groupGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: access_permission_groupGroupByArgs['orderBy'] }
        : { orderBy?: access_permission_groupGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, access_permission_groupGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAccess_permission_groupGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the access_permission_group model
   */
  readonly fields: access_permission_groupFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for access_permission_group.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__access_permission_groupClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';

    users<T extends access_permission_group$usersArgs<ExtArgs> = {}>(args?: Subset<T, access_permission_group$usersArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, 'findMany'> | Null>;

    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the access_permission_group model
   */ 
  interface access_permission_groupFieldRefs {
    readonly id: FieldRef<"access_permission_group", 'String'>
    readonly title: FieldRef<"access_permission_group", 'String'>
    readonly name: FieldRef<"access_permission_group", 'String'>
    readonly isDeletable: FieldRef<"access_permission_group", 'Boolean'>
    readonly createDate: FieldRef<"access_permission_group", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * access_permission_group findUnique
   */
  export type access_permission_groupFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group
     */
    select?: access_permission_groupSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: access_permission_groupInclude<ExtArgs> | null
    /**
     * Filter, which access_permission_group to fetch.
     */
    where: access_permission_groupWhereUniqueInput
  }

  /**
   * access_permission_group findUniqueOrThrow
   */
  export type access_permission_groupFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group
     */
    select?: access_permission_groupSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: access_permission_groupInclude<ExtArgs> | null
    /**
     * Filter, which access_permission_group to fetch.
     */
    where: access_permission_groupWhereUniqueInput
  }

  /**
   * access_permission_group findFirst
   */
  export type access_permission_groupFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group
     */
    select?: access_permission_groupSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: access_permission_groupInclude<ExtArgs> | null
    /**
     * Filter, which access_permission_group to fetch.
     */
    where?: access_permission_groupWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of access_permission_groups to fetch.
     */
    orderBy?: access_permission_groupOrderByWithRelationInput | access_permission_groupOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for access_permission_groups.
     */
    cursor?: access_permission_groupWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` access_permission_groups from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` access_permission_groups.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of access_permission_groups.
     */
    distinct?: Access_permission_groupScalarFieldEnum | Access_permission_groupScalarFieldEnum[]
  }

  /**
   * access_permission_group findFirstOrThrow
   */
  export type access_permission_groupFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group
     */
    select?: access_permission_groupSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: access_permission_groupInclude<ExtArgs> | null
    /**
     * Filter, which access_permission_group to fetch.
     */
    where?: access_permission_groupWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of access_permission_groups to fetch.
     */
    orderBy?: access_permission_groupOrderByWithRelationInput | access_permission_groupOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for access_permission_groups.
     */
    cursor?: access_permission_groupWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` access_permission_groups from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` access_permission_groups.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of access_permission_groups.
     */
    distinct?: Access_permission_groupScalarFieldEnum | Access_permission_groupScalarFieldEnum[]
  }

  /**
   * access_permission_group findMany
   */
  export type access_permission_groupFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group
     */
    select?: access_permission_groupSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: access_permission_groupInclude<ExtArgs> | null
    /**
     * Filter, which access_permission_groups to fetch.
     */
    where?: access_permission_groupWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of access_permission_groups to fetch.
     */
    orderBy?: access_permission_groupOrderByWithRelationInput | access_permission_groupOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing access_permission_groups.
     */
    cursor?: access_permission_groupWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` access_permission_groups from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` access_permission_groups.
     */
    skip?: number
    distinct?: Access_permission_groupScalarFieldEnum | Access_permission_groupScalarFieldEnum[]
  }

  /**
   * access_permission_group create
   */
  export type access_permission_groupCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group
     */
    select?: access_permission_groupSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: access_permission_groupInclude<ExtArgs> | null
    /**
     * The data needed to create a access_permission_group.
     */
    data: XOR<access_permission_groupCreateInput, access_permission_groupUncheckedCreateInput>
  }

  /**
   * access_permission_group createMany
   */
  export type access_permission_groupCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many access_permission_groups.
     */
    data: access_permission_groupCreateManyInput | access_permission_groupCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * access_permission_group update
   */
  export type access_permission_groupUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group
     */
    select?: access_permission_groupSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: access_permission_groupInclude<ExtArgs> | null
    /**
     * The data needed to update a access_permission_group.
     */
    data: XOR<access_permission_groupUpdateInput, access_permission_groupUncheckedUpdateInput>
    /**
     * Choose, which access_permission_group to update.
     */
    where: access_permission_groupWhereUniqueInput
  }

  /**
   * access_permission_group updateMany
   */
  export type access_permission_groupUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update access_permission_groups.
     */
    data: XOR<access_permission_groupUpdateManyMutationInput, access_permission_groupUncheckedUpdateManyInput>
    /**
     * Filter which access_permission_groups to update
     */
    where?: access_permission_groupWhereInput
  }

  /**
   * access_permission_group upsert
   */
  export type access_permission_groupUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group
     */
    select?: access_permission_groupSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: access_permission_groupInclude<ExtArgs> | null
    /**
     * The filter to search for the access_permission_group to update in case it exists.
     */
    where: access_permission_groupWhereUniqueInput
    /**
     * In case the access_permission_group found by the `where` argument doesn't exist, create a new access_permission_group with this data.
     */
    create: XOR<access_permission_groupCreateInput, access_permission_groupUncheckedCreateInput>
    /**
     * In case the access_permission_group was found with the provided `where` argument, update it with this data.
     */
    update: XOR<access_permission_groupUpdateInput, access_permission_groupUncheckedUpdateInput>
  }

  /**
   * access_permission_group delete
   */
  export type access_permission_groupDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group
     */
    select?: access_permission_groupSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: access_permission_groupInclude<ExtArgs> | null
    /**
     * Filter which access_permission_group to delete.
     */
    where: access_permission_groupWhereUniqueInput
  }

  /**
   * access_permission_group deleteMany
   */
  export type access_permission_groupDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which access_permission_groups to delete
     */
    where?: access_permission_groupWhereInput
  }

  /**
   * access_permission_group.users
   */
  export type access_permission_group$usersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    where?: usersWhereInput
    orderBy?: usersOrderByWithRelationInput | usersOrderByWithRelationInput[]
    cursor?: usersWhereUniqueInput
    take?: number
    skip?: number
    distinct?: UsersScalarFieldEnum | UsersScalarFieldEnum[]
  }

  /**
   * access_permission_group without action
   */
  export type access_permission_groupDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group
     */
    select?: access_permission_groupSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: access_permission_groupInclude<ExtArgs> | null
  }


  /**
   * Model access_permission_group_items
   */

  export type AggregateAccess_permission_group_items = {
    _count: Access_permission_group_itemsCountAggregateOutputType | null
    _min: Access_permission_group_itemsMinAggregateOutputType | null
    _max: Access_permission_group_itemsMaxAggregateOutputType | null
  }

  export type Access_permission_group_itemsMinAggregateOutputType = {
    id: string | null
    userOrParentAccessPermissionId: string | null
    providerKey: string | null
    creatorId: string | null
    createDate: Date | null
  }

  export type Access_permission_group_itemsMaxAggregateOutputType = {
    id: string | null
    userOrParentAccessPermissionId: string | null
    providerKey: string | null
    creatorId: string | null
    createDate: Date | null
  }

  export type Access_permission_group_itemsCountAggregateOutputType = {
    id: number
    userOrParentAccessPermissionId: number
    providerKey: number
    creatorId: number
    createDate: number
    _all: number
  }


  export type Access_permission_group_itemsMinAggregateInputType = {
    id?: true
    userOrParentAccessPermissionId?: true
    providerKey?: true
    creatorId?: true
    createDate?: true
  }

  export type Access_permission_group_itemsMaxAggregateInputType = {
    id?: true
    userOrParentAccessPermissionId?: true
    providerKey?: true
    creatorId?: true
    createDate?: true
  }

  export type Access_permission_group_itemsCountAggregateInputType = {
    id?: true
    userOrParentAccessPermissionId?: true
    providerKey?: true
    creatorId?: true
    createDate?: true
    _all?: true
  }

  export type Access_permission_group_itemsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which access_permission_group_items to aggregate.
     */
    where?: access_permission_group_itemsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of access_permission_group_items to fetch.
     */
    orderBy?: access_permission_group_itemsOrderByWithRelationInput | access_permission_group_itemsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: access_permission_group_itemsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` access_permission_group_items from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` access_permission_group_items.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned access_permission_group_items
    **/
    _count?: true | Access_permission_group_itemsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Access_permission_group_itemsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Access_permission_group_itemsMaxAggregateInputType
  }

  export type GetAccess_permission_group_itemsAggregateType<T extends Access_permission_group_itemsAggregateArgs> = {
        [P in keyof T & keyof AggregateAccess_permission_group_items]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAccess_permission_group_items[P]>
      : GetScalarType<T[P], AggregateAccess_permission_group_items[P]>
  }




  export type access_permission_group_itemsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: access_permission_group_itemsWhereInput
    orderBy?: access_permission_group_itemsOrderByWithAggregationInput | access_permission_group_itemsOrderByWithAggregationInput[]
    by: Access_permission_group_itemsScalarFieldEnum[] | Access_permission_group_itemsScalarFieldEnum
    having?: access_permission_group_itemsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Access_permission_group_itemsCountAggregateInputType | true
    _min?: Access_permission_group_itemsMinAggregateInputType
    _max?: Access_permission_group_itemsMaxAggregateInputType
  }

  export type Access_permission_group_itemsGroupByOutputType = {
    id: string
    userOrParentAccessPermissionId: string | null
    providerKey: string
    creatorId: string | null
    createDate: Date
    _count: Access_permission_group_itemsCountAggregateOutputType | null
    _min: Access_permission_group_itemsMinAggregateOutputType | null
    _max: Access_permission_group_itemsMaxAggregateOutputType | null
  }

  type GetAccess_permission_group_itemsGroupByPayload<T extends access_permission_group_itemsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Access_permission_group_itemsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Access_permission_group_itemsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Access_permission_group_itemsGroupByOutputType[P]>
            : GetScalarType<T[P], Access_permission_group_itemsGroupByOutputType[P]>
        }
      >
    >


  export type access_permission_group_itemsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userOrParentAccessPermissionId?: boolean
    providerKey?: boolean
    creatorId?: boolean
    createDate?: boolean
  }, ExtArgs["result"]["access_permission_group_items"]>


  export type access_permission_group_itemsSelectScalar = {
    id?: boolean
    userOrParentAccessPermissionId?: boolean
    providerKey?: boolean
    creatorId?: boolean
    createDate?: boolean
  }


  export type $access_permission_group_itemsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "access_permission_group_items"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      userOrParentAccessPermissionId: string | null
      providerKey: string
      creatorId: string | null
      createDate: Date
    }, ExtArgs["result"]["access_permission_group_items"]>
    composites: {}
  }

  type access_permission_group_itemsGetPayload<S extends boolean | null | undefined | access_permission_group_itemsDefaultArgs> = $Result.GetResult<Prisma.$access_permission_group_itemsPayload, S>

  type access_permission_group_itemsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<access_permission_group_itemsFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: Access_permission_group_itemsCountAggregateInputType | true
    }

  export interface access_permission_group_itemsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['access_permission_group_items'], meta: { name: 'access_permission_group_items' } }
    /**
     * Find zero or one Access_permission_group_items that matches the filter.
     * @param {access_permission_group_itemsFindUniqueArgs} args - Arguments to find a Access_permission_group_items
     * @example
     * // Get one Access_permission_group_items
     * const access_permission_group_items = await prisma.access_permission_group_items.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends access_permission_group_itemsFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, access_permission_group_itemsFindUniqueArgs<ExtArgs>>
    ): Prisma__access_permission_group_itemsClient<$Result.GetResult<Prisma.$access_permission_group_itemsPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one Access_permission_group_items that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {access_permission_group_itemsFindUniqueOrThrowArgs} args - Arguments to find a Access_permission_group_items
     * @example
     * // Get one Access_permission_group_items
     * const access_permission_group_items = await prisma.access_permission_group_items.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends access_permission_group_itemsFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, access_permission_group_itemsFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__access_permission_group_itemsClient<$Result.GetResult<Prisma.$access_permission_group_itemsPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first Access_permission_group_items that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {access_permission_group_itemsFindFirstArgs} args - Arguments to find a Access_permission_group_items
     * @example
     * // Get one Access_permission_group_items
     * const access_permission_group_items = await prisma.access_permission_group_items.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends access_permission_group_itemsFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, access_permission_group_itemsFindFirstArgs<ExtArgs>>
    ): Prisma__access_permission_group_itemsClient<$Result.GetResult<Prisma.$access_permission_group_itemsPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first Access_permission_group_items that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {access_permission_group_itemsFindFirstOrThrowArgs} args - Arguments to find a Access_permission_group_items
     * @example
     * // Get one Access_permission_group_items
     * const access_permission_group_items = await prisma.access_permission_group_items.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends access_permission_group_itemsFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, access_permission_group_itemsFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__access_permission_group_itemsClient<$Result.GetResult<Prisma.$access_permission_group_itemsPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more Access_permission_group_items that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {access_permission_group_itemsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Access_permission_group_items
     * const access_permission_group_items = await prisma.access_permission_group_items.findMany()
     * 
     * // Get first 10 Access_permission_group_items
     * const access_permission_group_items = await prisma.access_permission_group_items.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const access_permission_group_itemsWithIdOnly = await prisma.access_permission_group_items.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends access_permission_group_itemsFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, access_permission_group_itemsFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$access_permission_group_itemsPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a Access_permission_group_items.
     * @param {access_permission_group_itemsCreateArgs} args - Arguments to create a Access_permission_group_items.
     * @example
     * // Create one Access_permission_group_items
     * const Access_permission_group_items = await prisma.access_permission_group_items.create({
     *   data: {
     *     // ... data to create a Access_permission_group_items
     *   }
     * })
     * 
    **/
    create<T extends access_permission_group_itemsCreateArgs<ExtArgs>>(
      args: SelectSubset<T, access_permission_group_itemsCreateArgs<ExtArgs>>
    ): Prisma__access_permission_group_itemsClient<$Result.GetResult<Prisma.$access_permission_group_itemsPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many Access_permission_group_items.
     * @param {access_permission_group_itemsCreateManyArgs} args - Arguments to create many Access_permission_group_items.
     * @example
     * // Create many Access_permission_group_items
     * const access_permission_group_items = await prisma.access_permission_group_items.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
    **/
    createMany<T extends access_permission_group_itemsCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, access_permission_group_itemsCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Access_permission_group_items.
     * @param {access_permission_group_itemsDeleteArgs} args - Arguments to delete one Access_permission_group_items.
     * @example
     * // Delete one Access_permission_group_items
     * const Access_permission_group_items = await prisma.access_permission_group_items.delete({
     *   where: {
     *     // ... filter to delete one Access_permission_group_items
     *   }
     * })
     * 
    **/
    delete<T extends access_permission_group_itemsDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, access_permission_group_itemsDeleteArgs<ExtArgs>>
    ): Prisma__access_permission_group_itemsClient<$Result.GetResult<Prisma.$access_permission_group_itemsPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one Access_permission_group_items.
     * @param {access_permission_group_itemsUpdateArgs} args - Arguments to update one Access_permission_group_items.
     * @example
     * // Update one Access_permission_group_items
     * const access_permission_group_items = await prisma.access_permission_group_items.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends access_permission_group_itemsUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, access_permission_group_itemsUpdateArgs<ExtArgs>>
    ): Prisma__access_permission_group_itemsClient<$Result.GetResult<Prisma.$access_permission_group_itemsPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more Access_permission_group_items.
     * @param {access_permission_group_itemsDeleteManyArgs} args - Arguments to filter Access_permission_group_items to delete.
     * @example
     * // Delete a few Access_permission_group_items
     * const { count } = await prisma.access_permission_group_items.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends access_permission_group_itemsDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, access_permission_group_itemsDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Access_permission_group_items.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {access_permission_group_itemsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Access_permission_group_items
     * const access_permission_group_items = await prisma.access_permission_group_items.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends access_permission_group_itemsUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, access_permission_group_itemsUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Access_permission_group_items.
     * @param {access_permission_group_itemsUpsertArgs} args - Arguments to update or create a Access_permission_group_items.
     * @example
     * // Update or create a Access_permission_group_items
     * const access_permission_group_items = await prisma.access_permission_group_items.upsert({
     *   create: {
     *     // ... data to create a Access_permission_group_items
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Access_permission_group_items we want to update
     *   }
     * })
    **/
    upsert<T extends access_permission_group_itemsUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, access_permission_group_itemsUpsertArgs<ExtArgs>>
    ): Prisma__access_permission_group_itemsClient<$Result.GetResult<Prisma.$access_permission_group_itemsPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of Access_permission_group_items.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {access_permission_group_itemsCountArgs} args - Arguments to filter Access_permission_group_items to count.
     * @example
     * // Count the number of Access_permission_group_items
     * const count = await prisma.access_permission_group_items.count({
     *   where: {
     *     // ... the filter for the Access_permission_group_items we want to count
     *   }
     * })
    **/
    count<T extends access_permission_group_itemsCountArgs>(
      args?: Subset<T, access_permission_group_itemsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Access_permission_group_itemsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Access_permission_group_items.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Access_permission_group_itemsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Access_permission_group_itemsAggregateArgs>(args: Subset<T, Access_permission_group_itemsAggregateArgs>): Prisma.PrismaPromise<GetAccess_permission_group_itemsAggregateType<T>>

    /**
     * Group by Access_permission_group_items.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {access_permission_group_itemsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends access_permission_group_itemsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: access_permission_group_itemsGroupByArgs['orderBy'] }
        : { orderBy?: access_permission_group_itemsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, access_permission_group_itemsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAccess_permission_group_itemsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the access_permission_group_items model
   */
  readonly fields: access_permission_group_itemsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for access_permission_group_items.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__access_permission_group_itemsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';


    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the access_permission_group_items model
   */ 
  interface access_permission_group_itemsFieldRefs {
    readonly id: FieldRef<"access_permission_group_items", 'String'>
    readonly userOrParentAccessPermissionId: FieldRef<"access_permission_group_items", 'String'>
    readonly providerKey: FieldRef<"access_permission_group_items", 'String'>
    readonly creatorId: FieldRef<"access_permission_group_items", 'String'>
    readonly createDate: FieldRef<"access_permission_group_items", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * access_permission_group_items findUnique
   */
  export type access_permission_group_itemsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group_items
     */
    select?: access_permission_group_itemsSelect<ExtArgs> | null
    /**
     * Filter, which access_permission_group_items to fetch.
     */
    where: access_permission_group_itemsWhereUniqueInput
  }

  /**
   * access_permission_group_items findUniqueOrThrow
   */
  export type access_permission_group_itemsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group_items
     */
    select?: access_permission_group_itemsSelect<ExtArgs> | null
    /**
     * Filter, which access_permission_group_items to fetch.
     */
    where: access_permission_group_itemsWhereUniqueInput
  }

  /**
   * access_permission_group_items findFirst
   */
  export type access_permission_group_itemsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group_items
     */
    select?: access_permission_group_itemsSelect<ExtArgs> | null
    /**
     * Filter, which access_permission_group_items to fetch.
     */
    where?: access_permission_group_itemsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of access_permission_group_items to fetch.
     */
    orderBy?: access_permission_group_itemsOrderByWithRelationInput | access_permission_group_itemsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for access_permission_group_items.
     */
    cursor?: access_permission_group_itemsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` access_permission_group_items from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` access_permission_group_items.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of access_permission_group_items.
     */
    distinct?: Access_permission_group_itemsScalarFieldEnum | Access_permission_group_itemsScalarFieldEnum[]
  }

  /**
   * access_permission_group_items findFirstOrThrow
   */
  export type access_permission_group_itemsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group_items
     */
    select?: access_permission_group_itemsSelect<ExtArgs> | null
    /**
     * Filter, which access_permission_group_items to fetch.
     */
    where?: access_permission_group_itemsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of access_permission_group_items to fetch.
     */
    orderBy?: access_permission_group_itemsOrderByWithRelationInput | access_permission_group_itemsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for access_permission_group_items.
     */
    cursor?: access_permission_group_itemsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` access_permission_group_items from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` access_permission_group_items.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of access_permission_group_items.
     */
    distinct?: Access_permission_group_itemsScalarFieldEnum | Access_permission_group_itemsScalarFieldEnum[]
  }

  /**
   * access_permission_group_items findMany
   */
  export type access_permission_group_itemsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group_items
     */
    select?: access_permission_group_itemsSelect<ExtArgs> | null
    /**
     * Filter, which access_permission_group_items to fetch.
     */
    where?: access_permission_group_itemsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of access_permission_group_items to fetch.
     */
    orderBy?: access_permission_group_itemsOrderByWithRelationInput | access_permission_group_itemsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing access_permission_group_items.
     */
    cursor?: access_permission_group_itemsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` access_permission_group_items from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` access_permission_group_items.
     */
    skip?: number
    distinct?: Access_permission_group_itemsScalarFieldEnum | Access_permission_group_itemsScalarFieldEnum[]
  }

  /**
   * access_permission_group_items create
   */
  export type access_permission_group_itemsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group_items
     */
    select?: access_permission_group_itemsSelect<ExtArgs> | null
    /**
     * The data needed to create a access_permission_group_items.
     */
    data: XOR<access_permission_group_itemsCreateInput, access_permission_group_itemsUncheckedCreateInput>
  }

  /**
   * access_permission_group_items createMany
   */
  export type access_permission_group_itemsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many access_permission_group_items.
     */
    data: access_permission_group_itemsCreateManyInput | access_permission_group_itemsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * access_permission_group_items update
   */
  export type access_permission_group_itemsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group_items
     */
    select?: access_permission_group_itemsSelect<ExtArgs> | null
    /**
     * The data needed to update a access_permission_group_items.
     */
    data: XOR<access_permission_group_itemsUpdateInput, access_permission_group_itemsUncheckedUpdateInput>
    /**
     * Choose, which access_permission_group_items to update.
     */
    where: access_permission_group_itemsWhereUniqueInput
  }

  /**
   * access_permission_group_items updateMany
   */
  export type access_permission_group_itemsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update access_permission_group_items.
     */
    data: XOR<access_permission_group_itemsUpdateManyMutationInput, access_permission_group_itemsUncheckedUpdateManyInput>
    /**
     * Filter which access_permission_group_items to update
     */
    where?: access_permission_group_itemsWhereInput
  }

  /**
   * access_permission_group_items upsert
   */
  export type access_permission_group_itemsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group_items
     */
    select?: access_permission_group_itemsSelect<ExtArgs> | null
    /**
     * The filter to search for the access_permission_group_items to update in case it exists.
     */
    where: access_permission_group_itemsWhereUniqueInput
    /**
     * In case the access_permission_group_items found by the `where` argument doesn't exist, create a new access_permission_group_items with this data.
     */
    create: XOR<access_permission_group_itemsCreateInput, access_permission_group_itemsUncheckedCreateInput>
    /**
     * In case the access_permission_group_items was found with the provided `where` argument, update it with this data.
     */
    update: XOR<access_permission_group_itemsUpdateInput, access_permission_group_itemsUncheckedUpdateInput>
  }

  /**
   * access_permission_group_items delete
   */
  export type access_permission_group_itemsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group_items
     */
    select?: access_permission_group_itemsSelect<ExtArgs> | null
    /**
     * Filter which access_permission_group_items to delete.
     */
    where: access_permission_group_itemsWhereUniqueInput
  }

  /**
   * access_permission_group_items deleteMany
   */
  export type access_permission_group_itemsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which access_permission_group_items to delete
     */
    where?: access_permission_group_itemsWhereInput
  }

  /**
   * access_permission_group_items without action
   */
  export type access_permission_group_itemsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the access_permission_group_items
     */
    select?: access_permission_group_itemsSelect<ExtArgs> | null
  }


  /**
   * Model settings
   */

  export type AggregateSettings = {
    _count: SettingsCountAggregateOutputType | null
    _min: SettingsMinAggregateOutputType | null
    _max: SettingsMaxAggregateOutputType | null
  }

  export type SettingsMinAggregateOutputType = {
    id: string | null
    providerKey: string | null
    providerValue: string | null
    creatorId: string | null
    createDate: Date | null
  }

  export type SettingsMaxAggregateOutputType = {
    id: string | null
    providerKey: string | null
    providerValue: string | null
    creatorId: string | null
    createDate: Date | null
  }

  export type SettingsCountAggregateOutputType = {
    id: number
    providerKey: number
    providerValue: number
    creatorId: number
    createDate: number
    _all: number
  }


  export type SettingsMinAggregateInputType = {
    id?: true
    providerKey?: true
    providerValue?: true
    creatorId?: true
    createDate?: true
  }

  export type SettingsMaxAggregateInputType = {
    id?: true
    providerKey?: true
    providerValue?: true
    creatorId?: true
    createDate?: true
  }

  export type SettingsCountAggregateInputType = {
    id?: true
    providerKey?: true
    providerValue?: true
    creatorId?: true
    createDate?: true
    _all?: true
  }

  export type SettingsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which settings to aggregate.
     */
    where?: settingsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of settings to fetch.
     */
    orderBy?: settingsOrderByWithRelationInput | settingsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: settingsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` settings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` settings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned settings
    **/
    _count?: true | SettingsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SettingsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SettingsMaxAggregateInputType
  }

  export type GetSettingsAggregateType<T extends SettingsAggregateArgs> = {
        [P in keyof T & keyof AggregateSettings]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSettings[P]>
      : GetScalarType<T[P], AggregateSettings[P]>
  }




  export type settingsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: settingsWhereInput
    orderBy?: settingsOrderByWithAggregationInput | settingsOrderByWithAggregationInput[]
    by: SettingsScalarFieldEnum[] | SettingsScalarFieldEnum
    having?: settingsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SettingsCountAggregateInputType | true
    _min?: SettingsMinAggregateInputType
    _max?: SettingsMaxAggregateInputType
  }

  export type SettingsGroupByOutputType = {
    id: string
    providerKey: string
    providerValue: string
    creatorId: string | null
    createDate: Date
    _count: SettingsCountAggregateOutputType | null
    _min: SettingsMinAggregateOutputType | null
    _max: SettingsMaxAggregateOutputType | null
  }

  type GetSettingsGroupByPayload<T extends settingsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SettingsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SettingsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SettingsGroupByOutputType[P]>
            : GetScalarType<T[P], SettingsGroupByOutputType[P]>
        }
      >
    >


  export type settingsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    providerKey?: boolean
    providerValue?: boolean
    creatorId?: boolean
    createDate?: boolean
  }, ExtArgs["result"]["settings"]>


  export type settingsSelectScalar = {
    id?: boolean
    providerKey?: boolean
    providerValue?: boolean
    creatorId?: boolean
    createDate?: boolean
  }


  export type $settingsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "settings"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      providerKey: string
      providerValue: string
      creatorId: string | null
      createDate: Date
    }, ExtArgs["result"]["settings"]>
    composites: {}
  }

  type settingsGetPayload<S extends boolean | null | undefined | settingsDefaultArgs> = $Result.GetResult<Prisma.$settingsPayload, S>

  type settingsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<settingsFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: SettingsCountAggregateInputType | true
    }

  export interface settingsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['settings'], meta: { name: 'settings' } }
    /**
     * Find zero or one Settings that matches the filter.
     * @param {settingsFindUniqueArgs} args - Arguments to find a Settings
     * @example
     * // Get one Settings
     * const settings = await prisma.settings.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends settingsFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, settingsFindUniqueArgs<ExtArgs>>
    ): Prisma__settingsClient<$Result.GetResult<Prisma.$settingsPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one Settings that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {settingsFindUniqueOrThrowArgs} args - Arguments to find a Settings
     * @example
     * // Get one Settings
     * const settings = await prisma.settings.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends settingsFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, settingsFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__settingsClient<$Result.GetResult<Prisma.$settingsPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first Settings that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {settingsFindFirstArgs} args - Arguments to find a Settings
     * @example
     * // Get one Settings
     * const settings = await prisma.settings.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends settingsFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, settingsFindFirstArgs<ExtArgs>>
    ): Prisma__settingsClient<$Result.GetResult<Prisma.$settingsPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first Settings that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {settingsFindFirstOrThrowArgs} args - Arguments to find a Settings
     * @example
     * // Get one Settings
     * const settings = await prisma.settings.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends settingsFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, settingsFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__settingsClient<$Result.GetResult<Prisma.$settingsPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more Settings that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {settingsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Settings
     * const settings = await prisma.settings.findMany()
     * 
     * // Get first 10 Settings
     * const settings = await prisma.settings.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const settingsWithIdOnly = await prisma.settings.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends settingsFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, settingsFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$settingsPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a Settings.
     * @param {settingsCreateArgs} args - Arguments to create a Settings.
     * @example
     * // Create one Settings
     * const Settings = await prisma.settings.create({
     *   data: {
     *     // ... data to create a Settings
     *   }
     * })
     * 
    **/
    create<T extends settingsCreateArgs<ExtArgs>>(
      args: SelectSubset<T, settingsCreateArgs<ExtArgs>>
    ): Prisma__settingsClient<$Result.GetResult<Prisma.$settingsPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many Settings.
     * @param {settingsCreateManyArgs} args - Arguments to create many Settings.
     * @example
     * // Create many Settings
     * const settings = await prisma.settings.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
    **/
    createMany<T extends settingsCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, settingsCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Settings.
     * @param {settingsDeleteArgs} args - Arguments to delete one Settings.
     * @example
     * // Delete one Settings
     * const Settings = await prisma.settings.delete({
     *   where: {
     *     // ... filter to delete one Settings
     *   }
     * })
     * 
    **/
    delete<T extends settingsDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, settingsDeleteArgs<ExtArgs>>
    ): Prisma__settingsClient<$Result.GetResult<Prisma.$settingsPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one Settings.
     * @param {settingsUpdateArgs} args - Arguments to update one Settings.
     * @example
     * // Update one Settings
     * const settings = await prisma.settings.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends settingsUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, settingsUpdateArgs<ExtArgs>>
    ): Prisma__settingsClient<$Result.GetResult<Prisma.$settingsPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more Settings.
     * @param {settingsDeleteManyArgs} args - Arguments to filter Settings to delete.
     * @example
     * // Delete a few Settings
     * const { count } = await prisma.settings.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends settingsDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, settingsDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Settings.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {settingsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Settings
     * const settings = await prisma.settings.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends settingsUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, settingsUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Settings.
     * @param {settingsUpsertArgs} args - Arguments to update or create a Settings.
     * @example
     * // Update or create a Settings
     * const settings = await prisma.settings.upsert({
     *   create: {
     *     // ... data to create a Settings
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Settings we want to update
     *   }
     * })
    **/
    upsert<T extends settingsUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, settingsUpsertArgs<ExtArgs>>
    ): Prisma__settingsClient<$Result.GetResult<Prisma.$settingsPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of Settings.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {settingsCountArgs} args - Arguments to filter Settings to count.
     * @example
     * // Count the number of Settings
     * const count = await prisma.settings.count({
     *   where: {
     *     // ... the filter for the Settings we want to count
     *   }
     * })
    **/
    count<T extends settingsCountArgs>(
      args?: Subset<T, settingsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SettingsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Settings.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SettingsAggregateArgs>(args: Subset<T, SettingsAggregateArgs>): Prisma.PrismaPromise<GetSettingsAggregateType<T>>

    /**
     * Group by Settings.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {settingsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends settingsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: settingsGroupByArgs['orderBy'] }
        : { orderBy?: settingsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, settingsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSettingsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the settings model
   */
  readonly fields: settingsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for settings.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__settingsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';


    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the settings model
   */ 
  interface settingsFieldRefs {
    readonly id: FieldRef<"settings", 'String'>
    readonly providerKey: FieldRef<"settings", 'String'>
    readonly providerValue: FieldRef<"settings", 'String'>
    readonly creatorId: FieldRef<"settings", 'String'>
    readonly createDate: FieldRef<"settings", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * settings findUnique
   */
  export type settingsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the settings
     */
    select?: settingsSelect<ExtArgs> | null
    /**
     * Filter, which settings to fetch.
     */
    where: settingsWhereUniqueInput
  }

  /**
   * settings findUniqueOrThrow
   */
  export type settingsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the settings
     */
    select?: settingsSelect<ExtArgs> | null
    /**
     * Filter, which settings to fetch.
     */
    where: settingsWhereUniqueInput
  }

  /**
   * settings findFirst
   */
  export type settingsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the settings
     */
    select?: settingsSelect<ExtArgs> | null
    /**
     * Filter, which settings to fetch.
     */
    where?: settingsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of settings to fetch.
     */
    orderBy?: settingsOrderByWithRelationInput | settingsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for settings.
     */
    cursor?: settingsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` settings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` settings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of settings.
     */
    distinct?: SettingsScalarFieldEnum | SettingsScalarFieldEnum[]
  }

  /**
   * settings findFirstOrThrow
   */
  export type settingsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the settings
     */
    select?: settingsSelect<ExtArgs> | null
    /**
     * Filter, which settings to fetch.
     */
    where?: settingsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of settings to fetch.
     */
    orderBy?: settingsOrderByWithRelationInput | settingsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for settings.
     */
    cursor?: settingsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` settings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` settings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of settings.
     */
    distinct?: SettingsScalarFieldEnum | SettingsScalarFieldEnum[]
  }

  /**
   * settings findMany
   */
  export type settingsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the settings
     */
    select?: settingsSelect<ExtArgs> | null
    /**
     * Filter, which settings to fetch.
     */
    where?: settingsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of settings to fetch.
     */
    orderBy?: settingsOrderByWithRelationInput | settingsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing settings.
     */
    cursor?: settingsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` settings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` settings.
     */
    skip?: number
    distinct?: SettingsScalarFieldEnum | SettingsScalarFieldEnum[]
  }

  /**
   * settings create
   */
  export type settingsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the settings
     */
    select?: settingsSelect<ExtArgs> | null
    /**
     * The data needed to create a settings.
     */
    data: XOR<settingsCreateInput, settingsUncheckedCreateInput>
  }

  /**
   * settings createMany
   */
  export type settingsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many settings.
     */
    data: settingsCreateManyInput | settingsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * settings update
   */
  export type settingsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the settings
     */
    select?: settingsSelect<ExtArgs> | null
    /**
     * The data needed to update a settings.
     */
    data: XOR<settingsUpdateInput, settingsUncheckedUpdateInput>
    /**
     * Choose, which settings to update.
     */
    where: settingsWhereUniqueInput
  }

  /**
   * settings updateMany
   */
  export type settingsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update settings.
     */
    data: XOR<settingsUpdateManyMutationInput, settingsUncheckedUpdateManyInput>
    /**
     * Filter which settings to update
     */
    where?: settingsWhereInput
  }

  /**
   * settings upsert
   */
  export type settingsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the settings
     */
    select?: settingsSelect<ExtArgs> | null
    /**
     * The filter to search for the settings to update in case it exists.
     */
    where: settingsWhereUniqueInput
    /**
     * In case the settings found by the `where` argument doesn't exist, create a new settings with this data.
     */
    create: XOR<settingsCreateInput, settingsUncheckedCreateInput>
    /**
     * In case the settings was found with the provided `where` argument, update it with this data.
     */
    update: XOR<settingsUpdateInput, settingsUncheckedUpdateInput>
  }

  /**
   * settings delete
   */
  export type settingsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the settings
     */
    select?: settingsSelect<ExtArgs> | null
    /**
     * Filter which settings to delete.
     */
    where: settingsWhereUniqueInput
  }

  /**
   * settings deleteMany
   */
  export type settingsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which settings to delete
     */
    where?: settingsWhereInput
  }

  /**
   * settings without action
   */
  export type settingsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the settings
     */
    select?: settingsSelect<ExtArgs> | null
  }


  /**
   * Model ipgs
   */

  export type AggregateIpgs = {
    _count: IpgsCountAggregateOutputType | null
    _min: IpgsMinAggregateOutputType | null
    _max: IpgsMaxAggregateOutputType | null
  }

  export type IpgsMinAggregateOutputType = {
    id: string | null
    provider: string | null
    merchantId: string | null
    terminalId: string | null
    terminalKey: string | null
    isActive: boolean | null
    creationTime: Date | null
    creatorId: string | null
  }

  export type IpgsMaxAggregateOutputType = {
    id: string | null
    provider: string | null
    merchantId: string | null
    terminalId: string | null
    terminalKey: string | null
    isActive: boolean | null
    creationTime: Date | null
    creatorId: string | null
  }

  export type IpgsCountAggregateOutputType = {
    id: number
    provider: number
    merchantId: number
    terminalId: number
    terminalKey: number
    isActive: number
    creationTime: number
    creatorId: number
    _all: number
  }


  export type IpgsMinAggregateInputType = {
    id?: true
    provider?: true
    merchantId?: true
    terminalId?: true
    terminalKey?: true
    isActive?: true
    creationTime?: true
    creatorId?: true
  }

  export type IpgsMaxAggregateInputType = {
    id?: true
    provider?: true
    merchantId?: true
    terminalId?: true
    terminalKey?: true
    isActive?: true
    creationTime?: true
    creatorId?: true
  }

  export type IpgsCountAggregateInputType = {
    id?: true
    provider?: true
    merchantId?: true
    terminalId?: true
    terminalKey?: true
    isActive?: true
    creationTime?: true
    creatorId?: true
    _all?: true
  }

  export type IpgsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ipgs to aggregate.
     */
    where?: ipgsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ipgs to fetch.
     */
    orderBy?: ipgsOrderByWithRelationInput | ipgsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ipgsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ipgs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ipgs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned ipgs
    **/
    _count?: true | IpgsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: IpgsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: IpgsMaxAggregateInputType
  }

  export type GetIpgsAggregateType<T extends IpgsAggregateArgs> = {
        [P in keyof T & keyof AggregateIpgs]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateIpgs[P]>
      : GetScalarType<T[P], AggregateIpgs[P]>
  }




  export type ipgsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ipgsWhereInput
    orderBy?: ipgsOrderByWithAggregationInput | ipgsOrderByWithAggregationInput[]
    by: IpgsScalarFieldEnum[] | IpgsScalarFieldEnum
    having?: ipgsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: IpgsCountAggregateInputType | true
    _min?: IpgsMinAggregateInputType
    _max?: IpgsMaxAggregateInputType
  }

  export type IpgsGroupByOutputType = {
    id: string
    provider: string | null
    merchantId: string
    terminalId: string
    terminalKey: string
    isActive: boolean
    creationTime: Date
    creatorId: string | null
    _count: IpgsCountAggregateOutputType | null
    _min: IpgsMinAggregateOutputType | null
    _max: IpgsMaxAggregateOutputType | null
  }

  type GetIpgsGroupByPayload<T extends ipgsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<IpgsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof IpgsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], IpgsGroupByOutputType[P]>
            : GetScalarType<T[P], IpgsGroupByOutputType[P]>
        }
      >
    >


  export type ipgsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    provider?: boolean
    merchantId?: boolean
    terminalId?: boolean
    terminalKey?: boolean
    isActive?: boolean
    creationTime?: boolean
    creatorId?: boolean
  }, ExtArgs["result"]["ipgs"]>


  export type ipgsSelectScalar = {
    id?: boolean
    provider?: boolean
    merchantId?: boolean
    terminalId?: boolean
    terminalKey?: boolean
    isActive?: boolean
    creationTime?: boolean
    creatorId?: boolean
  }


  export type $ipgsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "ipgs"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      provider: string | null
      merchantId: string
      terminalId: string
      terminalKey: string
      isActive: boolean
      creationTime: Date
      creatorId: string | null
    }, ExtArgs["result"]["ipgs"]>
    composites: {}
  }

  type ipgsGetPayload<S extends boolean | null | undefined | ipgsDefaultArgs> = $Result.GetResult<Prisma.$ipgsPayload, S>

  type ipgsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<ipgsFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: IpgsCountAggregateInputType | true
    }

  export interface ipgsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['ipgs'], meta: { name: 'ipgs' } }
    /**
     * Find zero or one Ipgs that matches the filter.
     * @param {ipgsFindUniqueArgs} args - Arguments to find a Ipgs
     * @example
     * // Get one Ipgs
     * const ipgs = await prisma.ipgs.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends ipgsFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, ipgsFindUniqueArgs<ExtArgs>>
    ): Prisma__ipgsClient<$Result.GetResult<Prisma.$ipgsPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one Ipgs that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {ipgsFindUniqueOrThrowArgs} args - Arguments to find a Ipgs
     * @example
     * // Get one Ipgs
     * const ipgs = await prisma.ipgs.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends ipgsFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, ipgsFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__ipgsClient<$Result.GetResult<Prisma.$ipgsPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first Ipgs that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ipgsFindFirstArgs} args - Arguments to find a Ipgs
     * @example
     * // Get one Ipgs
     * const ipgs = await prisma.ipgs.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends ipgsFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, ipgsFindFirstArgs<ExtArgs>>
    ): Prisma__ipgsClient<$Result.GetResult<Prisma.$ipgsPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first Ipgs that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ipgsFindFirstOrThrowArgs} args - Arguments to find a Ipgs
     * @example
     * // Get one Ipgs
     * const ipgs = await prisma.ipgs.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends ipgsFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, ipgsFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__ipgsClient<$Result.GetResult<Prisma.$ipgsPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more Ipgs that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ipgsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Ipgs
     * const ipgs = await prisma.ipgs.findMany()
     * 
     * // Get first 10 Ipgs
     * const ipgs = await prisma.ipgs.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const ipgsWithIdOnly = await prisma.ipgs.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends ipgsFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ipgsFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ipgsPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a Ipgs.
     * @param {ipgsCreateArgs} args - Arguments to create a Ipgs.
     * @example
     * // Create one Ipgs
     * const Ipgs = await prisma.ipgs.create({
     *   data: {
     *     // ... data to create a Ipgs
     *   }
     * })
     * 
    **/
    create<T extends ipgsCreateArgs<ExtArgs>>(
      args: SelectSubset<T, ipgsCreateArgs<ExtArgs>>
    ): Prisma__ipgsClient<$Result.GetResult<Prisma.$ipgsPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many Ipgs.
     * @param {ipgsCreateManyArgs} args - Arguments to create many Ipgs.
     * @example
     * // Create many Ipgs
     * const ipgs = await prisma.ipgs.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
    **/
    createMany<T extends ipgsCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ipgsCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Ipgs.
     * @param {ipgsDeleteArgs} args - Arguments to delete one Ipgs.
     * @example
     * // Delete one Ipgs
     * const Ipgs = await prisma.ipgs.delete({
     *   where: {
     *     // ... filter to delete one Ipgs
     *   }
     * })
     * 
    **/
    delete<T extends ipgsDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, ipgsDeleteArgs<ExtArgs>>
    ): Prisma__ipgsClient<$Result.GetResult<Prisma.$ipgsPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one Ipgs.
     * @param {ipgsUpdateArgs} args - Arguments to update one Ipgs.
     * @example
     * // Update one Ipgs
     * const ipgs = await prisma.ipgs.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends ipgsUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, ipgsUpdateArgs<ExtArgs>>
    ): Prisma__ipgsClient<$Result.GetResult<Prisma.$ipgsPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more Ipgs.
     * @param {ipgsDeleteManyArgs} args - Arguments to filter Ipgs to delete.
     * @example
     * // Delete a few Ipgs
     * const { count } = await prisma.ipgs.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends ipgsDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ipgsDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Ipgs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ipgsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Ipgs
     * const ipgs = await prisma.ipgs.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends ipgsUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, ipgsUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Ipgs.
     * @param {ipgsUpsertArgs} args - Arguments to update or create a Ipgs.
     * @example
     * // Update or create a Ipgs
     * const ipgs = await prisma.ipgs.upsert({
     *   create: {
     *     // ... data to create a Ipgs
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Ipgs we want to update
     *   }
     * })
    **/
    upsert<T extends ipgsUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, ipgsUpsertArgs<ExtArgs>>
    ): Prisma__ipgsClient<$Result.GetResult<Prisma.$ipgsPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of Ipgs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ipgsCountArgs} args - Arguments to filter Ipgs to count.
     * @example
     * // Count the number of Ipgs
     * const count = await prisma.ipgs.count({
     *   where: {
     *     // ... the filter for the Ipgs we want to count
     *   }
     * })
    **/
    count<T extends ipgsCountArgs>(
      args?: Subset<T, ipgsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], IpgsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Ipgs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {IpgsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends IpgsAggregateArgs>(args: Subset<T, IpgsAggregateArgs>): Prisma.PrismaPromise<GetIpgsAggregateType<T>>

    /**
     * Group by Ipgs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ipgsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ipgsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ipgsGroupByArgs['orderBy'] }
        : { orderBy?: ipgsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ipgsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetIpgsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the ipgs model
   */
  readonly fields: ipgsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for ipgs.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ipgsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';


    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the ipgs model
   */ 
  interface ipgsFieldRefs {
    readonly id: FieldRef<"ipgs", 'String'>
    readonly provider: FieldRef<"ipgs", 'String'>
    readonly merchantId: FieldRef<"ipgs", 'String'>
    readonly terminalId: FieldRef<"ipgs", 'String'>
    readonly terminalKey: FieldRef<"ipgs", 'String'>
    readonly isActive: FieldRef<"ipgs", 'Boolean'>
    readonly creationTime: FieldRef<"ipgs", 'DateTime'>
    readonly creatorId: FieldRef<"ipgs", 'String'>
  }
    

  // Custom InputTypes
  /**
   * ipgs findUnique
   */
  export type ipgsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ipgs
     */
    select?: ipgsSelect<ExtArgs> | null
    /**
     * Filter, which ipgs to fetch.
     */
    where: ipgsWhereUniqueInput
  }

  /**
   * ipgs findUniqueOrThrow
   */
  export type ipgsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ipgs
     */
    select?: ipgsSelect<ExtArgs> | null
    /**
     * Filter, which ipgs to fetch.
     */
    where: ipgsWhereUniqueInput
  }

  /**
   * ipgs findFirst
   */
  export type ipgsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ipgs
     */
    select?: ipgsSelect<ExtArgs> | null
    /**
     * Filter, which ipgs to fetch.
     */
    where?: ipgsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ipgs to fetch.
     */
    orderBy?: ipgsOrderByWithRelationInput | ipgsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ipgs.
     */
    cursor?: ipgsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ipgs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ipgs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ipgs.
     */
    distinct?: IpgsScalarFieldEnum | IpgsScalarFieldEnum[]
  }

  /**
   * ipgs findFirstOrThrow
   */
  export type ipgsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ipgs
     */
    select?: ipgsSelect<ExtArgs> | null
    /**
     * Filter, which ipgs to fetch.
     */
    where?: ipgsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ipgs to fetch.
     */
    orderBy?: ipgsOrderByWithRelationInput | ipgsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ipgs.
     */
    cursor?: ipgsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ipgs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ipgs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ipgs.
     */
    distinct?: IpgsScalarFieldEnum | IpgsScalarFieldEnum[]
  }

  /**
   * ipgs findMany
   */
  export type ipgsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ipgs
     */
    select?: ipgsSelect<ExtArgs> | null
    /**
     * Filter, which ipgs to fetch.
     */
    where?: ipgsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ipgs to fetch.
     */
    orderBy?: ipgsOrderByWithRelationInput | ipgsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing ipgs.
     */
    cursor?: ipgsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ipgs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ipgs.
     */
    skip?: number
    distinct?: IpgsScalarFieldEnum | IpgsScalarFieldEnum[]
  }

  /**
   * ipgs create
   */
  export type ipgsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ipgs
     */
    select?: ipgsSelect<ExtArgs> | null
    /**
     * The data needed to create a ipgs.
     */
    data: XOR<ipgsCreateInput, ipgsUncheckedCreateInput>
  }

  /**
   * ipgs createMany
   */
  export type ipgsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many ipgs.
     */
    data: ipgsCreateManyInput | ipgsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * ipgs update
   */
  export type ipgsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ipgs
     */
    select?: ipgsSelect<ExtArgs> | null
    /**
     * The data needed to update a ipgs.
     */
    data: XOR<ipgsUpdateInput, ipgsUncheckedUpdateInput>
    /**
     * Choose, which ipgs to update.
     */
    where: ipgsWhereUniqueInput
  }

  /**
   * ipgs updateMany
   */
  export type ipgsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update ipgs.
     */
    data: XOR<ipgsUpdateManyMutationInput, ipgsUncheckedUpdateManyInput>
    /**
     * Filter which ipgs to update
     */
    where?: ipgsWhereInput
  }

  /**
   * ipgs upsert
   */
  export type ipgsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ipgs
     */
    select?: ipgsSelect<ExtArgs> | null
    /**
     * The filter to search for the ipgs to update in case it exists.
     */
    where: ipgsWhereUniqueInput
    /**
     * In case the ipgs found by the `where` argument doesn't exist, create a new ipgs with this data.
     */
    create: XOR<ipgsCreateInput, ipgsUncheckedCreateInput>
    /**
     * In case the ipgs was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ipgsUpdateInput, ipgsUncheckedUpdateInput>
  }

  /**
   * ipgs delete
   */
  export type ipgsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ipgs
     */
    select?: ipgsSelect<ExtArgs> | null
    /**
     * Filter which ipgs to delete.
     */
    where: ipgsWhereUniqueInput
  }

  /**
   * ipgs deleteMany
   */
  export type ipgsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ipgs to delete
     */
    where?: ipgsWhereInput
  }

  /**
   * ipgs without action
   */
  export type ipgsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ipgs
     */
    select?: ipgsSelect<ExtArgs> | null
  }


  /**
   * Model reuqestcodes
   */

  export type AggregateReuqestcodes = {
    _count: ReuqestcodesCountAggregateOutputType | null
    _min: ReuqestcodesMinAggregateOutputType | null
    _max: ReuqestcodesMaxAggregateOutputType | null
  }

  export type ReuqestcodesMinAggregateOutputType = {
    id: string | null
    mobileNumber: string | null
    code: string | null
    createDate: Date | null
  }

  export type ReuqestcodesMaxAggregateOutputType = {
    id: string | null
    mobileNumber: string | null
    code: string | null
    createDate: Date | null
  }

  export type ReuqestcodesCountAggregateOutputType = {
    id: number
    mobileNumber: number
    code: number
    createDate: number
    _all: number
  }


  export type ReuqestcodesMinAggregateInputType = {
    id?: true
    mobileNumber?: true
    code?: true
    createDate?: true
  }

  export type ReuqestcodesMaxAggregateInputType = {
    id?: true
    mobileNumber?: true
    code?: true
    createDate?: true
  }

  export type ReuqestcodesCountAggregateInputType = {
    id?: true
    mobileNumber?: true
    code?: true
    createDate?: true
    _all?: true
  }

  export type ReuqestcodesAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which reuqestcodes to aggregate.
     */
    where?: reuqestcodesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of reuqestcodes to fetch.
     */
    orderBy?: reuqestcodesOrderByWithRelationInput | reuqestcodesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: reuqestcodesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` reuqestcodes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` reuqestcodes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned reuqestcodes
    **/
    _count?: true | ReuqestcodesCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ReuqestcodesMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ReuqestcodesMaxAggregateInputType
  }

  export type GetReuqestcodesAggregateType<T extends ReuqestcodesAggregateArgs> = {
        [P in keyof T & keyof AggregateReuqestcodes]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateReuqestcodes[P]>
      : GetScalarType<T[P], AggregateReuqestcodes[P]>
  }




  export type reuqestcodesGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: reuqestcodesWhereInput
    orderBy?: reuqestcodesOrderByWithAggregationInput | reuqestcodesOrderByWithAggregationInput[]
    by: ReuqestcodesScalarFieldEnum[] | ReuqestcodesScalarFieldEnum
    having?: reuqestcodesScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ReuqestcodesCountAggregateInputType | true
    _min?: ReuqestcodesMinAggregateInputType
    _max?: ReuqestcodesMaxAggregateInputType
  }

  export type ReuqestcodesGroupByOutputType = {
    id: string
    mobileNumber: string
    code: string
    createDate: Date
    _count: ReuqestcodesCountAggregateOutputType | null
    _min: ReuqestcodesMinAggregateOutputType | null
    _max: ReuqestcodesMaxAggregateOutputType | null
  }

  type GetReuqestcodesGroupByPayload<T extends reuqestcodesGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ReuqestcodesGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ReuqestcodesGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ReuqestcodesGroupByOutputType[P]>
            : GetScalarType<T[P], ReuqestcodesGroupByOutputType[P]>
        }
      >
    >


  export type reuqestcodesSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    mobileNumber?: boolean
    code?: boolean
    createDate?: boolean
  }, ExtArgs["result"]["reuqestcodes"]>


  export type reuqestcodesSelectScalar = {
    id?: boolean
    mobileNumber?: boolean
    code?: boolean
    createDate?: boolean
  }


  export type $reuqestcodesPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "reuqestcodes"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      mobileNumber: string
      code: string
      createDate: Date
    }, ExtArgs["result"]["reuqestcodes"]>
    composites: {}
  }

  type reuqestcodesGetPayload<S extends boolean | null | undefined | reuqestcodesDefaultArgs> = $Result.GetResult<Prisma.$reuqestcodesPayload, S>

  type reuqestcodesCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<reuqestcodesFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: ReuqestcodesCountAggregateInputType | true
    }

  export interface reuqestcodesDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['reuqestcodes'], meta: { name: 'reuqestcodes' } }
    /**
     * Find zero or one Reuqestcodes that matches the filter.
     * @param {reuqestcodesFindUniqueArgs} args - Arguments to find a Reuqestcodes
     * @example
     * // Get one Reuqestcodes
     * const reuqestcodes = await prisma.reuqestcodes.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends reuqestcodesFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, reuqestcodesFindUniqueArgs<ExtArgs>>
    ): Prisma__reuqestcodesClient<$Result.GetResult<Prisma.$reuqestcodesPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one Reuqestcodes that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {reuqestcodesFindUniqueOrThrowArgs} args - Arguments to find a Reuqestcodes
     * @example
     * // Get one Reuqestcodes
     * const reuqestcodes = await prisma.reuqestcodes.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends reuqestcodesFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, reuqestcodesFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__reuqestcodesClient<$Result.GetResult<Prisma.$reuqestcodesPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first Reuqestcodes that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {reuqestcodesFindFirstArgs} args - Arguments to find a Reuqestcodes
     * @example
     * // Get one Reuqestcodes
     * const reuqestcodes = await prisma.reuqestcodes.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends reuqestcodesFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, reuqestcodesFindFirstArgs<ExtArgs>>
    ): Prisma__reuqestcodesClient<$Result.GetResult<Prisma.$reuqestcodesPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first Reuqestcodes that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {reuqestcodesFindFirstOrThrowArgs} args - Arguments to find a Reuqestcodes
     * @example
     * // Get one Reuqestcodes
     * const reuqestcodes = await prisma.reuqestcodes.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends reuqestcodesFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, reuqestcodesFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__reuqestcodesClient<$Result.GetResult<Prisma.$reuqestcodesPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more Reuqestcodes that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {reuqestcodesFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Reuqestcodes
     * const reuqestcodes = await prisma.reuqestcodes.findMany()
     * 
     * // Get first 10 Reuqestcodes
     * const reuqestcodes = await prisma.reuqestcodes.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const reuqestcodesWithIdOnly = await prisma.reuqestcodes.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends reuqestcodesFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, reuqestcodesFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$reuqestcodesPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a Reuqestcodes.
     * @param {reuqestcodesCreateArgs} args - Arguments to create a Reuqestcodes.
     * @example
     * // Create one Reuqestcodes
     * const Reuqestcodes = await prisma.reuqestcodes.create({
     *   data: {
     *     // ... data to create a Reuqestcodes
     *   }
     * })
     * 
    **/
    create<T extends reuqestcodesCreateArgs<ExtArgs>>(
      args: SelectSubset<T, reuqestcodesCreateArgs<ExtArgs>>
    ): Prisma__reuqestcodesClient<$Result.GetResult<Prisma.$reuqestcodesPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many Reuqestcodes.
     * @param {reuqestcodesCreateManyArgs} args - Arguments to create many Reuqestcodes.
     * @example
     * // Create many Reuqestcodes
     * const reuqestcodes = await prisma.reuqestcodes.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
    **/
    createMany<T extends reuqestcodesCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, reuqestcodesCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Reuqestcodes.
     * @param {reuqestcodesDeleteArgs} args - Arguments to delete one Reuqestcodes.
     * @example
     * // Delete one Reuqestcodes
     * const Reuqestcodes = await prisma.reuqestcodes.delete({
     *   where: {
     *     // ... filter to delete one Reuqestcodes
     *   }
     * })
     * 
    **/
    delete<T extends reuqestcodesDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, reuqestcodesDeleteArgs<ExtArgs>>
    ): Prisma__reuqestcodesClient<$Result.GetResult<Prisma.$reuqestcodesPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one Reuqestcodes.
     * @param {reuqestcodesUpdateArgs} args - Arguments to update one Reuqestcodes.
     * @example
     * // Update one Reuqestcodes
     * const reuqestcodes = await prisma.reuqestcodes.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends reuqestcodesUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, reuqestcodesUpdateArgs<ExtArgs>>
    ): Prisma__reuqestcodesClient<$Result.GetResult<Prisma.$reuqestcodesPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more Reuqestcodes.
     * @param {reuqestcodesDeleteManyArgs} args - Arguments to filter Reuqestcodes to delete.
     * @example
     * // Delete a few Reuqestcodes
     * const { count } = await prisma.reuqestcodes.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends reuqestcodesDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, reuqestcodesDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Reuqestcodes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {reuqestcodesUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Reuqestcodes
     * const reuqestcodes = await prisma.reuqestcodes.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends reuqestcodesUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, reuqestcodesUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Reuqestcodes.
     * @param {reuqestcodesUpsertArgs} args - Arguments to update or create a Reuqestcodes.
     * @example
     * // Update or create a Reuqestcodes
     * const reuqestcodes = await prisma.reuqestcodes.upsert({
     *   create: {
     *     // ... data to create a Reuqestcodes
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Reuqestcodes we want to update
     *   }
     * })
    **/
    upsert<T extends reuqestcodesUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, reuqestcodesUpsertArgs<ExtArgs>>
    ): Prisma__reuqestcodesClient<$Result.GetResult<Prisma.$reuqestcodesPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of Reuqestcodes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {reuqestcodesCountArgs} args - Arguments to filter Reuqestcodes to count.
     * @example
     * // Count the number of Reuqestcodes
     * const count = await prisma.reuqestcodes.count({
     *   where: {
     *     // ... the filter for the Reuqestcodes we want to count
     *   }
     * })
    **/
    count<T extends reuqestcodesCountArgs>(
      args?: Subset<T, reuqestcodesCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ReuqestcodesCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Reuqestcodes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ReuqestcodesAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ReuqestcodesAggregateArgs>(args: Subset<T, ReuqestcodesAggregateArgs>): Prisma.PrismaPromise<GetReuqestcodesAggregateType<T>>

    /**
     * Group by Reuqestcodes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {reuqestcodesGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends reuqestcodesGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: reuqestcodesGroupByArgs['orderBy'] }
        : { orderBy?: reuqestcodesGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, reuqestcodesGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetReuqestcodesGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the reuqestcodes model
   */
  readonly fields: reuqestcodesFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for reuqestcodes.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__reuqestcodesClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';


    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the reuqestcodes model
   */ 
  interface reuqestcodesFieldRefs {
    readonly id: FieldRef<"reuqestcodes", 'String'>
    readonly mobileNumber: FieldRef<"reuqestcodes", 'String'>
    readonly code: FieldRef<"reuqestcodes", 'String'>
    readonly createDate: FieldRef<"reuqestcodes", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * reuqestcodes findUnique
   */
  export type reuqestcodesFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the reuqestcodes
     */
    select?: reuqestcodesSelect<ExtArgs> | null
    /**
     * Filter, which reuqestcodes to fetch.
     */
    where: reuqestcodesWhereUniqueInput
  }

  /**
   * reuqestcodes findUniqueOrThrow
   */
  export type reuqestcodesFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the reuqestcodes
     */
    select?: reuqestcodesSelect<ExtArgs> | null
    /**
     * Filter, which reuqestcodes to fetch.
     */
    where: reuqestcodesWhereUniqueInput
  }

  /**
   * reuqestcodes findFirst
   */
  export type reuqestcodesFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the reuqestcodes
     */
    select?: reuqestcodesSelect<ExtArgs> | null
    /**
     * Filter, which reuqestcodes to fetch.
     */
    where?: reuqestcodesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of reuqestcodes to fetch.
     */
    orderBy?: reuqestcodesOrderByWithRelationInput | reuqestcodesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for reuqestcodes.
     */
    cursor?: reuqestcodesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` reuqestcodes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` reuqestcodes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of reuqestcodes.
     */
    distinct?: ReuqestcodesScalarFieldEnum | ReuqestcodesScalarFieldEnum[]
  }

  /**
   * reuqestcodes findFirstOrThrow
   */
  export type reuqestcodesFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the reuqestcodes
     */
    select?: reuqestcodesSelect<ExtArgs> | null
    /**
     * Filter, which reuqestcodes to fetch.
     */
    where?: reuqestcodesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of reuqestcodes to fetch.
     */
    orderBy?: reuqestcodesOrderByWithRelationInput | reuqestcodesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for reuqestcodes.
     */
    cursor?: reuqestcodesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` reuqestcodes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` reuqestcodes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of reuqestcodes.
     */
    distinct?: ReuqestcodesScalarFieldEnum | ReuqestcodesScalarFieldEnum[]
  }

  /**
   * reuqestcodes findMany
   */
  export type reuqestcodesFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the reuqestcodes
     */
    select?: reuqestcodesSelect<ExtArgs> | null
    /**
     * Filter, which reuqestcodes to fetch.
     */
    where?: reuqestcodesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of reuqestcodes to fetch.
     */
    orderBy?: reuqestcodesOrderByWithRelationInput | reuqestcodesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing reuqestcodes.
     */
    cursor?: reuqestcodesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` reuqestcodes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` reuqestcodes.
     */
    skip?: number
    distinct?: ReuqestcodesScalarFieldEnum | ReuqestcodesScalarFieldEnum[]
  }

  /**
   * reuqestcodes create
   */
  export type reuqestcodesCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the reuqestcodes
     */
    select?: reuqestcodesSelect<ExtArgs> | null
    /**
     * The data needed to create a reuqestcodes.
     */
    data: XOR<reuqestcodesCreateInput, reuqestcodesUncheckedCreateInput>
  }

  /**
   * reuqestcodes createMany
   */
  export type reuqestcodesCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many reuqestcodes.
     */
    data: reuqestcodesCreateManyInput | reuqestcodesCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * reuqestcodes update
   */
  export type reuqestcodesUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the reuqestcodes
     */
    select?: reuqestcodesSelect<ExtArgs> | null
    /**
     * The data needed to update a reuqestcodes.
     */
    data: XOR<reuqestcodesUpdateInput, reuqestcodesUncheckedUpdateInput>
    /**
     * Choose, which reuqestcodes to update.
     */
    where: reuqestcodesWhereUniqueInput
  }

  /**
   * reuqestcodes updateMany
   */
  export type reuqestcodesUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update reuqestcodes.
     */
    data: XOR<reuqestcodesUpdateManyMutationInput, reuqestcodesUncheckedUpdateManyInput>
    /**
     * Filter which reuqestcodes to update
     */
    where?: reuqestcodesWhereInput
  }

  /**
   * reuqestcodes upsert
   */
  export type reuqestcodesUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the reuqestcodes
     */
    select?: reuqestcodesSelect<ExtArgs> | null
    /**
     * The filter to search for the reuqestcodes to update in case it exists.
     */
    where: reuqestcodesWhereUniqueInput
    /**
     * In case the reuqestcodes found by the `where` argument doesn't exist, create a new reuqestcodes with this data.
     */
    create: XOR<reuqestcodesCreateInput, reuqestcodesUncheckedCreateInput>
    /**
     * In case the reuqestcodes was found with the provided `where` argument, update it with this data.
     */
    update: XOR<reuqestcodesUpdateInput, reuqestcodesUncheckedUpdateInput>
  }

  /**
   * reuqestcodes delete
   */
  export type reuqestcodesDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the reuqestcodes
     */
    select?: reuqestcodesSelect<ExtArgs> | null
    /**
     * Filter which reuqestcodes to delete.
     */
    where: reuqestcodesWhereUniqueInput
  }

  /**
   * reuqestcodes deleteMany
   */
  export type reuqestcodesDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which reuqestcodes to delete
     */
    where?: reuqestcodesWhereInput
  }

  /**
   * reuqestcodes without action
   */
  export type reuqestcodesDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the reuqestcodes
     */
    select?: reuqestcodesSelect<ExtArgs> | null
  }


  /**
   * Model baseData
   */

  export type AggregateBaseData = {
    _count: BaseDataCountAggregateOutputType | null
    _min: BaseDataMinAggregateOutputType | null
    _max: BaseDataMaxAggregateOutputType | null
  }

  export type BaseDataMinAggregateOutputType = {
    id: string | null
    providerKey: string | null
    providerValue: string | null
    providerData: string | null
    providerData_2: string | null
    createDate: Date | null
  }

  export type BaseDataMaxAggregateOutputType = {
    id: string | null
    providerKey: string | null
    providerValue: string | null
    providerData: string | null
    providerData_2: string | null
    createDate: Date | null
  }

  export type BaseDataCountAggregateOutputType = {
    id: number
    providerKey: number
    providerValue: number
    providerData: number
    providerData_2: number
    createDate: number
    _all: number
  }


  export type BaseDataMinAggregateInputType = {
    id?: true
    providerKey?: true
    providerValue?: true
    providerData?: true
    providerData_2?: true
    createDate?: true
  }

  export type BaseDataMaxAggregateInputType = {
    id?: true
    providerKey?: true
    providerValue?: true
    providerData?: true
    providerData_2?: true
    createDate?: true
  }

  export type BaseDataCountAggregateInputType = {
    id?: true
    providerKey?: true
    providerValue?: true
    providerData?: true
    providerData_2?: true
    createDate?: true
    _all?: true
  }

  export type BaseDataAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which baseData to aggregate.
     */
    where?: baseDataWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of baseData to fetch.
     */
    orderBy?: baseDataOrderByWithRelationInput | baseDataOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: baseDataWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` baseData from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` baseData.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned baseData
    **/
    _count?: true | BaseDataCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: BaseDataMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: BaseDataMaxAggregateInputType
  }

  export type GetBaseDataAggregateType<T extends BaseDataAggregateArgs> = {
        [P in keyof T & keyof AggregateBaseData]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateBaseData[P]>
      : GetScalarType<T[P], AggregateBaseData[P]>
  }




  export type baseDataGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: baseDataWhereInput
    orderBy?: baseDataOrderByWithAggregationInput | baseDataOrderByWithAggregationInput[]
    by: BaseDataScalarFieldEnum[] | BaseDataScalarFieldEnum
    having?: baseDataScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: BaseDataCountAggregateInputType | true
    _min?: BaseDataMinAggregateInputType
    _max?: BaseDataMaxAggregateInputType
  }

  export type BaseDataGroupByOutputType = {
    id: string
    providerKey: string
    providerValue: string
    providerData: string | null
    providerData_2: string | null
    createDate: Date
    _count: BaseDataCountAggregateOutputType | null
    _min: BaseDataMinAggregateOutputType | null
    _max: BaseDataMaxAggregateOutputType | null
  }

  type GetBaseDataGroupByPayload<T extends baseDataGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<BaseDataGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof BaseDataGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], BaseDataGroupByOutputType[P]>
            : GetScalarType<T[P], BaseDataGroupByOutputType[P]>
        }
      >
    >


  export type baseDataSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    providerKey?: boolean
    providerValue?: boolean
    providerData?: boolean
    providerData_2?: boolean
    createDate?: boolean
  }, ExtArgs["result"]["baseData"]>


  export type baseDataSelectScalar = {
    id?: boolean
    providerKey?: boolean
    providerValue?: boolean
    providerData?: boolean
    providerData_2?: boolean
    createDate?: boolean
  }


  export type $baseDataPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "baseData"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      providerKey: string
      providerValue: string
      providerData: string | null
      providerData_2: string | null
      createDate: Date
    }, ExtArgs["result"]["baseData"]>
    composites: {}
  }

  type baseDataGetPayload<S extends boolean | null | undefined | baseDataDefaultArgs> = $Result.GetResult<Prisma.$baseDataPayload, S>

  type baseDataCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<baseDataFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: BaseDataCountAggregateInputType | true
    }

  export interface baseDataDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['baseData'], meta: { name: 'baseData' } }
    /**
     * Find zero or one BaseData that matches the filter.
     * @param {baseDataFindUniqueArgs} args - Arguments to find a BaseData
     * @example
     * // Get one BaseData
     * const baseData = await prisma.baseData.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends baseDataFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, baseDataFindUniqueArgs<ExtArgs>>
    ): Prisma__baseDataClient<$Result.GetResult<Prisma.$baseDataPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one BaseData that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {baseDataFindUniqueOrThrowArgs} args - Arguments to find a BaseData
     * @example
     * // Get one BaseData
     * const baseData = await prisma.baseData.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends baseDataFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, baseDataFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__baseDataClient<$Result.GetResult<Prisma.$baseDataPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first BaseData that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {baseDataFindFirstArgs} args - Arguments to find a BaseData
     * @example
     * // Get one BaseData
     * const baseData = await prisma.baseData.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends baseDataFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, baseDataFindFirstArgs<ExtArgs>>
    ): Prisma__baseDataClient<$Result.GetResult<Prisma.$baseDataPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first BaseData that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {baseDataFindFirstOrThrowArgs} args - Arguments to find a BaseData
     * @example
     * // Get one BaseData
     * const baseData = await prisma.baseData.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends baseDataFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, baseDataFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__baseDataClient<$Result.GetResult<Prisma.$baseDataPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more BaseData that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {baseDataFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all BaseData
     * const baseData = await prisma.baseData.findMany()
     * 
     * // Get first 10 BaseData
     * const baseData = await prisma.baseData.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const baseDataWithIdOnly = await prisma.baseData.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends baseDataFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, baseDataFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$baseDataPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a BaseData.
     * @param {baseDataCreateArgs} args - Arguments to create a BaseData.
     * @example
     * // Create one BaseData
     * const BaseData = await prisma.baseData.create({
     *   data: {
     *     // ... data to create a BaseData
     *   }
     * })
     * 
    **/
    create<T extends baseDataCreateArgs<ExtArgs>>(
      args: SelectSubset<T, baseDataCreateArgs<ExtArgs>>
    ): Prisma__baseDataClient<$Result.GetResult<Prisma.$baseDataPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many BaseData.
     * @param {baseDataCreateManyArgs} args - Arguments to create many BaseData.
     * @example
     * // Create many BaseData
     * const baseData = await prisma.baseData.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
    **/
    createMany<T extends baseDataCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, baseDataCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a BaseData.
     * @param {baseDataDeleteArgs} args - Arguments to delete one BaseData.
     * @example
     * // Delete one BaseData
     * const BaseData = await prisma.baseData.delete({
     *   where: {
     *     // ... filter to delete one BaseData
     *   }
     * })
     * 
    **/
    delete<T extends baseDataDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, baseDataDeleteArgs<ExtArgs>>
    ): Prisma__baseDataClient<$Result.GetResult<Prisma.$baseDataPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one BaseData.
     * @param {baseDataUpdateArgs} args - Arguments to update one BaseData.
     * @example
     * // Update one BaseData
     * const baseData = await prisma.baseData.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends baseDataUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, baseDataUpdateArgs<ExtArgs>>
    ): Prisma__baseDataClient<$Result.GetResult<Prisma.$baseDataPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more BaseData.
     * @param {baseDataDeleteManyArgs} args - Arguments to filter BaseData to delete.
     * @example
     * // Delete a few BaseData
     * const { count } = await prisma.baseData.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends baseDataDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, baseDataDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more BaseData.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {baseDataUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many BaseData
     * const baseData = await prisma.baseData.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends baseDataUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, baseDataUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one BaseData.
     * @param {baseDataUpsertArgs} args - Arguments to update or create a BaseData.
     * @example
     * // Update or create a BaseData
     * const baseData = await prisma.baseData.upsert({
     *   create: {
     *     // ... data to create a BaseData
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the BaseData we want to update
     *   }
     * })
    **/
    upsert<T extends baseDataUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, baseDataUpsertArgs<ExtArgs>>
    ): Prisma__baseDataClient<$Result.GetResult<Prisma.$baseDataPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of BaseData.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {baseDataCountArgs} args - Arguments to filter BaseData to count.
     * @example
     * // Count the number of BaseData
     * const count = await prisma.baseData.count({
     *   where: {
     *     // ... the filter for the BaseData we want to count
     *   }
     * })
    **/
    count<T extends baseDataCountArgs>(
      args?: Subset<T, baseDataCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], BaseDataCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a BaseData.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BaseDataAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends BaseDataAggregateArgs>(args: Subset<T, BaseDataAggregateArgs>): Prisma.PrismaPromise<GetBaseDataAggregateType<T>>

    /**
     * Group by BaseData.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {baseDataGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends baseDataGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: baseDataGroupByArgs['orderBy'] }
        : { orderBy?: baseDataGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, baseDataGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetBaseDataGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the baseData model
   */
  readonly fields: baseDataFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for baseData.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__baseDataClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';


    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the baseData model
   */ 
  interface baseDataFieldRefs {
    readonly id: FieldRef<"baseData", 'String'>
    readonly providerKey: FieldRef<"baseData", 'String'>
    readonly providerValue: FieldRef<"baseData", 'String'>
    readonly providerData: FieldRef<"baseData", 'String'>
    readonly providerData_2: FieldRef<"baseData", 'String'>
    readonly createDate: FieldRef<"baseData", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * baseData findUnique
   */
  export type baseDataFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the baseData
     */
    select?: baseDataSelect<ExtArgs> | null
    /**
     * Filter, which baseData to fetch.
     */
    where: baseDataWhereUniqueInput
  }

  /**
   * baseData findUniqueOrThrow
   */
  export type baseDataFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the baseData
     */
    select?: baseDataSelect<ExtArgs> | null
    /**
     * Filter, which baseData to fetch.
     */
    where: baseDataWhereUniqueInput
  }

  /**
   * baseData findFirst
   */
  export type baseDataFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the baseData
     */
    select?: baseDataSelect<ExtArgs> | null
    /**
     * Filter, which baseData to fetch.
     */
    where?: baseDataWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of baseData to fetch.
     */
    orderBy?: baseDataOrderByWithRelationInput | baseDataOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for baseData.
     */
    cursor?: baseDataWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` baseData from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` baseData.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of baseData.
     */
    distinct?: BaseDataScalarFieldEnum | BaseDataScalarFieldEnum[]
  }

  /**
   * baseData findFirstOrThrow
   */
  export type baseDataFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the baseData
     */
    select?: baseDataSelect<ExtArgs> | null
    /**
     * Filter, which baseData to fetch.
     */
    where?: baseDataWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of baseData to fetch.
     */
    orderBy?: baseDataOrderByWithRelationInput | baseDataOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for baseData.
     */
    cursor?: baseDataWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` baseData from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` baseData.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of baseData.
     */
    distinct?: BaseDataScalarFieldEnum | BaseDataScalarFieldEnum[]
  }

  /**
   * baseData findMany
   */
  export type baseDataFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the baseData
     */
    select?: baseDataSelect<ExtArgs> | null
    /**
     * Filter, which baseData to fetch.
     */
    where?: baseDataWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of baseData to fetch.
     */
    orderBy?: baseDataOrderByWithRelationInput | baseDataOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing baseData.
     */
    cursor?: baseDataWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` baseData from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` baseData.
     */
    skip?: number
    distinct?: BaseDataScalarFieldEnum | BaseDataScalarFieldEnum[]
  }

  /**
   * baseData create
   */
  export type baseDataCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the baseData
     */
    select?: baseDataSelect<ExtArgs> | null
    /**
     * The data needed to create a baseData.
     */
    data: XOR<baseDataCreateInput, baseDataUncheckedCreateInput>
  }

  /**
   * baseData createMany
   */
  export type baseDataCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many baseData.
     */
    data: baseDataCreateManyInput | baseDataCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * baseData update
   */
  export type baseDataUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the baseData
     */
    select?: baseDataSelect<ExtArgs> | null
    /**
     * The data needed to update a baseData.
     */
    data: XOR<baseDataUpdateInput, baseDataUncheckedUpdateInput>
    /**
     * Choose, which baseData to update.
     */
    where: baseDataWhereUniqueInput
  }

  /**
   * baseData updateMany
   */
  export type baseDataUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update baseData.
     */
    data: XOR<baseDataUpdateManyMutationInput, baseDataUncheckedUpdateManyInput>
    /**
     * Filter which baseData to update
     */
    where?: baseDataWhereInput
  }

  /**
   * baseData upsert
   */
  export type baseDataUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the baseData
     */
    select?: baseDataSelect<ExtArgs> | null
    /**
     * The filter to search for the baseData to update in case it exists.
     */
    where: baseDataWhereUniqueInput
    /**
     * In case the baseData found by the `where` argument doesn't exist, create a new baseData with this data.
     */
    create: XOR<baseDataCreateInput, baseDataUncheckedCreateInput>
    /**
     * In case the baseData was found with the provided `where` argument, update it with this data.
     */
    update: XOR<baseDataUpdateInput, baseDataUncheckedUpdateInput>
  }

  /**
   * baseData delete
   */
  export type baseDataDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the baseData
     */
    select?: baseDataSelect<ExtArgs> | null
    /**
     * Filter which baseData to delete.
     */
    where: baseDataWhereUniqueInput
  }

  /**
   * baseData deleteMany
   */
  export type baseDataDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which baseData to delete
     */
    where?: baseDataWhereInput
  }

  /**
   * baseData without action
   */
  export type baseDataDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the baseData
     */
    select?: baseDataSelect<ExtArgs> | null
  }


  /**
   * Model members
   */

  export type AggregateMembers = {
    _count: MembersCountAggregateOutputType | null
    _avg: MembersAvgAggregateOutputType | null
    _sum: MembersSumAggregateOutputType | null
    _min: MembersMinAggregateOutputType | null
    _max: MembersMaxAggregateOutputType | null
  }

  export type MembersAvgAggregateOutputType = {
    disabilityStatus: number | null
    educationLevel: number | null
    maritalStatus: number | null
    childrenCounts: number | null
    status: number | null
  }

  export type MembersSumAggregateOutputType = {
    disabilityStatus: number | null
    educationLevel: number | null
    maritalStatus: number | null
    childrenCounts: number | null
    status: number | null
  }

  export type MembersMinAggregateOutputType = {
    id: string | null
    name: string | null
    family: string | null
    nationalCode: string | null
    fatherName: string | null
    disabilityStatus: number | null
    disabilityDescription: string | null
    partnerJob: string | null
    educationLevel: number | null
    maritalStatus: number | null
    childrenCounts: number | null
    birthDate: string | null
    mobileNumber: string | null
    address: string | null
    username: string | null
    password: string | null
    status: number | null
    creationTime: Date | null
    creatorId: string | null
    isDeleted: boolean | null
  }

  export type MembersMaxAggregateOutputType = {
    id: string | null
    name: string | null
    family: string | null
    nationalCode: string | null
    fatherName: string | null
    disabilityStatus: number | null
    disabilityDescription: string | null
    partnerJob: string | null
    educationLevel: number | null
    maritalStatus: number | null
    childrenCounts: number | null
    birthDate: string | null
    mobileNumber: string | null
    address: string | null
    username: string | null
    password: string | null
    status: number | null
    creationTime: Date | null
    creatorId: string | null
    isDeleted: boolean | null
  }

  export type MembersCountAggregateOutputType = {
    id: number
    name: number
    family: number
    nationalCode: number
    fatherName: number
    disabilityStatus: number
    disabilityDescription: number
    partnerJob: number
    educationLevel: number
    maritalStatus: number
    childrenCounts: number
    birthDate: number
    mobileNumber: number
    address: number
    username: number
    password: number
    status: number
    creationTime: number
    creatorId: number
    isDeleted: number
    _all: number
  }


  export type MembersAvgAggregateInputType = {
    disabilityStatus?: true
    educationLevel?: true
    maritalStatus?: true
    childrenCounts?: true
    status?: true
  }

  export type MembersSumAggregateInputType = {
    disabilityStatus?: true
    educationLevel?: true
    maritalStatus?: true
    childrenCounts?: true
    status?: true
  }

  export type MembersMinAggregateInputType = {
    id?: true
    name?: true
    family?: true
    nationalCode?: true
    fatherName?: true
    disabilityStatus?: true
    disabilityDescription?: true
    partnerJob?: true
    educationLevel?: true
    maritalStatus?: true
    childrenCounts?: true
    birthDate?: true
    mobileNumber?: true
    address?: true
    username?: true
    password?: true
    status?: true
    creationTime?: true
    creatorId?: true
    isDeleted?: true
  }

  export type MembersMaxAggregateInputType = {
    id?: true
    name?: true
    family?: true
    nationalCode?: true
    fatherName?: true
    disabilityStatus?: true
    disabilityDescription?: true
    partnerJob?: true
    educationLevel?: true
    maritalStatus?: true
    childrenCounts?: true
    birthDate?: true
    mobileNumber?: true
    address?: true
    username?: true
    password?: true
    status?: true
    creationTime?: true
    creatorId?: true
    isDeleted?: true
  }

  export type MembersCountAggregateInputType = {
    id?: true
    name?: true
    family?: true
    nationalCode?: true
    fatherName?: true
    disabilityStatus?: true
    disabilityDescription?: true
    partnerJob?: true
    educationLevel?: true
    maritalStatus?: true
    childrenCounts?: true
    birthDate?: true
    mobileNumber?: true
    address?: true
    username?: true
    password?: true
    status?: true
    creationTime?: true
    creatorId?: true
    isDeleted?: true
    _all?: true
  }

  export type MembersAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which members to aggregate.
     */
    where?: membersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of members to fetch.
     */
    orderBy?: membersOrderByWithRelationInput | membersOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: membersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` members from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` members.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned members
    **/
    _count?: true | MembersCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: MembersAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: MembersSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: MembersMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: MembersMaxAggregateInputType
  }

  export type GetMembersAggregateType<T extends MembersAggregateArgs> = {
        [P in keyof T & keyof AggregateMembers]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateMembers[P]>
      : GetScalarType<T[P], AggregateMembers[P]>
  }




  export type membersGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: membersWhereInput
    orderBy?: membersOrderByWithAggregationInput | membersOrderByWithAggregationInput[]
    by: MembersScalarFieldEnum[] | MembersScalarFieldEnum
    having?: membersScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: MembersCountAggregateInputType | true
    _avg?: MembersAvgAggregateInputType
    _sum?: MembersSumAggregateInputType
    _min?: MembersMinAggregateInputType
    _max?: MembersMaxAggregateInputType
  }

  export type MembersGroupByOutputType = {
    id: string
    name: string | null
    family: string | null
    nationalCode: string | null
    fatherName: string | null
    disabilityStatus: number | null
    disabilityDescription: string | null
    partnerJob: string | null
    educationLevel: number | null
    maritalStatus: number | null
    childrenCounts: number | null
    birthDate: string | null
    mobileNumber: string
    address: string | null
    username: string | null
    password: string | null
    status: number | null
    creationTime: Date
    creatorId: string | null
    isDeleted: boolean
    _count: MembersCountAggregateOutputType | null
    _avg: MembersAvgAggregateOutputType | null
    _sum: MembersSumAggregateOutputType | null
    _min: MembersMinAggregateOutputType | null
    _max: MembersMaxAggregateOutputType | null
  }

  type GetMembersGroupByPayload<T extends membersGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<MembersGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof MembersGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], MembersGroupByOutputType[P]>
            : GetScalarType<T[P], MembersGroupByOutputType[P]>
        }
      >
    >


  export type membersSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    family?: boolean
    nationalCode?: boolean
    fatherName?: boolean
    disabilityStatus?: boolean
    disabilityDescription?: boolean
    partnerJob?: boolean
    educationLevel?: boolean
    maritalStatus?: boolean
    childrenCounts?: boolean
    birthDate?: boolean
    mobileNumber?: boolean
    address?: boolean
    username?: boolean
    password?: boolean
    status?: boolean
    creationTime?: boolean
    creatorId?: boolean
    isDeleted?: boolean
  }, ExtArgs["result"]["members"]>


  export type membersSelectScalar = {
    id?: boolean
    name?: boolean
    family?: boolean
    nationalCode?: boolean
    fatherName?: boolean
    disabilityStatus?: boolean
    disabilityDescription?: boolean
    partnerJob?: boolean
    educationLevel?: boolean
    maritalStatus?: boolean
    childrenCounts?: boolean
    birthDate?: boolean
    mobileNumber?: boolean
    address?: boolean
    username?: boolean
    password?: boolean
    status?: boolean
    creationTime?: boolean
    creatorId?: boolean
    isDeleted?: boolean
  }


  export type $membersPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "members"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string | null
      family: string | null
      nationalCode: string | null
      fatherName: string | null
      disabilityStatus: number | null
      disabilityDescription: string | null
      partnerJob: string | null
      educationLevel: number | null
      maritalStatus: number | null
      childrenCounts: number | null
      birthDate: string | null
      mobileNumber: string
      address: string | null
      username: string | null
      password: string | null
      status: number | null
      creationTime: Date
      creatorId: string | null
      isDeleted: boolean
    }, ExtArgs["result"]["members"]>
    composites: {}
  }

  type membersGetPayload<S extends boolean | null | undefined | membersDefaultArgs> = $Result.GetResult<Prisma.$membersPayload, S>

  type membersCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<membersFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: MembersCountAggregateInputType | true
    }

  export interface membersDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['members'], meta: { name: 'members' } }
    /**
     * Find zero or one Members that matches the filter.
     * @param {membersFindUniqueArgs} args - Arguments to find a Members
     * @example
     * // Get one Members
     * const members = await prisma.members.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends membersFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, membersFindUniqueArgs<ExtArgs>>
    ): Prisma__membersClient<$Result.GetResult<Prisma.$membersPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one Members that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {membersFindUniqueOrThrowArgs} args - Arguments to find a Members
     * @example
     * // Get one Members
     * const members = await prisma.members.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends membersFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, membersFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__membersClient<$Result.GetResult<Prisma.$membersPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first Members that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {membersFindFirstArgs} args - Arguments to find a Members
     * @example
     * // Get one Members
     * const members = await prisma.members.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends membersFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, membersFindFirstArgs<ExtArgs>>
    ): Prisma__membersClient<$Result.GetResult<Prisma.$membersPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first Members that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {membersFindFirstOrThrowArgs} args - Arguments to find a Members
     * @example
     * // Get one Members
     * const members = await prisma.members.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends membersFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, membersFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__membersClient<$Result.GetResult<Prisma.$membersPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more Members that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {membersFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Members
     * const members = await prisma.members.findMany()
     * 
     * // Get first 10 Members
     * const members = await prisma.members.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const membersWithIdOnly = await prisma.members.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends membersFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, membersFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$membersPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a Members.
     * @param {membersCreateArgs} args - Arguments to create a Members.
     * @example
     * // Create one Members
     * const Members = await prisma.members.create({
     *   data: {
     *     // ... data to create a Members
     *   }
     * })
     * 
    **/
    create<T extends membersCreateArgs<ExtArgs>>(
      args: SelectSubset<T, membersCreateArgs<ExtArgs>>
    ): Prisma__membersClient<$Result.GetResult<Prisma.$membersPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many Members.
     * @param {membersCreateManyArgs} args - Arguments to create many Members.
     * @example
     * // Create many Members
     * const members = await prisma.members.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
    **/
    createMany<T extends membersCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, membersCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Members.
     * @param {membersDeleteArgs} args - Arguments to delete one Members.
     * @example
     * // Delete one Members
     * const Members = await prisma.members.delete({
     *   where: {
     *     // ... filter to delete one Members
     *   }
     * })
     * 
    **/
    delete<T extends membersDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, membersDeleteArgs<ExtArgs>>
    ): Prisma__membersClient<$Result.GetResult<Prisma.$membersPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one Members.
     * @param {membersUpdateArgs} args - Arguments to update one Members.
     * @example
     * // Update one Members
     * const members = await prisma.members.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends membersUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, membersUpdateArgs<ExtArgs>>
    ): Prisma__membersClient<$Result.GetResult<Prisma.$membersPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more Members.
     * @param {membersDeleteManyArgs} args - Arguments to filter Members to delete.
     * @example
     * // Delete a few Members
     * const { count } = await prisma.members.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends membersDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, membersDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Members.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {membersUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Members
     * const members = await prisma.members.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends membersUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, membersUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Members.
     * @param {membersUpsertArgs} args - Arguments to update or create a Members.
     * @example
     * // Update or create a Members
     * const members = await prisma.members.upsert({
     *   create: {
     *     // ... data to create a Members
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Members we want to update
     *   }
     * })
    **/
    upsert<T extends membersUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, membersUpsertArgs<ExtArgs>>
    ): Prisma__membersClient<$Result.GetResult<Prisma.$membersPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of Members.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {membersCountArgs} args - Arguments to filter Members to count.
     * @example
     * // Count the number of Members
     * const count = await prisma.members.count({
     *   where: {
     *     // ... the filter for the Members we want to count
     *   }
     * })
    **/
    count<T extends membersCountArgs>(
      args?: Subset<T, membersCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], MembersCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Members.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MembersAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends MembersAggregateArgs>(args: Subset<T, MembersAggregateArgs>): Prisma.PrismaPromise<GetMembersAggregateType<T>>

    /**
     * Group by Members.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {membersGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends membersGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: membersGroupByArgs['orderBy'] }
        : { orderBy?: membersGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, membersGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetMembersGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the members model
   */
  readonly fields: membersFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for members.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__membersClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';


    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the members model
   */ 
  interface membersFieldRefs {
    readonly id: FieldRef<"members", 'String'>
    readonly name: FieldRef<"members", 'String'>
    readonly family: FieldRef<"members", 'String'>
    readonly nationalCode: FieldRef<"members", 'String'>
    readonly fatherName: FieldRef<"members", 'String'>
    readonly disabilityStatus: FieldRef<"members", 'Int'>
    readonly disabilityDescription: FieldRef<"members", 'String'>
    readonly partnerJob: FieldRef<"members", 'String'>
    readonly educationLevel: FieldRef<"members", 'Int'>
    readonly maritalStatus: FieldRef<"members", 'Int'>
    readonly childrenCounts: FieldRef<"members", 'Int'>
    readonly birthDate: FieldRef<"members", 'String'>
    readonly mobileNumber: FieldRef<"members", 'String'>
    readonly address: FieldRef<"members", 'String'>
    readonly username: FieldRef<"members", 'String'>
    readonly password: FieldRef<"members", 'String'>
    readonly status: FieldRef<"members", 'Int'>
    readonly creationTime: FieldRef<"members", 'DateTime'>
    readonly creatorId: FieldRef<"members", 'String'>
    readonly isDeleted: FieldRef<"members", 'Boolean'>
  }
    

  // Custom InputTypes
  /**
   * members findUnique
   */
  export type membersFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the members
     */
    select?: membersSelect<ExtArgs> | null
    /**
     * Filter, which members to fetch.
     */
    where: membersWhereUniqueInput
  }

  /**
   * members findUniqueOrThrow
   */
  export type membersFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the members
     */
    select?: membersSelect<ExtArgs> | null
    /**
     * Filter, which members to fetch.
     */
    where: membersWhereUniqueInput
  }

  /**
   * members findFirst
   */
  export type membersFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the members
     */
    select?: membersSelect<ExtArgs> | null
    /**
     * Filter, which members to fetch.
     */
    where?: membersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of members to fetch.
     */
    orderBy?: membersOrderByWithRelationInput | membersOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for members.
     */
    cursor?: membersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` members from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` members.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of members.
     */
    distinct?: MembersScalarFieldEnum | MembersScalarFieldEnum[]
  }

  /**
   * members findFirstOrThrow
   */
  export type membersFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the members
     */
    select?: membersSelect<ExtArgs> | null
    /**
     * Filter, which members to fetch.
     */
    where?: membersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of members to fetch.
     */
    orderBy?: membersOrderByWithRelationInput | membersOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for members.
     */
    cursor?: membersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` members from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` members.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of members.
     */
    distinct?: MembersScalarFieldEnum | MembersScalarFieldEnum[]
  }

  /**
   * members findMany
   */
  export type membersFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the members
     */
    select?: membersSelect<ExtArgs> | null
    /**
     * Filter, which members to fetch.
     */
    where?: membersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of members to fetch.
     */
    orderBy?: membersOrderByWithRelationInput | membersOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing members.
     */
    cursor?: membersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` members from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` members.
     */
    skip?: number
    distinct?: MembersScalarFieldEnum | MembersScalarFieldEnum[]
  }

  /**
   * members create
   */
  export type membersCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the members
     */
    select?: membersSelect<ExtArgs> | null
    /**
     * The data needed to create a members.
     */
    data: XOR<membersCreateInput, membersUncheckedCreateInput>
  }

  /**
   * members createMany
   */
  export type membersCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many members.
     */
    data: membersCreateManyInput | membersCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * members update
   */
  export type membersUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the members
     */
    select?: membersSelect<ExtArgs> | null
    /**
     * The data needed to update a members.
     */
    data: XOR<membersUpdateInput, membersUncheckedUpdateInput>
    /**
     * Choose, which members to update.
     */
    where: membersWhereUniqueInput
  }

  /**
   * members updateMany
   */
  export type membersUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update members.
     */
    data: XOR<membersUpdateManyMutationInput, membersUncheckedUpdateManyInput>
    /**
     * Filter which members to update
     */
    where?: membersWhereInput
  }

  /**
   * members upsert
   */
  export type membersUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the members
     */
    select?: membersSelect<ExtArgs> | null
    /**
     * The filter to search for the members to update in case it exists.
     */
    where: membersWhereUniqueInput
    /**
     * In case the members found by the `where` argument doesn't exist, create a new members with this data.
     */
    create: XOR<membersCreateInput, membersUncheckedCreateInput>
    /**
     * In case the members was found with the provided `where` argument, update it with this data.
     */
    update: XOR<membersUpdateInput, membersUncheckedUpdateInput>
  }

  /**
   * members delete
   */
  export type membersDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the members
     */
    select?: membersSelect<ExtArgs> | null
    /**
     * Filter which members to delete.
     */
    where: membersWhereUniqueInput
  }

  /**
   * members deleteMany
   */
  export type membersDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which members to delete
     */
    where?: membersWhereInput
  }

  /**
   * members without action
   */
  export type membersDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the members
     */
    select?: membersSelect<ExtArgs> | null
  }


  /**
   * Model members_product_items
   */

  export type AggregateMembers_product_items = {
    _count: Members_product_itemsCountAggregateOutputType | null
    _min: Members_product_itemsMinAggregateOutputType | null
    _max: Members_product_itemsMaxAggregateOutputType | null
  }

  export type Members_product_itemsMinAggregateOutputType = {
    id: string | null
    parentMemberId: string | null
    title: string | null
    ownProduct: boolean | null
  }

  export type Members_product_itemsMaxAggregateOutputType = {
    id: string | null
    parentMemberId: string | null
    title: string | null
    ownProduct: boolean | null
  }

  export type Members_product_itemsCountAggregateOutputType = {
    id: number
    parentMemberId: number
    title: number
    ownProduct: number
    _all: number
  }


  export type Members_product_itemsMinAggregateInputType = {
    id?: true
    parentMemberId?: true
    title?: true
    ownProduct?: true
  }

  export type Members_product_itemsMaxAggregateInputType = {
    id?: true
    parentMemberId?: true
    title?: true
    ownProduct?: true
  }

  export type Members_product_itemsCountAggregateInputType = {
    id?: true
    parentMemberId?: true
    title?: true
    ownProduct?: true
    _all?: true
  }

  export type Members_product_itemsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which members_product_items to aggregate.
     */
    where?: members_product_itemsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of members_product_items to fetch.
     */
    orderBy?: members_product_itemsOrderByWithRelationInput | members_product_itemsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: members_product_itemsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` members_product_items from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` members_product_items.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned members_product_items
    **/
    _count?: true | Members_product_itemsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Members_product_itemsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Members_product_itemsMaxAggregateInputType
  }

  export type GetMembers_product_itemsAggregateType<T extends Members_product_itemsAggregateArgs> = {
        [P in keyof T & keyof AggregateMembers_product_items]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateMembers_product_items[P]>
      : GetScalarType<T[P], AggregateMembers_product_items[P]>
  }




  export type members_product_itemsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: members_product_itemsWhereInput
    orderBy?: members_product_itemsOrderByWithAggregationInput | members_product_itemsOrderByWithAggregationInput[]
    by: Members_product_itemsScalarFieldEnum[] | Members_product_itemsScalarFieldEnum
    having?: members_product_itemsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Members_product_itemsCountAggregateInputType | true
    _min?: Members_product_itemsMinAggregateInputType
    _max?: Members_product_itemsMaxAggregateInputType
  }

  export type Members_product_itemsGroupByOutputType = {
    id: string
    parentMemberId: string
    title: string
    ownProduct: boolean
    _count: Members_product_itemsCountAggregateOutputType | null
    _min: Members_product_itemsMinAggregateOutputType | null
    _max: Members_product_itemsMaxAggregateOutputType | null
  }

  type GetMembers_product_itemsGroupByPayload<T extends members_product_itemsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Members_product_itemsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Members_product_itemsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Members_product_itemsGroupByOutputType[P]>
            : GetScalarType<T[P], Members_product_itemsGroupByOutputType[P]>
        }
      >
    >


  export type members_product_itemsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    parentMemberId?: boolean
    title?: boolean
    ownProduct?: boolean
  }, ExtArgs["result"]["members_product_items"]>


  export type members_product_itemsSelectScalar = {
    id?: boolean
    parentMemberId?: boolean
    title?: boolean
    ownProduct?: boolean
  }


  export type $members_product_itemsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "members_product_items"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      parentMemberId: string
      title: string
      ownProduct: boolean
    }, ExtArgs["result"]["members_product_items"]>
    composites: {}
  }

  type members_product_itemsGetPayload<S extends boolean | null | undefined | members_product_itemsDefaultArgs> = $Result.GetResult<Prisma.$members_product_itemsPayload, S>

  type members_product_itemsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<members_product_itemsFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: Members_product_itemsCountAggregateInputType | true
    }

  export interface members_product_itemsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['members_product_items'], meta: { name: 'members_product_items' } }
    /**
     * Find zero or one Members_product_items that matches the filter.
     * @param {members_product_itemsFindUniqueArgs} args - Arguments to find a Members_product_items
     * @example
     * // Get one Members_product_items
     * const members_product_items = await prisma.members_product_items.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends members_product_itemsFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, members_product_itemsFindUniqueArgs<ExtArgs>>
    ): Prisma__members_product_itemsClient<$Result.GetResult<Prisma.$members_product_itemsPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one Members_product_items that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {members_product_itemsFindUniqueOrThrowArgs} args - Arguments to find a Members_product_items
     * @example
     * // Get one Members_product_items
     * const members_product_items = await prisma.members_product_items.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends members_product_itemsFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, members_product_itemsFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__members_product_itemsClient<$Result.GetResult<Prisma.$members_product_itemsPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first Members_product_items that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {members_product_itemsFindFirstArgs} args - Arguments to find a Members_product_items
     * @example
     * // Get one Members_product_items
     * const members_product_items = await prisma.members_product_items.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends members_product_itemsFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, members_product_itemsFindFirstArgs<ExtArgs>>
    ): Prisma__members_product_itemsClient<$Result.GetResult<Prisma.$members_product_itemsPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first Members_product_items that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {members_product_itemsFindFirstOrThrowArgs} args - Arguments to find a Members_product_items
     * @example
     * // Get one Members_product_items
     * const members_product_items = await prisma.members_product_items.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends members_product_itemsFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, members_product_itemsFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__members_product_itemsClient<$Result.GetResult<Prisma.$members_product_itemsPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more Members_product_items that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {members_product_itemsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Members_product_items
     * const members_product_items = await prisma.members_product_items.findMany()
     * 
     * // Get first 10 Members_product_items
     * const members_product_items = await prisma.members_product_items.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const members_product_itemsWithIdOnly = await prisma.members_product_items.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends members_product_itemsFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, members_product_itemsFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$members_product_itemsPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a Members_product_items.
     * @param {members_product_itemsCreateArgs} args - Arguments to create a Members_product_items.
     * @example
     * // Create one Members_product_items
     * const Members_product_items = await prisma.members_product_items.create({
     *   data: {
     *     // ... data to create a Members_product_items
     *   }
     * })
     * 
    **/
    create<T extends members_product_itemsCreateArgs<ExtArgs>>(
      args: SelectSubset<T, members_product_itemsCreateArgs<ExtArgs>>
    ): Prisma__members_product_itemsClient<$Result.GetResult<Prisma.$members_product_itemsPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many Members_product_items.
     * @param {members_product_itemsCreateManyArgs} args - Arguments to create many Members_product_items.
     * @example
     * // Create many Members_product_items
     * const members_product_items = await prisma.members_product_items.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
    **/
    createMany<T extends members_product_itemsCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, members_product_itemsCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Members_product_items.
     * @param {members_product_itemsDeleteArgs} args - Arguments to delete one Members_product_items.
     * @example
     * // Delete one Members_product_items
     * const Members_product_items = await prisma.members_product_items.delete({
     *   where: {
     *     // ... filter to delete one Members_product_items
     *   }
     * })
     * 
    **/
    delete<T extends members_product_itemsDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, members_product_itemsDeleteArgs<ExtArgs>>
    ): Prisma__members_product_itemsClient<$Result.GetResult<Prisma.$members_product_itemsPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one Members_product_items.
     * @param {members_product_itemsUpdateArgs} args - Arguments to update one Members_product_items.
     * @example
     * // Update one Members_product_items
     * const members_product_items = await prisma.members_product_items.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends members_product_itemsUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, members_product_itemsUpdateArgs<ExtArgs>>
    ): Prisma__members_product_itemsClient<$Result.GetResult<Prisma.$members_product_itemsPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more Members_product_items.
     * @param {members_product_itemsDeleteManyArgs} args - Arguments to filter Members_product_items to delete.
     * @example
     * // Delete a few Members_product_items
     * const { count } = await prisma.members_product_items.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends members_product_itemsDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, members_product_itemsDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Members_product_items.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {members_product_itemsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Members_product_items
     * const members_product_items = await prisma.members_product_items.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends members_product_itemsUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, members_product_itemsUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Members_product_items.
     * @param {members_product_itemsUpsertArgs} args - Arguments to update or create a Members_product_items.
     * @example
     * // Update or create a Members_product_items
     * const members_product_items = await prisma.members_product_items.upsert({
     *   create: {
     *     // ... data to create a Members_product_items
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Members_product_items we want to update
     *   }
     * })
    **/
    upsert<T extends members_product_itemsUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, members_product_itemsUpsertArgs<ExtArgs>>
    ): Prisma__members_product_itemsClient<$Result.GetResult<Prisma.$members_product_itemsPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of Members_product_items.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {members_product_itemsCountArgs} args - Arguments to filter Members_product_items to count.
     * @example
     * // Count the number of Members_product_items
     * const count = await prisma.members_product_items.count({
     *   where: {
     *     // ... the filter for the Members_product_items we want to count
     *   }
     * })
    **/
    count<T extends members_product_itemsCountArgs>(
      args?: Subset<T, members_product_itemsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Members_product_itemsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Members_product_items.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Members_product_itemsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Members_product_itemsAggregateArgs>(args: Subset<T, Members_product_itemsAggregateArgs>): Prisma.PrismaPromise<GetMembers_product_itemsAggregateType<T>>

    /**
     * Group by Members_product_items.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {members_product_itemsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends members_product_itemsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: members_product_itemsGroupByArgs['orderBy'] }
        : { orderBy?: members_product_itemsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, members_product_itemsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetMembers_product_itemsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the members_product_items model
   */
  readonly fields: members_product_itemsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for members_product_items.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__members_product_itemsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';


    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the members_product_items model
   */ 
  interface members_product_itemsFieldRefs {
    readonly id: FieldRef<"members_product_items", 'String'>
    readonly parentMemberId: FieldRef<"members_product_items", 'String'>
    readonly title: FieldRef<"members_product_items", 'String'>
    readonly ownProduct: FieldRef<"members_product_items", 'Boolean'>
  }
    

  // Custom InputTypes
  /**
   * members_product_items findUnique
   */
  export type members_product_itemsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the members_product_items
     */
    select?: members_product_itemsSelect<ExtArgs> | null
    /**
     * Filter, which members_product_items to fetch.
     */
    where: members_product_itemsWhereUniqueInput
  }

  /**
   * members_product_items findUniqueOrThrow
   */
  export type members_product_itemsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the members_product_items
     */
    select?: members_product_itemsSelect<ExtArgs> | null
    /**
     * Filter, which members_product_items to fetch.
     */
    where: members_product_itemsWhereUniqueInput
  }

  /**
   * members_product_items findFirst
   */
  export type members_product_itemsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the members_product_items
     */
    select?: members_product_itemsSelect<ExtArgs> | null
    /**
     * Filter, which members_product_items to fetch.
     */
    where?: members_product_itemsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of members_product_items to fetch.
     */
    orderBy?: members_product_itemsOrderByWithRelationInput | members_product_itemsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for members_product_items.
     */
    cursor?: members_product_itemsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` members_product_items from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` members_product_items.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of members_product_items.
     */
    distinct?: Members_product_itemsScalarFieldEnum | Members_product_itemsScalarFieldEnum[]
  }

  /**
   * members_product_items findFirstOrThrow
   */
  export type members_product_itemsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the members_product_items
     */
    select?: members_product_itemsSelect<ExtArgs> | null
    /**
     * Filter, which members_product_items to fetch.
     */
    where?: members_product_itemsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of members_product_items to fetch.
     */
    orderBy?: members_product_itemsOrderByWithRelationInput | members_product_itemsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for members_product_items.
     */
    cursor?: members_product_itemsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` members_product_items from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` members_product_items.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of members_product_items.
     */
    distinct?: Members_product_itemsScalarFieldEnum | Members_product_itemsScalarFieldEnum[]
  }

  /**
   * members_product_items findMany
   */
  export type members_product_itemsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the members_product_items
     */
    select?: members_product_itemsSelect<ExtArgs> | null
    /**
     * Filter, which members_product_items to fetch.
     */
    where?: members_product_itemsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of members_product_items to fetch.
     */
    orderBy?: members_product_itemsOrderByWithRelationInput | members_product_itemsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing members_product_items.
     */
    cursor?: members_product_itemsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` members_product_items from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` members_product_items.
     */
    skip?: number
    distinct?: Members_product_itemsScalarFieldEnum | Members_product_itemsScalarFieldEnum[]
  }

  /**
   * members_product_items create
   */
  export type members_product_itemsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the members_product_items
     */
    select?: members_product_itemsSelect<ExtArgs> | null
    /**
     * The data needed to create a members_product_items.
     */
    data: XOR<members_product_itemsCreateInput, members_product_itemsUncheckedCreateInput>
  }

  /**
   * members_product_items createMany
   */
  export type members_product_itemsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many members_product_items.
     */
    data: members_product_itemsCreateManyInput | members_product_itemsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * members_product_items update
   */
  export type members_product_itemsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the members_product_items
     */
    select?: members_product_itemsSelect<ExtArgs> | null
    /**
     * The data needed to update a members_product_items.
     */
    data: XOR<members_product_itemsUpdateInput, members_product_itemsUncheckedUpdateInput>
    /**
     * Choose, which members_product_items to update.
     */
    where: members_product_itemsWhereUniqueInput
  }

  /**
   * members_product_items updateMany
   */
  export type members_product_itemsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update members_product_items.
     */
    data: XOR<members_product_itemsUpdateManyMutationInput, members_product_itemsUncheckedUpdateManyInput>
    /**
     * Filter which members_product_items to update
     */
    where?: members_product_itemsWhereInput
  }

  /**
   * members_product_items upsert
   */
  export type members_product_itemsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the members_product_items
     */
    select?: members_product_itemsSelect<ExtArgs> | null
    /**
     * The filter to search for the members_product_items to update in case it exists.
     */
    where: members_product_itemsWhereUniqueInput
    /**
     * In case the members_product_items found by the `where` argument doesn't exist, create a new members_product_items with this data.
     */
    create: XOR<members_product_itemsCreateInput, members_product_itemsUncheckedCreateInput>
    /**
     * In case the members_product_items was found with the provided `where` argument, update it with this data.
     */
    update: XOR<members_product_itemsUpdateInput, members_product_itemsUncheckedUpdateInput>
  }

  /**
   * members_product_items delete
   */
  export type members_product_itemsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the members_product_items
     */
    select?: members_product_itemsSelect<ExtArgs> | null
    /**
     * Filter which members_product_items to delete.
     */
    where: members_product_itemsWhereUniqueInput
  }

  /**
   * members_product_items deleteMany
   */
  export type members_product_itemsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which members_product_items to delete
     */
    where?: members_product_itemsWhereInput
  }

  /**
   * members_product_items without action
   */
  export type members_product_itemsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the members_product_items
     */
    select?: members_product_itemsSelect<ExtArgs> | null
  }


  /**
   * Model imageSlider
   */

  export type AggregateImageSlider = {
    _count: ImageSliderCountAggregateOutputType | null
    _min: ImageSliderMinAggregateOutputType | null
    _max: ImageSliderMaxAggregateOutputType | null
  }

  export type ImageSliderMinAggregateOutputType = {
    id: string | null
    fileId: string | null
    title: string | null
    creationTime: Date | null
    creatorId: string | null
  }

  export type ImageSliderMaxAggregateOutputType = {
    id: string | null
    fileId: string | null
    title: string | null
    creationTime: Date | null
    creatorId: string | null
  }

  export type ImageSliderCountAggregateOutputType = {
    id: number
    fileId: number
    title: number
    creationTime: number
    creatorId: number
    _all: number
  }


  export type ImageSliderMinAggregateInputType = {
    id?: true
    fileId?: true
    title?: true
    creationTime?: true
    creatorId?: true
  }

  export type ImageSliderMaxAggregateInputType = {
    id?: true
    fileId?: true
    title?: true
    creationTime?: true
    creatorId?: true
  }

  export type ImageSliderCountAggregateInputType = {
    id?: true
    fileId?: true
    title?: true
    creationTime?: true
    creatorId?: true
    _all?: true
  }

  export type ImageSliderAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which imageSlider to aggregate.
     */
    where?: imageSliderWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of imageSliders to fetch.
     */
    orderBy?: imageSliderOrderByWithRelationInput | imageSliderOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: imageSliderWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` imageSliders from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` imageSliders.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned imageSliders
    **/
    _count?: true | ImageSliderCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ImageSliderMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ImageSliderMaxAggregateInputType
  }

  export type GetImageSliderAggregateType<T extends ImageSliderAggregateArgs> = {
        [P in keyof T & keyof AggregateImageSlider]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateImageSlider[P]>
      : GetScalarType<T[P], AggregateImageSlider[P]>
  }




  export type imageSliderGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: imageSliderWhereInput
    orderBy?: imageSliderOrderByWithAggregationInput | imageSliderOrderByWithAggregationInput[]
    by: ImageSliderScalarFieldEnum[] | ImageSliderScalarFieldEnum
    having?: imageSliderScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ImageSliderCountAggregateInputType | true
    _min?: ImageSliderMinAggregateInputType
    _max?: ImageSliderMaxAggregateInputType
  }

  export type ImageSliderGroupByOutputType = {
    id: string
    fileId: string
    title: string
    creationTime: Date
    creatorId: string | null
    _count: ImageSliderCountAggregateOutputType | null
    _min: ImageSliderMinAggregateOutputType | null
    _max: ImageSliderMaxAggregateOutputType | null
  }

  type GetImageSliderGroupByPayload<T extends imageSliderGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ImageSliderGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ImageSliderGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ImageSliderGroupByOutputType[P]>
            : GetScalarType<T[P], ImageSliderGroupByOutputType[P]>
        }
      >
    >


  export type imageSliderSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    fileId?: boolean
    title?: boolean
    creationTime?: boolean
    creatorId?: boolean
  }, ExtArgs["result"]["imageSlider"]>


  export type imageSliderSelectScalar = {
    id?: boolean
    fileId?: boolean
    title?: boolean
    creationTime?: boolean
    creatorId?: boolean
  }


  export type $imageSliderPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "imageSlider"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      fileId: string
      title: string
      creationTime: Date
      creatorId: string | null
    }, ExtArgs["result"]["imageSlider"]>
    composites: {}
  }

  type imageSliderGetPayload<S extends boolean | null | undefined | imageSliderDefaultArgs> = $Result.GetResult<Prisma.$imageSliderPayload, S>

  type imageSliderCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<imageSliderFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: ImageSliderCountAggregateInputType | true
    }

  export interface imageSliderDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['imageSlider'], meta: { name: 'imageSlider' } }
    /**
     * Find zero or one ImageSlider that matches the filter.
     * @param {imageSliderFindUniqueArgs} args - Arguments to find a ImageSlider
     * @example
     * // Get one ImageSlider
     * const imageSlider = await prisma.imageSlider.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends imageSliderFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, imageSliderFindUniqueArgs<ExtArgs>>
    ): Prisma__imageSliderClient<$Result.GetResult<Prisma.$imageSliderPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one ImageSlider that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {imageSliderFindUniqueOrThrowArgs} args - Arguments to find a ImageSlider
     * @example
     * // Get one ImageSlider
     * const imageSlider = await prisma.imageSlider.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends imageSliderFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, imageSliderFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__imageSliderClient<$Result.GetResult<Prisma.$imageSliderPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first ImageSlider that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {imageSliderFindFirstArgs} args - Arguments to find a ImageSlider
     * @example
     * // Get one ImageSlider
     * const imageSlider = await prisma.imageSlider.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends imageSliderFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, imageSliderFindFirstArgs<ExtArgs>>
    ): Prisma__imageSliderClient<$Result.GetResult<Prisma.$imageSliderPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first ImageSlider that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {imageSliderFindFirstOrThrowArgs} args - Arguments to find a ImageSlider
     * @example
     * // Get one ImageSlider
     * const imageSlider = await prisma.imageSlider.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends imageSliderFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, imageSliderFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__imageSliderClient<$Result.GetResult<Prisma.$imageSliderPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more ImageSliders that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {imageSliderFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all ImageSliders
     * const imageSliders = await prisma.imageSlider.findMany()
     * 
     * // Get first 10 ImageSliders
     * const imageSliders = await prisma.imageSlider.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const imageSliderWithIdOnly = await prisma.imageSlider.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends imageSliderFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, imageSliderFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$imageSliderPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a ImageSlider.
     * @param {imageSliderCreateArgs} args - Arguments to create a ImageSlider.
     * @example
     * // Create one ImageSlider
     * const ImageSlider = await prisma.imageSlider.create({
     *   data: {
     *     // ... data to create a ImageSlider
     *   }
     * })
     * 
    **/
    create<T extends imageSliderCreateArgs<ExtArgs>>(
      args: SelectSubset<T, imageSliderCreateArgs<ExtArgs>>
    ): Prisma__imageSliderClient<$Result.GetResult<Prisma.$imageSliderPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many ImageSliders.
     * @param {imageSliderCreateManyArgs} args - Arguments to create many ImageSliders.
     * @example
     * // Create many ImageSliders
     * const imageSlider = await prisma.imageSlider.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
    **/
    createMany<T extends imageSliderCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, imageSliderCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a ImageSlider.
     * @param {imageSliderDeleteArgs} args - Arguments to delete one ImageSlider.
     * @example
     * // Delete one ImageSlider
     * const ImageSlider = await prisma.imageSlider.delete({
     *   where: {
     *     // ... filter to delete one ImageSlider
     *   }
     * })
     * 
    **/
    delete<T extends imageSliderDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, imageSliderDeleteArgs<ExtArgs>>
    ): Prisma__imageSliderClient<$Result.GetResult<Prisma.$imageSliderPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one ImageSlider.
     * @param {imageSliderUpdateArgs} args - Arguments to update one ImageSlider.
     * @example
     * // Update one ImageSlider
     * const imageSlider = await prisma.imageSlider.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends imageSliderUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, imageSliderUpdateArgs<ExtArgs>>
    ): Prisma__imageSliderClient<$Result.GetResult<Prisma.$imageSliderPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more ImageSliders.
     * @param {imageSliderDeleteManyArgs} args - Arguments to filter ImageSliders to delete.
     * @example
     * // Delete a few ImageSliders
     * const { count } = await prisma.imageSlider.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends imageSliderDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, imageSliderDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ImageSliders.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {imageSliderUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many ImageSliders
     * const imageSlider = await prisma.imageSlider.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends imageSliderUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, imageSliderUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one ImageSlider.
     * @param {imageSliderUpsertArgs} args - Arguments to update or create a ImageSlider.
     * @example
     * // Update or create a ImageSlider
     * const imageSlider = await prisma.imageSlider.upsert({
     *   create: {
     *     // ... data to create a ImageSlider
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the ImageSlider we want to update
     *   }
     * })
    **/
    upsert<T extends imageSliderUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, imageSliderUpsertArgs<ExtArgs>>
    ): Prisma__imageSliderClient<$Result.GetResult<Prisma.$imageSliderPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of ImageSliders.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {imageSliderCountArgs} args - Arguments to filter ImageSliders to count.
     * @example
     * // Count the number of ImageSliders
     * const count = await prisma.imageSlider.count({
     *   where: {
     *     // ... the filter for the ImageSliders we want to count
     *   }
     * })
    **/
    count<T extends imageSliderCountArgs>(
      args?: Subset<T, imageSliderCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ImageSliderCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a ImageSlider.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ImageSliderAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ImageSliderAggregateArgs>(args: Subset<T, ImageSliderAggregateArgs>): Prisma.PrismaPromise<GetImageSliderAggregateType<T>>

    /**
     * Group by ImageSlider.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {imageSliderGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends imageSliderGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: imageSliderGroupByArgs['orderBy'] }
        : { orderBy?: imageSliderGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, imageSliderGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetImageSliderGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the imageSlider model
   */
  readonly fields: imageSliderFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for imageSlider.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__imageSliderClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';


    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the imageSlider model
   */ 
  interface imageSliderFieldRefs {
    readonly id: FieldRef<"imageSlider", 'String'>
    readonly fileId: FieldRef<"imageSlider", 'String'>
    readonly title: FieldRef<"imageSlider", 'String'>
    readonly creationTime: FieldRef<"imageSlider", 'DateTime'>
    readonly creatorId: FieldRef<"imageSlider", 'String'>
  }
    

  // Custom InputTypes
  /**
   * imageSlider findUnique
   */
  export type imageSliderFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the imageSlider
     */
    select?: imageSliderSelect<ExtArgs> | null
    /**
     * Filter, which imageSlider to fetch.
     */
    where: imageSliderWhereUniqueInput
  }

  /**
   * imageSlider findUniqueOrThrow
   */
  export type imageSliderFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the imageSlider
     */
    select?: imageSliderSelect<ExtArgs> | null
    /**
     * Filter, which imageSlider to fetch.
     */
    where: imageSliderWhereUniqueInput
  }

  /**
   * imageSlider findFirst
   */
  export type imageSliderFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the imageSlider
     */
    select?: imageSliderSelect<ExtArgs> | null
    /**
     * Filter, which imageSlider to fetch.
     */
    where?: imageSliderWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of imageSliders to fetch.
     */
    orderBy?: imageSliderOrderByWithRelationInput | imageSliderOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for imageSliders.
     */
    cursor?: imageSliderWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` imageSliders from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` imageSliders.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of imageSliders.
     */
    distinct?: ImageSliderScalarFieldEnum | ImageSliderScalarFieldEnum[]
  }

  /**
   * imageSlider findFirstOrThrow
   */
  export type imageSliderFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the imageSlider
     */
    select?: imageSliderSelect<ExtArgs> | null
    /**
     * Filter, which imageSlider to fetch.
     */
    where?: imageSliderWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of imageSliders to fetch.
     */
    orderBy?: imageSliderOrderByWithRelationInput | imageSliderOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for imageSliders.
     */
    cursor?: imageSliderWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` imageSliders from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` imageSliders.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of imageSliders.
     */
    distinct?: ImageSliderScalarFieldEnum | ImageSliderScalarFieldEnum[]
  }

  /**
   * imageSlider findMany
   */
  export type imageSliderFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the imageSlider
     */
    select?: imageSliderSelect<ExtArgs> | null
    /**
     * Filter, which imageSliders to fetch.
     */
    where?: imageSliderWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of imageSliders to fetch.
     */
    orderBy?: imageSliderOrderByWithRelationInput | imageSliderOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing imageSliders.
     */
    cursor?: imageSliderWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` imageSliders from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` imageSliders.
     */
    skip?: number
    distinct?: ImageSliderScalarFieldEnum | ImageSliderScalarFieldEnum[]
  }

  /**
   * imageSlider create
   */
  export type imageSliderCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the imageSlider
     */
    select?: imageSliderSelect<ExtArgs> | null
    /**
     * The data needed to create a imageSlider.
     */
    data: XOR<imageSliderCreateInput, imageSliderUncheckedCreateInput>
  }

  /**
   * imageSlider createMany
   */
  export type imageSliderCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many imageSliders.
     */
    data: imageSliderCreateManyInput | imageSliderCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * imageSlider update
   */
  export type imageSliderUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the imageSlider
     */
    select?: imageSliderSelect<ExtArgs> | null
    /**
     * The data needed to update a imageSlider.
     */
    data: XOR<imageSliderUpdateInput, imageSliderUncheckedUpdateInput>
    /**
     * Choose, which imageSlider to update.
     */
    where: imageSliderWhereUniqueInput
  }

  /**
   * imageSlider updateMany
   */
  export type imageSliderUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update imageSliders.
     */
    data: XOR<imageSliderUpdateManyMutationInput, imageSliderUncheckedUpdateManyInput>
    /**
     * Filter which imageSliders to update
     */
    where?: imageSliderWhereInput
  }

  /**
   * imageSlider upsert
   */
  export type imageSliderUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the imageSlider
     */
    select?: imageSliderSelect<ExtArgs> | null
    /**
     * The filter to search for the imageSlider to update in case it exists.
     */
    where: imageSliderWhereUniqueInput
    /**
     * In case the imageSlider found by the `where` argument doesn't exist, create a new imageSlider with this data.
     */
    create: XOR<imageSliderCreateInput, imageSliderUncheckedCreateInput>
    /**
     * In case the imageSlider was found with the provided `where` argument, update it with this data.
     */
    update: XOR<imageSliderUpdateInput, imageSliderUncheckedUpdateInput>
  }

  /**
   * imageSlider delete
   */
  export type imageSliderDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the imageSlider
     */
    select?: imageSliderSelect<ExtArgs> | null
    /**
     * Filter which imageSlider to delete.
     */
    where: imageSliderWhereUniqueInput
  }

  /**
   * imageSlider deleteMany
   */
  export type imageSliderDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which imageSliders to delete
     */
    where?: imageSliderWhereInput
  }

  /**
   * imageSlider without action
   */
  export type imageSliderDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the imageSlider
     */
    select?: imageSliderSelect<ExtArgs> | null
  }


  /**
   * Model profileImageSlider
   */

  export type AggregateProfileImageSlider = {
    _count: ProfileImageSliderCountAggregateOutputType | null
    _min: ProfileImageSliderMinAggregateOutputType | null
    _max: ProfileImageSliderMaxAggregateOutputType | null
  }

  export type ProfileImageSliderMinAggregateOutputType = {
    id: string | null
    fileId: string | null
    targetUrl: string | null
    creationTime: Date | null
    creatorId: string | null
  }

  export type ProfileImageSliderMaxAggregateOutputType = {
    id: string | null
    fileId: string | null
    targetUrl: string | null
    creationTime: Date | null
    creatorId: string | null
  }

  export type ProfileImageSliderCountAggregateOutputType = {
    id: number
    fileId: number
    targetUrl: number
    creationTime: number
    creatorId: number
    _all: number
  }


  export type ProfileImageSliderMinAggregateInputType = {
    id?: true
    fileId?: true
    targetUrl?: true
    creationTime?: true
    creatorId?: true
  }

  export type ProfileImageSliderMaxAggregateInputType = {
    id?: true
    fileId?: true
    targetUrl?: true
    creationTime?: true
    creatorId?: true
  }

  export type ProfileImageSliderCountAggregateInputType = {
    id?: true
    fileId?: true
    targetUrl?: true
    creationTime?: true
    creatorId?: true
    _all?: true
  }

  export type ProfileImageSliderAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which profileImageSlider to aggregate.
     */
    where?: profileImageSliderWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of profileImageSliders to fetch.
     */
    orderBy?: profileImageSliderOrderByWithRelationInput | profileImageSliderOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: profileImageSliderWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` profileImageSliders from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` profileImageSliders.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned profileImageSliders
    **/
    _count?: true | ProfileImageSliderCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ProfileImageSliderMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ProfileImageSliderMaxAggregateInputType
  }

  export type GetProfileImageSliderAggregateType<T extends ProfileImageSliderAggregateArgs> = {
        [P in keyof T & keyof AggregateProfileImageSlider]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateProfileImageSlider[P]>
      : GetScalarType<T[P], AggregateProfileImageSlider[P]>
  }




  export type profileImageSliderGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: profileImageSliderWhereInput
    orderBy?: profileImageSliderOrderByWithAggregationInput | profileImageSliderOrderByWithAggregationInput[]
    by: ProfileImageSliderScalarFieldEnum[] | ProfileImageSliderScalarFieldEnum
    having?: profileImageSliderScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ProfileImageSliderCountAggregateInputType | true
    _min?: ProfileImageSliderMinAggregateInputType
    _max?: ProfileImageSliderMaxAggregateInputType
  }

  export type ProfileImageSliderGroupByOutputType = {
    id: string
    fileId: string
    targetUrl: string | null
    creationTime: Date
    creatorId: string | null
    _count: ProfileImageSliderCountAggregateOutputType | null
    _min: ProfileImageSliderMinAggregateOutputType | null
    _max: ProfileImageSliderMaxAggregateOutputType | null
  }

  type GetProfileImageSliderGroupByPayload<T extends profileImageSliderGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ProfileImageSliderGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ProfileImageSliderGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ProfileImageSliderGroupByOutputType[P]>
            : GetScalarType<T[P], ProfileImageSliderGroupByOutputType[P]>
        }
      >
    >


  export type profileImageSliderSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    fileId?: boolean
    targetUrl?: boolean
    creationTime?: boolean
    creatorId?: boolean
  }, ExtArgs["result"]["profileImageSlider"]>


  export type profileImageSliderSelectScalar = {
    id?: boolean
    fileId?: boolean
    targetUrl?: boolean
    creationTime?: boolean
    creatorId?: boolean
  }


  export type $profileImageSliderPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "profileImageSlider"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      fileId: string
      targetUrl: string | null
      creationTime: Date
      creatorId: string | null
    }, ExtArgs["result"]["profileImageSlider"]>
    composites: {}
  }

  type profileImageSliderGetPayload<S extends boolean | null | undefined | profileImageSliderDefaultArgs> = $Result.GetResult<Prisma.$profileImageSliderPayload, S>

  type profileImageSliderCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<profileImageSliderFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: ProfileImageSliderCountAggregateInputType | true
    }

  export interface profileImageSliderDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['profileImageSlider'], meta: { name: 'profileImageSlider' } }
    /**
     * Find zero or one ProfileImageSlider that matches the filter.
     * @param {profileImageSliderFindUniqueArgs} args - Arguments to find a ProfileImageSlider
     * @example
     * // Get one ProfileImageSlider
     * const profileImageSlider = await prisma.profileImageSlider.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends profileImageSliderFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, profileImageSliderFindUniqueArgs<ExtArgs>>
    ): Prisma__profileImageSliderClient<$Result.GetResult<Prisma.$profileImageSliderPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one ProfileImageSlider that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {profileImageSliderFindUniqueOrThrowArgs} args - Arguments to find a ProfileImageSlider
     * @example
     * // Get one ProfileImageSlider
     * const profileImageSlider = await prisma.profileImageSlider.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends profileImageSliderFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, profileImageSliderFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__profileImageSliderClient<$Result.GetResult<Prisma.$profileImageSliderPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first ProfileImageSlider that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {profileImageSliderFindFirstArgs} args - Arguments to find a ProfileImageSlider
     * @example
     * // Get one ProfileImageSlider
     * const profileImageSlider = await prisma.profileImageSlider.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends profileImageSliderFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, profileImageSliderFindFirstArgs<ExtArgs>>
    ): Prisma__profileImageSliderClient<$Result.GetResult<Prisma.$profileImageSliderPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first ProfileImageSlider that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {profileImageSliderFindFirstOrThrowArgs} args - Arguments to find a ProfileImageSlider
     * @example
     * // Get one ProfileImageSlider
     * const profileImageSlider = await prisma.profileImageSlider.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends profileImageSliderFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, profileImageSliderFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__profileImageSliderClient<$Result.GetResult<Prisma.$profileImageSliderPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more ProfileImageSliders that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {profileImageSliderFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all ProfileImageSliders
     * const profileImageSliders = await prisma.profileImageSlider.findMany()
     * 
     * // Get first 10 ProfileImageSliders
     * const profileImageSliders = await prisma.profileImageSlider.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const profileImageSliderWithIdOnly = await prisma.profileImageSlider.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends profileImageSliderFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, profileImageSliderFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$profileImageSliderPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a ProfileImageSlider.
     * @param {profileImageSliderCreateArgs} args - Arguments to create a ProfileImageSlider.
     * @example
     * // Create one ProfileImageSlider
     * const ProfileImageSlider = await prisma.profileImageSlider.create({
     *   data: {
     *     // ... data to create a ProfileImageSlider
     *   }
     * })
     * 
    **/
    create<T extends profileImageSliderCreateArgs<ExtArgs>>(
      args: SelectSubset<T, profileImageSliderCreateArgs<ExtArgs>>
    ): Prisma__profileImageSliderClient<$Result.GetResult<Prisma.$profileImageSliderPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many ProfileImageSliders.
     * @param {profileImageSliderCreateManyArgs} args - Arguments to create many ProfileImageSliders.
     * @example
     * // Create many ProfileImageSliders
     * const profileImageSlider = await prisma.profileImageSlider.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
    **/
    createMany<T extends profileImageSliderCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, profileImageSliderCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a ProfileImageSlider.
     * @param {profileImageSliderDeleteArgs} args - Arguments to delete one ProfileImageSlider.
     * @example
     * // Delete one ProfileImageSlider
     * const ProfileImageSlider = await prisma.profileImageSlider.delete({
     *   where: {
     *     // ... filter to delete one ProfileImageSlider
     *   }
     * })
     * 
    **/
    delete<T extends profileImageSliderDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, profileImageSliderDeleteArgs<ExtArgs>>
    ): Prisma__profileImageSliderClient<$Result.GetResult<Prisma.$profileImageSliderPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one ProfileImageSlider.
     * @param {profileImageSliderUpdateArgs} args - Arguments to update one ProfileImageSlider.
     * @example
     * // Update one ProfileImageSlider
     * const profileImageSlider = await prisma.profileImageSlider.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends profileImageSliderUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, profileImageSliderUpdateArgs<ExtArgs>>
    ): Prisma__profileImageSliderClient<$Result.GetResult<Prisma.$profileImageSliderPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more ProfileImageSliders.
     * @param {profileImageSliderDeleteManyArgs} args - Arguments to filter ProfileImageSliders to delete.
     * @example
     * // Delete a few ProfileImageSliders
     * const { count } = await prisma.profileImageSlider.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends profileImageSliderDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, profileImageSliderDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ProfileImageSliders.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {profileImageSliderUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many ProfileImageSliders
     * const profileImageSlider = await prisma.profileImageSlider.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends profileImageSliderUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, profileImageSliderUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one ProfileImageSlider.
     * @param {profileImageSliderUpsertArgs} args - Arguments to update or create a ProfileImageSlider.
     * @example
     * // Update or create a ProfileImageSlider
     * const profileImageSlider = await prisma.profileImageSlider.upsert({
     *   create: {
     *     // ... data to create a ProfileImageSlider
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the ProfileImageSlider we want to update
     *   }
     * })
    **/
    upsert<T extends profileImageSliderUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, profileImageSliderUpsertArgs<ExtArgs>>
    ): Prisma__profileImageSliderClient<$Result.GetResult<Prisma.$profileImageSliderPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of ProfileImageSliders.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {profileImageSliderCountArgs} args - Arguments to filter ProfileImageSliders to count.
     * @example
     * // Count the number of ProfileImageSliders
     * const count = await prisma.profileImageSlider.count({
     *   where: {
     *     // ... the filter for the ProfileImageSliders we want to count
     *   }
     * })
    **/
    count<T extends profileImageSliderCountArgs>(
      args?: Subset<T, profileImageSliderCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ProfileImageSliderCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a ProfileImageSlider.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProfileImageSliderAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ProfileImageSliderAggregateArgs>(args: Subset<T, ProfileImageSliderAggregateArgs>): Prisma.PrismaPromise<GetProfileImageSliderAggregateType<T>>

    /**
     * Group by ProfileImageSlider.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {profileImageSliderGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends profileImageSliderGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: profileImageSliderGroupByArgs['orderBy'] }
        : { orderBy?: profileImageSliderGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, profileImageSliderGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetProfileImageSliderGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the profileImageSlider model
   */
  readonly fields: profileImageSliderFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for profileImageSlider.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__profileImageSliderClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';


    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the profileImageSlider model
   */ 
  interface profileImageSliderFieldRefs {
    readonly id: FieldRef<"profileImageSlider", 'String'>
    readonly fileId: FieldRef<"profileImageSlider", 'String'>
    readonly targetUrl: FieldRef<"profileImageSlider", 'String'>
    readonly creationTime: FieldRef<"profileImageSlider", 'DateTime'>
    readonly creatorId: FieldRef<"profileImageSlider", 'String'>
  }
    

  // Custom InputTypes
  /**
   * profileImageSlider findUnique
   */
  export type profileImageSliderFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the profileImageSlider
     */
    select?: profileImageSliderSelect<ExtArgs> | null
    /**
     * Filter, which profileImageSlider to fetch.
     */
    where: profileImageSliderWhereUniqueInput
  }

  /**
   * profileImageSlider findUniqueOrThrow
   */
  export type profileImageSliderFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the profileImageSlider
     */
    select?: profileImageSliderSelect<ExtArgs> | null
    /**
     * Filter, which profileImageSlider to fetch.
     */
    where: profileImageSliderWhereUniqueInput
  }

  /**
   * profileImageSlider findFirst
   */
  export type profileImageSliderFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the profileImageSlider
     */
    select?: profileImageSliderSelect<ExtArgs> | null
    /**
     * Filter, which profileImageSlider to fetch.
     */
    where?: profileImageSliderWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of profileImageSliders to fetch.
     */
    orderBy?: profileImageSliderOrderByWithRelationInput | profileImageSliderOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for profileImageSliders.
     */
    cursor?: profileImageSliderWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` profileImageSliders from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` profileImageSliders.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of profileImageSliders.
     */
    distinct?: ProfileImageSliderScalarFieldEnum | ProfileImageSliderScalarFieldEnum[]
  }

  /**
   * profileImageSlider findFirstOrThrow
   */
  export type profileImageSliderFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the profileImageSlider
     */
    select?: profileImageSliderSelect<ExtArgs> | null
    /**
     * Filter, which profileImageSlider to fetch.
     */
    where?: profileImageSliderWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of profileImageSliders to fetch.
     */
    orderBy?: profileImageSliderOrderByWithRelationInput | profileImageSliderOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for profileImageSliders.
     */
    cursor?: profileImageSliderWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` profileImageSliders from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` profileImageSliders.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of profileImageSliders.
     */
    distinct?: ProfileImageSliderScalarFieldEnum | ProfileImageSliderScalarFieldEnum[]
  }

  /**
   * profileImageSlider findMany
   */
  export type profileImageSliderFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the profileImageSlider
     */
    select?: profileImageSliderSelect<ExtArgs> | null
    /**
     * Filter, which profileImageSliders to fetch.
     */
    where?: profileImageSliderWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of profileImageSliders to fetch.
     */
    orderBy?: profileImageSliderOrderByWithRelationInput | profileImageSliderOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing profileImageSliders.
     */
    cursor?: profileImageSliderWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` profileImageSliders from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` profileImageSliders.
     */
    skip?: number
    distinct?: ProfileImageSliderScalarFieldEnum | ProfileImageSliderScalarFieldEnum[]
  }

  /**
   * profileImageSlider create
   */
  export type profileImageSliderCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the profileImageSlider
     */
    select?: profileImageSliderSelect<ExtArgs> | null
    /**
     * The data needed to create a profileImageSlider.
     */
    data: XOR<profileImageSliderCreateInput, profileImageSliderUncheckedCreateInput>
  }

  /**
   * profileImageSlider createMany
   */
  export type profileImageSliderCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many profileImageSliders.
     */
    data: profileImageSliderCreateManyInput | profileImageSliderCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * profileImageSlider update
   */
  export type profileImageSliderUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the profileImageSlider
     */
    select?: profileImageSliderSelect<ExtArgs> | null
    /**
     * The data needed to update a profileImageSlider.
     */
    data: XOR<profileImageSliderUpdateInput, profileImageSliderUncheckedUpdateInput>
    /**
     * Choose, which profileImageSlider to update.
     */
    where: profileImageSliderWhereUniqueInput
  }

  /**
   * profileImageSlider updateMany
   */
  export type profileImageSliderUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update profileImageSliders.
     */
    data: XOR<profileImageSliderUpdateManyMutationInput, profileImageSliderUncheckedUpdateManyInput>
    /**
     * Filter which profileImageSliders to update
     */
    where?: profileImageSliderWhereInput
  }

  /**
   * profileImageSlider upsert
   */
  export type profileImageSliderUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the profileImageSlider
     */
    select?: profileImageSliderSelect<ExtArgs> | null
    /**
     * The filter to search for the profileImageSlider to update in case it exists.
     */
    where: profileImageSliderWhereUniqueInput
    /**
     * In case the profileImageSlider found by the `where` argument doesn't exist, create a new profileImageSlider with this data.
     */
    create: XOR<profileImageSliderCreateInput, profileImageSliderUncheckedCreateInput>
    /**
     * In case the profileImageSlider was found with the provided `where` argument, update it with this data.
     */
    update: XOR<profileImageSliderUpdateInput, profileImageSliderUncheckedUpdateInput>
  }

  /**
   * profileImageSlider delete
   */
  export type profileImageSliderDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the profileImageSlider
     */
    select?: profileImageSliderSelect<ExtArgs> | null
    /**
     * Filter which profileImageSlider to delete.
     */
    where: profileImageSliderWhereUniqueInput
  }

  /**
   * profileImageSlider deleteMany
   */
  export type profileImageSliderDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which profileImageSliders to delete
     */
    where?: profileImageSliderWhereInput
  }

  /**
   * profileImageSlider without action
   */
  export type profileImageSliderDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the profileImageSlider
     */
    select?: profileImageSliderSelect<ExtArgs> | null
  }


  /**
   * Model upload_document_template
   */

  export type AggregateUpload_document_template = {
    _count: Upload_document_templateCountAggregateOutputType | null
    _avg: Upload_document_templateAvgAggregateOutputType | null
    _sum: Upload_document_templateSumAggregateOutputType | null
    _min: Upload_document_templateMinAggregateOutputType | null
    _max: Upload_document_templateMaxAggregateOutputType | null
  }

  export type Upload_document_templateAvgAggregateOutputType = {
    maximumSizeInMb: number | null
  }

  export type Upload_document_templateSumAggregateOutputType = {
    maximumSizeInMb: number | null
  }

  export type Upload_document_templateMinAggregateOutputType = {
    id: string | null
    title: string | null
    maximumSizeInMb: number | null
    isRequired: boolean | null
    showWhen: string | null
    creationTime: Date | null
    creatorId: string | null
  }

  export type Upload_document_templateMaxAggregateOutputType = {
    id: string | null
    title: string | null
    maximumSizeInMb: number | null
    isRequired: boolean | null
    showWhen: string | null
    creationTime: Date | null
    creatorId: string | null
  }

  export type Upload_document_templateCountAggregateOutputType = {
    id: number
    title: number
    maximumSizeInMb: number
    isRequired: number
    showWhen: number
    creationTime: number
    creatorId: number
    _all: number
  }


  export type Upload_document_templateAvgAggregateInputType = {
    maximumSizeInMb?: true
  }

  export type Upload_document_templateSumAggregateInputType = {
    maximumSizeInMb?: true
  }

  export type Upload_document_templateMinAggregateInputType = {
    id?: true
    title?: true
    maximumSizeInMb?: true
    isRequired?: true
    showWhen?: true
    creationTime?: true
    creatorId?: true
  }

  export type Upload_document_templateMaxAggregateInputType = {
    id?: true
    title?: true
    maximumSizeInMb?: true
    isRequired?: true
    showWhen?: true
    creationTime?: true
    creatorId?: true
  }

  export type Upload_document_templateCountAggregateInputType = {
    id?: true
    title?: true
    maximumSizeInMb?: true
    isRequired?: true
    showWhen?: true
    creationTime?: true
    creatorId?: true
    _all?: true
  }

  export type Upload_document_templateAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which upload_document_template to aggregate.
     */
    where?: upload_document_templateWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of upload_document_templates to fetch.
     */
    orderBy?: upload_document_templateOrderByWithRelationInput | upload_document_templateOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: upload_document_templateWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` upload_document_templates from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` upload_document_templates.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned upload_document_templates
    **/
    _count?: true | Upload_document_templateCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: Upload_document_templateAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: Upload_document_templateSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Upload_document_templateMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Upload_document_templateMaxAggregateInputType
  }

  export type GetUpload_document_templateAggregateType<T extends Upload_document_templateAggregateArgs> = {
        [P in keyof T & keyof AggregateUpload_document_template]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUpload_document_template[P]>
      : GetScalarType<T[P], AggregateUpload_document_template[P]>
  }




  export type upload_document_templateGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: upload_document_templateWhereInput
    orderBy?: upload_document_templateOrderByWithAggregationInput | upload_document_templateOrderByWithAggregationInput[]
    by: Upload_document_templateScalarFieldEnum[] | Upload_document_templateScalarFieldEnum
    having?: upload_document_templateScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Upload_document_templateCountAggregateInputType | true
    _avg?: Upload_document_templateAvgAggregateInputType
    _sum?: Upload_document_templateSumAggregateInputType
    _min?: Upload_document_templateMinAggregateInputType
    _max?: Upload_document_templateMaxAggregateInputType
  }

  export type Upload_document_templateGroupByOutputType = {
    id: string
    title: string
    maximumSizeInMb: number
    isRequired: boolean
    showWhen: string | null
    creationTime: Date
    creatorId: string | null
    _count: Upload_document_templateCountAggregateOutputType | null
    _avg: Upload_document_templateAvgAggregateOutputType | null
    _sum: Upload_document_templateSumAggregateOutputType | null
    _min: Upload_document_templateMinAggregateOutputType | null
    _max: Upload_document_templateMaxAggregateOutputType | null
  }

  type GetUpload_document_templateGroupByPayload<T extends upload_document_templateGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Upload_document_templateGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Upload_document_templateGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Upload_document_templateGroupByOutputType[P]>
            : GetScalarType<T[P], Upload_document_templateGroupByOutputType[P]>
        }
      >
    >


  export type upload_document_templateSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    title?: boolean
    maximumSizeInMb?: boolean
    isRequired?: boolean
    showWhen?: boolean
    creationTime?: boolean
    creatorId?: boolean
  }, ExtArgs["result"]["upload_document_template"]>


  export type upload_document_templateSelectScalar = {
    id?: boolean
    title?: boolean
    maximumSizeInMb?: boolean
    isRequired?: boolean
    showWhen?: boolean
    creationTime?: boolean
    creatorId?: boolean
  }


  export type $upload_document_templatePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "upload_document_template"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      title: string
      maximumSizeInMb: number
      isRequired: boolean
      showWhen: string | null
      creationTime: Date
      creatorId: string | null
    }, ExtArgs["result"]["upload_document_template"]>
    composites: {}
  }

  type upload_document_templateGetPayload<S extends boolean | null | undefined | upload_document_templateDefaultArgs> = $Result.GetResult<Prisma.$upload_document_templatePayload, S>

  type upload_document_templateCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<upload_document_templateFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: Upload_document_templateCountAggregateInputType | true
    }

  export interface upload_document_templateDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['upload_document_template'], meta: { name: 'upload_document_template' } }
    /**
     * Find zero or one Upload_document_template that matches the filter.
     * @param {upload_document_templateFindUniqueArgs} args - Arguments to find a Upload_document_template
     * @example
     * // Get one Upload_document_template
     * const upload_document_template = await prisma.upload_document_template.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends upload_document_templateFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, upload_document_templateFindUniqueArgs<ExtArgs>>
    ): Prisma__upload_document_templateClient<$Result.GetResult<Prisma.$upload_document_templatePayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one Upload_document_template that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {upload_document_templateFindUniqueOrThrowArgs} args - Arguments to find a Upload_document_template
     * @example
     * // Get one Upload_document_template
     * const upload_document_template = await prisma.upload_document_template.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends upload_document_templateFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, upload_document_templateFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__upload_document_templateClient<$Result.GetResult<Prisma.$upload_document_templatePayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first Upload_document_template that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {upload_document_templateFindFirstArgs} args - Arguments to find a Upload_document_template
     * @example
     * // Get one Upload_document_template
     * const upload_document_template = await prisma.upload_document_template.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends upload_document_templateFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, upload_document_templateFindFirstArgs<ExtArgs>>
    ): Prisma__upload_document_templateClient<$Result.GetResult<Prisma.$upload_document_templatePayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first Upload_document_template that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {upload_document_templateFindFirstOrThrowArgs} args - Arguments to find a Upload_document_template
     * @example
     * // Get one Upload_document_template
     * const upload_document_template = await prisma.upload_document_template.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends upload_document_templateFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, upload_document_templateFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__upload_document_templateClient<$Result.GetResult<Prisma.$upload_document_templatePayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more Upload_document_templates that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {upload_document_templateFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Upload_document_templates
     * const upload_document_templates = await prisma.upload_document_template.findMany()
     * 
     * // Get first 10 Upload_document_templates
     * const upload_document_templates = await prisma.upload_document_template.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const upload_document_templateWithIdOnly = await prisma.upload_document_template.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends upload_document_templateFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, upload_document_templateFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$upload_document_templatePayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a Upload_document_template.
     * @param {upload_document_templateCreateArgs} args - Arguments to create a Upload_document_template.
     * @example
     * // Create one Upload_document_template
     * const Upload_document_template = await prisma.upload_document_template.create({
     *   data: {
     *     // ... data to create a Upload_document_template
     *   }
     * })
     * 
    **/
    create<T extends upload_document_templateCreateArgs<ExtArgs>>(
      args: SelectSubset<T, upload_document_templateCreateArgs<ExtArgs>>
    ): Prisma__upload_document_templateClient<$Result.GetResult<Prisma.$upload_document_templatePayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many Upload_document_templates.
     * @param {upload_document_templateCreateManyArgs} args - Arguments to create many Upload_document_templates.
     * @example
     * // Create many Upload_document_templates
     * const upload_document_template = await prisma.upload_document_template.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
    **/
    createMany<T extends upload_document_templateCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, upload_document_templateCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Upload_document_template.
     * @param {upload_document_templateDeleteArgs} args - Arguments to delete one Upload_document_template.
     * @example
     * // Delete one Upload_document_template
     * const Upload_document_template = await prisma.upload_document_template.delete({
     *   where: {
     *     // ... filter to delete one Upload_document_template
     *   }
     * })
     * 
    **/
    delete<T extends upload_document_templateDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, upload_document_templateDeleteArgs<ExtArgs>>
    ): Prisma__upload_document_templateClient<$Result.GetResult<Prisma.$upload_document_templatePayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one Upload_document_template.
     * @param {upload_document_templateUpdateArgs} args - Arguments to update one Upload_document_template.
     * @example
     * // Update one Upload_document_template
     * const upload_document_template = await prisma.upload_document_template.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends upload_document_templateUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, upload_document_templateUpdateArgs<ExtArgs>>
    ): Prisma__upload_document_templateClient<$Result.GetResult<Prisma.$upload_document_templatePayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more Upload_document_templates.
     * @param {upload_document_templateDeleteManyArgs} args - Arguments to filter Upload_document_templates to delete.
     * @example
     * // Delete a few Upload_document_templates
     * const { count } = await prisma.upload_document_template.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends upload_document_templateDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, upload_document_templateDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Upload_document_templates.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {upload_document_templateUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Upload_document_templates
     * const upload_document_template = await prisma.upload_document_template.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends upload_document_templateUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, upload_document_templateUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Upload_document_template.
     * @param {upload_document_templateUpsertArgs} args - Arguments to update or create a Upload_document_template.
     * @example
     * // Update or create a Upload_document_template
     * const upload_document_template = await prisma.upload_document_template.upsert({
     *   create: {
     *     // ... data to create a Upload_document_template
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Upload_document_template we want to update
     *   }
     * })
    **/
    upsert<T extends upload_document_templateUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, upload_document_templateUpsertArgs<ExtArgs>>
    ): Prisma__upload_document_templateClient<$Result.GetResult<Prisma.$upload_document_templatePayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of Upload_document_templates.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {upload_document_templateCountArgs} args - Arguments to filter Upload_document_templates to count.
     * @example
     * // Count the number of Upload_document_templates
     * const count = await prisma.upload_document_template.count({
     *   where: {
     *     // ... the filter for the Upload_document_templates we want to count
     *   }
     * })
    **/
    count<T extends upload_document_templateCountArgs>(
      args?: Subset<T, upload_document_templateCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Upload_document_templateCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Upload_document_template.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Upload_document_templateAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Upload_document_templateAggregateArgs>(args: Subset<T, Upload_document_templateAggregateArgs>): Prisma.PrismaPromise<GetUpload_document_templateAggregateType<T>>

    /**
     * Group by Upload_document_template.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {upload_document_templateGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends upload_document_templateGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: upload_document_templateGroupByArgs['orderBy'] }
        : { orderBy?: upload_document_templateGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, upload_document_templateGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUpload_document_templateGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the upload_document_template model
   */
  readonly fields: upload_document_templateFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for upload_document_template.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__upload_document_templateClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';


    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the upload_document_template model
   */ 
  interface upload_document_templateFieldRefs {
    readonly id: FieldRef<"upload_document_template", 'String'>
    readonly title: FieldRef<"upload_document_template", 'String'>
    readonly maximumSizeInMb: FieldRef<"upload_document_template", 'Int'>
    readonly isRequired: FieldRef<"upload_document_template", 'Boolean'>
    readonly showWhen: FieldRef<"upload_document_template", 'String'>
    readonly creationTime: FieldRef<"upload_document_template", 'DateTime'>
    readonly creatorId: FieldRef<"upload_document_template", 'String'>
  }
    

  // Custom InputTypes
  /**
   * upload_document_template findUnique
   */
  export type upload_document_templateFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the upload_document_template
     */
    select?: upload_document_templateSelect<ExtArgs> | null
    /**
     * Filter, which upload_document_template to fetch.
     */
    where: upload_document_templateWhereUniqueInput
  }

  /**
   * upload_document_template findUniqueOrThrow
   */
  export type upload_document_templateFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the upload_document_template
     */
    select?: upload_document_templateSelect<ExtArgs> | null
    /**
     * Filter, which upload_document_template to fetch.
     */
    where: upload_document_templateWhereUniqueInput
  }

  /**
   * upload_document_template findFirst
   */
  export type upload_document_templateFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the upload_document_template
     */
    select?: upload_document_templateSelect<ExtArgs> | null
    /**
     * Filter, which upload_document_template to fetch.
     */
    where?: upload_document_templateWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of upload_document_templates to fetch.
     */
    orderBy?: upload_document_templateOrderByWithRelationInput | upload_document_templateOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for upload_document_templates.
     */
    cursor?: upload_document_templateWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` upload_document_templates from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` upload_document_templates.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of upload_document_templates.
     */
    distinct?: Upload_document_templateScalarFieldEnum | Upload_document_templateScalarFieldEnum[]
  }

  /**
   * upload_document_template findFirstOrThrow
   */
  export type upload_document_templateFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the upload_document_template
     */
    select?: upload_document_templateSelect<ExtArgs> | null
    /**
     * Filter, which upload_document_template to fetch.
     */
    where?: upload_document_templateWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of upload_document_templates to fetch.
     */
    orderBy?: upload_document_templateOrderByWithRelationInput | upload_document_templateOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for upload_document_templates.
     */
    cursor?: upload_document_templateWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` upload_document_templates from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` upload_document_templates.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of upload_document_templates.
     */
    distinct?: Upload_document_templateScalarFieldEnum | Upload_document_templateScalarFieldEnum[]
  }

  /**
   * upload_document_template findMany
   */
  export type upload_document_templateFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the upload_document_template
     */
    select?: upload_document_templateSelect<ExtArgs> | null
    /**
     * Filter, which upload_document_templates to fetch.
     */
    where?: upload_document_templateWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of upload_document_templates to fetch.
     */
    orderBy?: upload_document_templateOrderByWithRelationInput | upload_document_templateOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing upload_document_templates.
     */
    cursor?: upload_document_templateWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` upload_document_templates from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` upload_document_templates.
     */
    skip?: number
    distinct?: Upload_document_templateScalarFieldEnum | Upload_document_templateScalarFieldEnum[]
  }

  /**
   * upload_document_template create
   */
  export type upload_document_templateCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the upload_document_template
     */
    select?: upload_document_templateSelect<ExtArgs> | null
    /**
     * The data needed to create a upload_document_template.
     */
    data: XOR<upload_document_templateCreateInput, upload_document_templateUncheckedCreateInput>
  }

  /**
   * upload_document_template createMany
   */
  export type upload_document_templateCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many upload_document_templates.
     */
    data: upload_document_templateCreateManyInput | upload_document_templateCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * upload_document_template update
   */
  export type upload_document_templateUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the upload_document_template
     */
    select?: upload_document_templateSelect<ExtArgs> | null
    /**
     * The data needed to update a upload_document_template.
     */
    data: XOR<upload_document_templateUpdateInput, upload_document_templateUncheckedUpdateInput>
    /**
     * Choose, which upload_document_template to update.
     */
    where: upload_document_templateWhereUniqueInput
  }

  /**
   * upload_document_template updateMany
   */
  export type upload_document_templateUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update upload_document_templates.
     */
    data: XOR<upload_document_templateUpdateManyMutationInput, upload_document_templateUncheckedUpdateManyInput>
    /**
     * Filter which upload_document_templates to update
     */
    where?: upload_document_templateWhereInput
  }

  /**
   * upload_document_template upsert
   */
  export type upload_document_templateUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the upload_document_template
     */
    select?: upload_document_templateSelect<ExtArgs> | null
    /**
     * The filter to search for the upload_document_template to update in case it exists.
     */
    where: upload_document_templateWhereUniqueInput
    /**
     * In case the upload_document_template found by the `where` argument doesn't exist, create a new upload_document_template with this data.
     */
    create: XOR<upload_document_templateCreateInput, upload_document_templateUncheckedCreateInput>
    /**
     * In case the upload_document_template was found with the provided `where` argument, update it with this data.
     */
    update: XOR<upload_document_templateUpdateInput, upload_document_templateUncheckedUpdateInput>
  }

  /**
   * upload_document_template delete
   */
  export type upload_document_templateDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the upload_document_template
     */
    select?: upload_document_templateSelect<ExtArgs> | null
    /**
     * Filter which upload_document_template to delete.
     */
    where: upload_document_templateWhereUniqueInput
  }

  /**
   * upload_document_template deleteMany
   */
  export type upload_document_templateDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which upload_document_templates to delete
     */
    where?: upload_document_templateWhereInput
  }

  /**
   * upload_document_template without action
   */
  export type upload_document_templateDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the upload_document_template
     */
    select?: upload_document_templateSelect<ExtArgs> | null
  }


  /**
   * Model uploadedDocuments
   */

  export type AggregateUploadedDocuments = {
    _count: UploadedDocumentsCountAggregateOutputType | null
    _min: UploadedDocumentsMinAggregateOutputType | null
    _max: UploadedDocumentsMaxAggregateOutputType | null
  }

  export type UploadedDocumentsMinAggregateOutputType = {
    id: string | null
    userId: string | null
    templateId: string | null
    filePath: string | null
    creationTime: Date | null
  }

  export type UploadedDocumentsMaxAggregateOutputType = {
    id: string | null
    userId: string | null
    templateId: string | null
    filePath: string | null
    creationTime: Date | null
  }

  export type UploadedDocumentsCountAggregateOutputType = {
    id: number
    userId: number
    templateId: number
    filePath: number
    creationTime: number
    _all: number
  }


  export type UploadedDocumentsMinAggregateInputType = {
    id?: true
    userId?: true
    templateId?: true
    filePath?: true
    creationTime?: true
  }

  export type UploadedDocumentsMaxAggregateInputType = {
    id?: true
    userId?: true
    templateId?: true
    filePath?: true
    creationTime?: true
  }

  export type UploadedDocumentsCountAggregateInputType = {
    id?: true
    userId?: true
    templateId?: true
    filePath?: true
    creationTime?: true
    _all?: true
  }

  export type UploadedDocumentsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which uploadedDocuments to aggregate.
     */
    where?: uploadedDocumentsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of uploadedDocuments to fetch.
     */
    orderBy?: uploadedDocumentsOrderByWithRelationInput | uploadedDocumentsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: uploadedDocumentsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` uploadedDocuments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` uploadedDocuments.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned uploadedDocuments
    **/
    _count?: true | UploadedDocumentsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UploadedDocumentsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UploadedDocumentsMaxAggregateInputType
  }

  export type GetUploadedDocumentsAggregateType<T extends UploadedDocumentsAggregateArgs> = {
        [P in keyof T & keyof AggregateUploadedDocuments]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUploadedDocuments[P]>
      : GetScalarType<T[P], AggregateUploadedDocuments[P]>
  }




  export type uploadedDocumentsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: uploadedDocumentsWhereInput
    orderBy?: uploadedDocumentsOrderByWithAggregationInput | uploadedDocumentsOrderByWithAggregationInput[]
    by: UploadedDocumentsScalarFieldEnum[] | UploadedDocumentsScalarFieldEnum
    having?: uploadedDocumentsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UploadedDocumentsCountAggregateInputType | true
    _min?: UploadedDocumentsMinAggregateInputType
    _max?: UploadedDocumentsMaxAggregateInputType
  }

  export type UploadedDocumentsGroupByOutputType = {
    id: string
    userId: string
    templateId: string
    filePath: string
    creationTime: Date
    _count: UploadedDocumentsCountAggregateOutputType | null
    _min: UploadedDocumentsMinAggregateOutputType | null
    _max: UploadedDocumentsMaxAggregateOutputType | null
  }

  type GetUploadedDocumentsGroupByPayload<T extends uploadedDocumentsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UploadedDocumentsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UploadedDocumentsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UploadedDocumentsGroupByOutputType[P]>
            : GetScalarType<T[P], UploadedDocumentsGroupByOutputType[P]>
        }
      >
    >


  export type uploadedDocumentsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    templateId?: boolean
    filePath?: boolean
    creationTime?: boolean
  }, ExtArgs["result"]["uploadedDocuments"]>


  export type uploadedDocumentsSelectScalar = {
    id?: boolean
    userId?: boolean
    templateId?: boolean
    filePath?: boolean
    creationTime?: boolean
  }


  export type $uploadedDocumentsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "uploadedDocuments"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      userId: string
      templateId: string
      filePath: string
      creationTime: Date
    }, ExtArgs["result"]["uploadedDocuments"]>
    composites: {}
  }

  type uploadedDocumentsGetPayload<S extends boolean | null | undefined | uploadedDocumentsDefaultArgs> = $Result.GetResult<Prisma.$uploadedDocumentsPayload, S>

  type uploadedDocumentsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<uploadedDocumentsFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: UploadedDocumentsCountAggregateInputType | true
    }

  export interface uploadedDocumentsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['uploadedDocuments'], meta: { name: 'uploadedDocuments' } }
    /**
     * Find zero or one UploadedDocuments that matches the filter.
     * @param {uploadedDocumentsFindUniqueArgs} args - Arguments to find a UploadedDocuments
     * @example
     * // Get one UploadedDocuments
     * const uploadedDocuments = await prisma.uploadedDocuments.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends uploadedDocumentsFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, uploadedDocumentsFindUniqueArgs<ExtArgs>>
    ): Prisma__uploadedDocumentsClient<$Result.GetResult<Prisma.$uploadedDocumentsPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one UploadedDocuments that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {uploadedDocumentsFindUniqueOrThrowArgs} args - Arguments to find a UploadedDocuments
     * @example
     * // Get one UploadedDocuments
     * const uploadedDocuments = await prisma.uploadedDocuments.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends uploadedDocumentsFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, uploadedDocumentsFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__uploadedDocumentsClient<$Result.GetResult<Prisma.$uploadedDocumentsPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first UploadedDocuments that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {uploadedDocumentsFindFirstArgs} args - Arguments to find a UploadedDocuments
     * @example
     * // Get one UploadedDocuments
     * const uploadedDocuments = await prisma.uploadedDocuments.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends uploadedDocumentsFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, uploadedDocumentsFindFirstArgs<ExtArgs>>
    ): Prisma__uploadedDocumentsClient<$Result.GetResult<Prisma.$uploadedDocumentsPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first UploadedDocuments that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {uploadedDocumentsFindFirstOrThrowArgs} args - Arguments to find a UploadedDocuments
     * @example
     * // Get one UploadedDocuments
     * const uploadedDocuments = await prisma.uploadedDocuments.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends uploadedDocumentsFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, uploadedDocumentsFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__uploadedDocumentsClient<$Result.GetResult<Prisma.$uploadedDocumentsPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more UploadedDocuments that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {uploadedDocumentsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all UploadedDocuments
     * const uploadedDocuments = await prisma.uploadedDocuments.findMany()
     * 
     * // Get first 10 UploadedDocuments
     * const uploadedDocuments = await prisma.uploadedDocuments.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const uploadedDocumentsWithIdOnly = await prisma.uploadedDocuments.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends uploadedDocumentsFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, uploadedDocumentsFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$uploadedDocumentsPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a UploadedDocuments.
     * @param {uploadedDocumentsCreateArgs} args - Arguments to create a UploadedDocuments.
     * @example
     * // Create one UploadedDocuments
     * const UploadedDocuments = await prisma.uploadedDocuments.create({
     *   data: {
     *     // ... data to create a UploadedDocuments
     *   }
     * })
     * 
    **/
    create<T extends uploadedDocumentsCreateArgs<ExtArgs>>(
      args: SelectSubset<T, uploadedDocumentsCreateArgs<ExtArgs>>
    ): Prisma__uploadedDocumentsClient<$Result.GetResult<Prisma.$uploadedDocumentsPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many UploadedDocuments.
     * @param {uploadedDocumentsCreateManyArgs} args - Arguments to create many UploadedDocuments.
     * @example
     * // Create many UploadedDocuments
     * const uploadedDocuments = await prisma.uploadedDocuments.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
    **/
    createMany<T extends uploadedDocumentsCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, uploadedDocumentsCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a UploadedDocuments.
     * @param {uploadedDocumentsDeleteArgs} args - Arguments to delete one UploadedDocuments.
     * @example
     * // Delete one UploadedDocuments
     * const UploadedDocuments = await prisma.uploadedDocuments.delete({
     *   where: {
     *     // ... filter to delete one UploadedDocuments
     *   }
     * })
     * 
    **/
    delete<T extends uploadedDocumentsDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, uploadedDocumentsDeleteArgs<ExtArgs>>
    ): Prisma__uploadedDocumentsClient<$Result.GetResult<Prisma.$uploadedDocumentsPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one UploadedDocuments.
     * @param {uploadedDocumentsUpdateArgs} args - Arguments to update one UploadedDocuments.
     * @example
     * // Update one UploadedDocuments
     * const uploadedDocuments = await prisma.uploadedDocuments.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends uploadedDocumentsUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, uploadedDocumentsUpdateArgs<ExtArgs>>
    ): Prisma__uploadedDocumentsClient<$Result.GetResult<Prisma.$uploadedDocumentsPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more UploadedDocuments.
     * @param {uploadedDocumentsDeleteManyArgs} args - Arguments to filter UploadedDocuments to delete.
     * @example
     * // Delete a few UploadedDocuments
     * const { count } = await prisma.uploadedDocuments.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends uploadedDocumentsDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, uploadedDocumentsDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more UploadedDocuments.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {uploadedDocumentsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many UploadedDocuments
     * const uploadedDocuments = await prisma.uploadedDocuments.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends uploadedDocumentsUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, uploadedDocumentsUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one UploadedDocuments.
     * @param {uploadedDocumentsUpsertArgs} args - Arguments to update or create a UploadedDocuments.
     * @example
     * // Update or create a UploadedDocuments
     * const uploadedDocuments = await prisma.uploadedDocuments.upsert({
     *   create: {
     *     // ... data to create a UploadedDocuments
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the UploadedDocuments we want to update
     *   }
     * })
    **/
    upsert<T extends uploadedDocumentsUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, uploadedDocumentsUpsertArgs<ExtArgs>>
    ): Prisma__uploadedDocumentsClient<$Result.GetResult<Prisma.$uploadedDocumentsPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of UploadedDocuments.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {uploadedDocumentsCountArgs} args - Arguments to filter UploadedDocuments to count.
     * @example
     * // Count the number of UploadedDocuments
     * const count = await prisma.uploadedDocuments.count({
     *   where: {
     *     // ... the filter for the UploadedDocuments we want to count
     *   }
     * })
    **/
    count<T extends uploadedDocumentsCountArgs>(
      args?: Subset<T, uploadedDocumentsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UploadedDocumentsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a UploadedDocuments.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UploadedDocumentsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UploadedDocumentsAggregateArgs>(args: Subset<T, UploadedDocumentsAggregateArgs>): Prisma.PrismaPromise<GetUploadedDocumentsAggregateType<T>>

    /**
     * Group by UploadedDocuments.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {uploadedDocumentsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends uploadedDocumentsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: uploadedDocumentsGroupByArgs['orderBy'] }
        : { orderBy?: uploadedDocumentsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, uploadedDocumentsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUploadedDocumentsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the uploadedDocuments model
   */
  readonly fields: uploadedDocumentsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for uploadedDocuments.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__uploadedDocumentsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';


    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the uploadedDocuments model
   */ 
  interface uploadedDocumentsFieldRefs {
    readonly id: FieldRef<"uploadedDocuments", 'String'>
    readonly userId: FieldRef<"uploadedDocuments", 'String'>
    readonly templateId: FieldRef<"uploadedDocuments", 'String'>
    readonly filePath: FieldRef<"uploadedDocuments", 'String'>
    readonly creationTime: FieldRef<"uploadedDocuments", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * uploadedDocuments findUnique
   */
  export type uploadedDocumentsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the uploadedDocuments
     */
    select?: uploadedDocumentsSelect<ExtArgs> | null
    /**
     * Filter, which uploadedDocuments to fetch.
     */
    where: uploadedDocumentsWhereUniqueInput
  }

  /**
   * uploadedDocuments findUniqueOrThrow
   */
  export type uploadedDocumentsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the uploadedDocuments
     */
    select?: uploadedDocumentsSelect<ExtArgs> | null
    /**
     * Filter, which uploadedDocuments to fetch.
     */
    where: uploadedDocumentsWhereUniqueInput
  }

  /**
   * uploadedDocuments findFirst
   */
  export type uploadedDocumentsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the uploadedDocuments
     */
    select?: uploadedDocumentsSelect<ExtArgs> | null
    /**
     * Filter, which uploadedDocuments to fetch.
     */
    where?: uploadedDocumentsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of uploadedDocuments to fetch.
     */
    orderBy?: uploadedDocumentsOrderByWithRelationInput | uploadedDocumentsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for uploadedDocuments.
     */
    cursor?: uploadedDocumentsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` uploadedDocuments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` uploadedDocuments.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of uploadedDocuments.
     */
    distinct?: UploadedDocumentsScalarFieldEnum | UploadedDocumentsScalarFieldEnum[]
  }

  /**
   * uploadedDocuments findFirstOrThrow
   */
  export type uploadedDocumentsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the uploadedDocuments
     */
    select?: uploadedDocumentsSelect<ExtArgs> | null
    /**
     * Filter, which uploadedDocuments to fetch.
     */
    where?: uploadedDocumentsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of uploadedDocuments to fetch.
     */
    orderBy?: uploadedDocumentsOrderByWithRelationInput | uploadedDocumentsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for uploadedDocuments.
     */
    cursor?: uploadedDocumentsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` uploadedDocuments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` uploadedDocuments.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of uploadedDocuments.
     */
    distinct?: UploadedDocumentsScalarFieldEnum | UploadedDocumentsScalarFieldEnum[]
  }

  /**
   * uploadedDocuments findMany
   */
  export type uploadedDocumentsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the uploadedDocuments
     */
    select?: uploadedDocumentsSelect<ExtArgs> | null
    /**
     * Filter, which uploadedDocuments to fetch.
     */
    where?: uploadedDocumentsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of uploadedDocuments to fetch.
     */
    orderBy?: uploadedDocumentsOrderByWithRelationInput | uploadedDocumentsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing uploadedDocuments.
     */
    cursor?: uploadedDocumentsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` uploadedDocuments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` uploadedDocuments.
     */
    skip?: number
    distinct?: UploadedDocumentsScalarFieldEnum | UploadedDocumentsScalarFieldEnum[]
  }

  /**
   * uploadedDocuments create
   */
  export type uploadedDocumentsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the uploadedDocuments
     */
    select?: uploadedDocumentsSelect<ExtArgs> | null
    /**
     * The data needed to create a uploadedDocuments.
     */
    data: XOR<uploadedDocumentsCreateInput, uploadedDocumentsUncheckedCreateInput>
  }

  /**
   * uploadedDocuments createMany
   */
  export type uploadedDocumentsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many uploadedDocuments.
     */
    data: uploadedDocumentsCreateManyInput | uploadedDocumentsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * uploadedDocuments update
   */
  export type uploadedDocumentsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the uploadedDocuments
     */
    select?: uploadedDocumentsSelect<ExtArgs> | null
    /**
     * The data needed to update a uploadedDocuments.
     */
    data: XOR<uploadedDocumentsUpdateInput, uploadedDocumentsUncheckedUpdateInput>
    /**
     * Choose, which uploadedDocuments to update.
     */
    where: uploadedDocumentsWhereUniqueInput
  }

  /**
   * uploadedDocuments updateMany
   */
  export type uploadedDocumentsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update uploadedDocuments.
     */
    data: XOR<uploadedDocumentsUpdateManyMutationInput, uploadedDocumentsUncheckedUpdateManyInput>
    /**
     * Filter which uploadedDocuments to update
     */
    where?: uploadedDocumentsWhereInput
  }

  /**
   * uploadedDocuments upsert
   */
  export type uploadedDocumentsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the uploadedDocuments
     */
    select?: uploadedDocumentsSelect<ExtArgs> | null
    /**
     * The filter to search for the uploadedDocuments to update in case it exists.
     */
    where: uploadedDocumentsWhereUniqueInput
    /**
     * In case the uploadedDocuments found by the `where` argument doesn't exist, create a new uploadedDocuments with this data.
     */
    create: XOR<uploadedDocumentsCreateInput, uploadedDocumentsUncheckedCreateInput>
    /**
     * In case the uploadedDocuments was found with the provided `where` argument, update it with this data.
     */
    update: XOR<uploadedDocumentsUpdateInput, uploadedDocumentsUncheckedUpdateInput>
  }

  /**
   * uploadedDocuments delete
   */
  export type uploadedDocumentsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the uploadedDocuments
     */
    select?: uploadedDocumentsSelect<ExtArgs> | null
    /**
     * Filter which uploadedDocuments to delete.
     */
    where: uploadedDocumentsWhereUniqueInput
  }

  /**
   * uploadedDocuments deleteMany
   */
  export type uploadedDocumentsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which uploadedDocuments to delete
     */
    where?: uploadedDocumentsWhereInput
  }

  /**
   * uploadedDocuments without action
   */
  export type uploadedDocumentsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the uploadedDocuments
     */
    select?: uploadedDocumentsSelect<ExtArgs> | null
  }


  /**
   * Model rejectionTemplates
   */

  export type AggregateRejectionTemplates = {
    _count: RejectionTemplatesCountAggregateOutputType | null
    _min: RejectionTemplatesMinAggregateOutputType | null
    _max: RejectionTemplatesMaxAggregateOutputType | null
  }

  export type RejectionTemplatesMinAggregateOutputType = {
    id: string | null
    title: string | null
    creationTime: Date | null
    creatorId: string | null
  }

  export type RejectionTemplatesMaxAggregateOutputType = {
    id: string | null
    title: string | null
    creationTime: Date | null
    creatorId: string | null
  }

  export type RejectionTemplatesCountAggregateOutputType = {
    id: number
    title: number
    creationTime: number
    creatorId: number
    _all: number
  }


  export type RejectionTemplatesMinAggregateInputType = {
    id?: true
    title?: true
    creationTime?: true
    creatorId?: true
  }

  export type RejectionTemplatesMaxAggregateInputType = {
    id?: true
    title?: true
    creationTime?: true
    creatorId?: true
  }

  export type RejectionTemplatesCountAggregateInputType = {
    id?: true
    title?: true
    creationTime?: true
    creatorId?: true
    _all?: true
  }

  export type RejectionTemplatesAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which rejectionTemplates to aggregate.
     */
    where?: rejectionTemplatesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of rejectionTemplates to fetch.
     */
    orderBy?: rejectionTemplatesOrderByWithRelationInput | rejectionTemplatesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: rejectionTemplatesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` rejectionTemplates from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` rejectionTemplates.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned rejectionTemplates
    **/
    _count?: true | RejectionTemplatesCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: RejectionTemplatesMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: RejectionTemplatesMaxAggregateInputType
  }

  export type GetRejectionTemplatesAggregateType<T extends RejectionTemplatesAggregateArgs> = {
        [P in keyof T & keyof AggregateRejectionTemplates]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateRejectionTemplates[P]>
      : GetScalarType<T[P], AggregateRejectionTemplates[P]>
  }




  export type rejectionTemplatesGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: rejectionTemplatesWhereInput
    orderBy?: rejectionTemplatesOrderByWithAggregationInput | rejectionTemplatesOrderByWithAggregationInput[]
    by: RejectionTemplatesScalarFieldEnum[] | RejectionTemplatesScalarFieldEnum
    having?: rejectionTemplatesScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: RejectionTemplatesCountAggregateInputType | true
    _min?: RejectionTemplatesMinAggregateInputType
    _max?: RejectionTemplatesMaxAggregateInputType
  }

  export type RejectionTemplatesGroupByOutputType = {
    id: string
    title: string
    creationTime: Date
    creatorId: string | null
    _count: RejectionTemplatesCountAggregateOutputType | null
    _min: RejectionTemplatesMinAggregateOutputType | null
    _max: RejectionTemplatesMaxAggregateOutputType | null
  }

  type GetRejectionTemplatesGroupByPayload<T extends rejectionTemplatesGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<RejectionTemplatesGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof RejectionTemplatesGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], RejectionTemplatesGroupByOutputType[P]>
            : GetScalarType<T[P], RejectionTemplatesGroupByOutputType[P]>
        }
      >
    >


  export type rejectionTemplatesSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    title?: boolean
    creationTime?: boolean
    creatorId?: boolean
  }, ExtArgs["result"]["rejectionTemplates"]>


  export type rejectionTemplatesSelectScalar = {
    id?: boolean
    title?: boolean
    creationTime?: boolean
    creatorId?: boolean
  }


  export type $rejectionTemplatesPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "rejectionTemplates"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      title: string
      creationTime: Date
      creatorId: string | null
    }, ExtArgs["result"]["rejectionTemplates"]>
    composites: {}
  }

  type rejectionTemplatesGetPayload<S extends boolean | null | undefined | rejectionTemplatesDefaultArgs> = $Result.GetResult<Prisma.$rejectionTemplatesPayload, S>

  type rejectionTemplatesCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<rejectionTemplatesFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: RejectionTemplatesCountAggregateInputType | true
    }

  export interface rejectionTemplatesDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['rejectionTemplates'], meta: { name: 'rejectionTemplates' } }
    /**
     * Find zero or one RejectionTemplates that matches the filter.
     * @param {rejectionTemplatesFindUniqueArgs} args - Arguments to find a RejectionTemplates
     * @example
     * // Get one RejectionTemplates
     * const rejectionTemplates = await prisma.rejectionTemplates.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends rejectionTemplatesFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, rejectionTemplatesFindUniqueArgs<ExtArgs>>
    ): Prisma__rejectionTemplatesClient<$Result.GetResult<Prisma.$rejectionTemplatesPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one RejectionTemplates that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {rejectionTemplatesFindUniqueOrThrowArgs} args - Arguments to find a RejectionTemplates
     * @example
     * // Get one RejectionTemplates
     * const rejectionTemplates = await prisma.rejectionTemplates.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends rejectionTemplatesFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, rejectionTemplatesFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__rejectionTemplatesClient<$Result.GetResult<Prisma.$rejectionTemplatesPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first RejectionTemplates that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {rejectionTemplatesFindFirstArgs} args - Arguments to find a RejectionTemplates
     * @example
     * // Get one RejectionTemplates
     * const rejectionTemplates = await prisma.rejectionTemplates.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends rejectionTemplatesFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, rejectionTemplatesFindFirstArgs<ExtArgs>>
    ): Prisma__rejectionTemplatesClient<$Result.GetResult<Prisma.$rejectionTemplatesPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first RejectionTemplates that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {rejectionTemplatesFindFirstOrThrowArgs} args - Arguments to find a RejectionTemplates
     * @example
     * // Get one RejectionTemplates
     * const rejectionTemplates = await prisma.rejectionTemplates.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends rejectionTemplatesFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, rejectionTemplatesFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__rejectionTemplatesClient<$Result.GetResult<Prisma.$rejectionTemplatesPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more RejectionTemplates that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {rejectionTemplatesFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all RejectionTemplates
     * const rejectionTemplates = await prisma.rejectionTemplates.findMany()
     * 
     * // Get first 10 RejectionTemplates
     * const rejectionTemplates = await prisma.rejectionTemplates.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const rejectionTemplatesWithIdOnly = await prisma.rejectionTemplates.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends rejectionTemplatesFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, rejectionTemplatesFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$rejectionTemplatesPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a RejectionTemplates.
     * @param {rejectionTemplatesCreateArgs} args - Arguments to create a RejectionTemplates.
     * @example
     * // Create one RejectionTemplates
     * const RejectionTemplates = await prisma.rejectionTemplates.create({
     *   data: {
     *     // ... data to create a RejectionTemplates
     *   }
     * })
     * 
    **/
    create<T extends rejectionTemplatesCreateArgs<ExtArgs>>(
      args: SelectSubset<T, rejectionTemplatesCreateArgs<ExtArgs>>
    ): Prisma__rejectionTemplatesClient<$Result.GetResult<Prisma.$rejectionTemplatesPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many RejectionTemplates.
     * @param {rejectionTemplatesCreateManyArgs} args - Arguments to create many RejectionTemplates.
     * @example
     * // Create many RejectionTemplates
     * const rejectionTemplates = await prisma.rejectionTemplates.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
    **/
    createMany<T extends rejectionTemplatesCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, rejectionTemplatesCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a RejectionTemplates.
     * @param {rejectionTemplatesDeleteArgs} args - Arguments to delete one RejectionTemplates.
     * @example
     * // Delete one RejectionTemplates
     * const RejectionTemplates = await prisma.rejectionTemplates.delete({
     *   where: {
     *     // ... filter to delete one RejectionTemplates
     *   }
     * })
     * 
    **/
    delete<T extends rejectionTemplatesDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, rejectionTemplatesDeleteArgs<ExtArgs>>
    ): Prisma__rejectionTemplatesClient<$Result.GetResult<Prisma.$rejectionTemplatesPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one RejectionTemplates.
     * @param {rejectionTemplatesUpdateArgs} args - Arguments to update one RejectionTemplates.
     * @example
     * // Update one RejectionTemplates
     * const rejectionTemplates = await prisma.rejectionTemplates.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends rejectionTemplatesUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, rejectionTemplatesUpdateArgs<ExtArgs>>
    ): Prisma__rejectionTemplatesClient<$Result.GetResult<Prisma.$rejectionTemplatesPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more RejectionTemplates.
     * @param {rejectionTemplatesDeleteManyArgs} args - Arguments to filter RejectionTemplates to delete.
     * @example
     * // Delete a few RejectionTemplates
     * const { count } = await prisma.rejectionTemplates.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends rejectionTemplatesDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, rejectionTemplatesDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more RejectionTemplates.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {rejectionTemplatesUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many RejectionTemplates
     * const rejectionTemplates = await prisma.rejectionTemplates.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends rejectionTemplatesUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, rejectionTemplatesUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one RejectionTemplates.
     * @param {rejectionTemplatesUpsertArgs} args - Arguments to update or create a RejectionTemplates.
     * @example
     * // Update or create a RejectionTemplates
     * const rejectionTemplates = await prisma.rejectionTemplates.upsert({
     *   create: {
     *     // ... data to create a RejectionTemplates
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the RejectionTemplates we want to update
     *   }
     * })
    **/
    upsert<T extends rejectionTemplatesUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, rejectionTemplatesUpsertArgs<ExtArgs>>
    ): Prisma__rejectionTemplatesClient<$Result.GetResult<Prisma.$rejectionTemplatesPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of RejectionTemplates.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {rejectionTemplatesCountArgs} args - Arguments to filter RejectionTemplates to count.
     * @example
     * // Count the number of RejectionTemplates
     * const count = await prisma.rejectionTemplates.count({
     *   where: {
     *     // ... the filter for the RejectionTemplates we want to count
     *   }
     * })
    **/
    count<T extends rejectionTemplatesCountArgs>(
      args?: Subset<T, rejectionTemplatesCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], RejectionTemplatesCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a RejectionTemplates.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RejectionTemplatesAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends RejectionTemplatesAggregateArgs>(args: Subset<T, RejectionTemplatesAggregateArgs>): Prisma.PrismaPromise<GetRejectionTemplatesAggregateType<T>>

    /**
     * Group by RejectionTemplates.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {rejectionTemplatesGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends rejectionTemplatesGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: rejectionTemplatesGroupByArgs['orderBy'] }
        : { orderBy?: rejectionTemplatesGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, rejectionTemplatesGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetRejectionTemplatesGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the rejectionTemplates model
   */
  readonly fields: rejectionTemplatesFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for rejectionTemplates.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__rejectionTemplatesClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';


    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the rejectionTemplates model
   */ 
  interface rejectionTemplatesFieldRefs {
    readonly id: FieldRef<"rejectionTemplates", 'String'>
    readonly title: FieldRef<"rejectionTemplates", 'String'>
    readonly creationTime: FieldRef<"rejectionTemplates", 'DateTime'>
    readonly creatorId: FieldRef<"rejectionTemplates", 'String'>
  }
    

  // Custom InputTypes
  /**
   * rejectionTemplates findUnique
   */
  export type rejectionTemplatesFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the rejectionTemplates
     */
    select?: rejectionTemplatesSelect<ExtArgs> | null
    /**
     * Filter, which rejectionTemplates to fetch.
     */
    where: rejectionTemplatesWhereUniqueInput
  }

  /**
   * rejectionTemplates findUniqueOrThrow
   */
  export type rejectionTemplatesFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the rejectionTemplates
     */
    select?: rejectionTemplatesSelect<ExtArgs> | null
    /**
     * Filter, which rejectionTemplates to fetch.
     */
    where: rejectionTemplatesWhereUniqueInput
  }

  /**
   * rejectionTemplates findFirst
   */
  export type rejectionTemplatesFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the rejectionTemplates
     */
    select?: rejectionTemplatesSelect<ExtArgs> | null
    /**
     * Filter, which rejectionTemplates to fetch.
     */
    where?: rejectionTemplatesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of rejectionTemplates to fetch.
     */
    orderBy?: rejectionTemplatesOrderByWithRelationInput | rejectionTemplatesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for rejectionTemplates.
     */
    cursor?: rejectionTemplatesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` rejectionTemplates from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` rejectionTemplates.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of rejectionTemplates.
     */
    distinct?: RejectionTemplatesScalarFieldEnum | RejectionTemplatesScalarFieldEnum[]
  }

  /**
   * rejectionTemplates findFirstOrThrow
   */
  export type rejectionTemplatesFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the rejectionTemplates
     */
    select?: rejectionTemplatesSelect<ExtArgs> | null
    /**
     * Filter, which rejectionTemplates to fetch.
     */
    where?: rejectionTemplatesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of rejectionTemplates to fetch.
     */
    orderBy?: rejectionTemplatesOrderByWithRelationInput | rejectionTemplatesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for rejectionTemplates.
     */
    cursor?: rejectionTemplatesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` rejectionTemplates from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` rejectionTemplates.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of rejectionTemplates.
     */
    distinct?: RejectionTemplatesScalarFieldEnum | RejectionTemplatesScalarFieldEnum[]
  }

  /**
   * rejectionTemplates findMany
   */
  export type rejectionTemplatesFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the rejectionTemplates
     */
    select?: rejectionTemplatesSelect<ExtArgs> | null
    /**
     * Filter, which rejectionTemplates to fetch.
     */
    where?: rejectionTemplatesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of rejectionTemplates to fetch.
     */
    orderBy?: rejectionTemplatesOrderByWithRelationInput | rejectionTemplatesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing rejectionTemplates.
     */
    cursor?: rejectionTemplatesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` rejectionTemplates from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` rejectionTemplates.
     */
    skip?: number
    distinct?: RejectionTemplatesScalarFieldEnum | RejectionTemplatesScalarFieldEnum[]
  }

  /**
   * rejectionTemplates create
   */
  export type rejectionTemplatesCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the rejectionTemplates
     */
    select?: rejectionTemplatesSelect<ExtArgs> | null
    /**
     * The data needed to create a rejectionTemplates.
     */
    data: XOR<rejectionTemplatesCreateInput, rejectionTemplatesUncheckedCreateInput>
  }

  /**
   * rejectionTemplates createMany
   */
  export type rejectionTemplatesCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many rejectionTemplates.
     */
    data: rejectionTemplatesCreateManyInput | rejectionTemplatesCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * rejectionTemplates update
   */
  export type rejectionTemplatesUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the rejectionTemplates
     */
    select?: rejectionTemplatesSelect<ExtArgs> | null
    /**
     * The data needed to update a rejectionTemplates.
     */
    data: XOR<rejectionTemplatesUpdateInput, rejectionTemplatesUncheckedUpdateInput>
    /**
     * Choose, which rejectionTemplates to update.
     */
    where: rejectionTemplatesWhereUniqueInput
  }

  /**
   * rejectionTemplates updateMany
   */
  export type rejectionTemplatesUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update rejectionTemplates.
     */
    data: XOR<rejectionTemplatesUpdateManyMutationInput, rejectionTemplatesUncheckedUpdateManyInput>
    /**
     * Filter which rejectionTemplates to update
     */
    where?: rejectionTemplatesWhereInput
  }

  /**
   * rejectionTemplates upsert
   */
  export type rejectionTemplatesUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the rejectionTemplates
     */
    select?: rejectionTemplatesSelect<ExtArgs> | null
    /**
     * The filter to search for the rejectionTemplates to update in case it exists.
     */
    where: rejectionTemplatesWhereUniqueInput
    /**
     * In case the rejectionTemplates found by the `where` argument doesn't exist, create a new rejectionTemplates with this data.
     */
    create: XOR<rejectionTemplatesCreateInput, rejectionTemplatesUncheckedCreateInput>
    /**
     * In case the rejectionTemplates was found with the provided `where` argument, update it with this data.
     */
    update: XOR<rejectionTemplatesUpdateInput, rejectionTemplatesUncheckedUpdateInput>
  }

  /**
   * rejectionTemplates delete
   */
  export type rejectionTemplatesDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the rejectionTemplates
     */
    select?: rejectionTemplatesSelect<ExtArgs> | null
    /**
     * Filter which rejectionTemplates to delete.
     */
    where: rejectionTemplatesWhereUniqueInput
  }

  /**
   * rejectionTemplates deleteMany
   */
  export type rejectionTemplatesDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which rejectionTemplates to delete
     */
    where?: rejectionTemplatesWhereInput
  }

  /**
   * rejectionTemplates without action
   */
  export type rejectionTemplatesDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the rejectionTemplates
     */
    select?: rejectionTemplatesSelect<ExtArgs> | null
  }


  /**
   * Model markets
   */

  export type AggregateMarkets = {
    _count: MarketsCountAggregateOutputType | null
    _avg: MarketsAvgAggregateOutputType | null
    _sum: MarketsSumAggregateOutputType | null
    _min: MarketsMinAggregateOutputType | null
    _max: MarketsMaxAggregateOutputType | null
  }

  export type MarketsAvgAggregateOutputType = {
    amount: Decimal | null
  }

  export type MarketsSumAggregateOutputType = {
    amount: Decimal | null
  }

  export type MarketsMinAggregateOutputType = {
    id: string | null
    title: string | null
    activityStartDate: Date | null
    activityEndDate: Date | null
    amount: Decimal | null
    location: string | null
  }

  export type MarketsMaxAggregateOutputType = {
    id: string | null
    title: string | null
    activityStartDate: Date | null
    activityEndDate: Date | null
    amount: Decimal | null
    location: string | null
  }

  export type MarketsCountAggregateOutputType = {
    id: number
    title: number
    activityStartDate: number
    activityEndDate: number
    amount: number
    location: number
    _all: number
  }


  export type MarketsAvgAggregateInputType = {
    amount?: true
  }

  export type MarketsSumAggregateInputType = {
    amount?: true
  }

  export type MarketsMinAggregateInputType = {
    id?: true
    title?: true
    activityStartDate?: true
    activityEndDate?: true
    amount?: true
    location?: true
  }

  export type MarketsMaxAggregateInputType = {
    id?: true
    title?: true
    activityStartDate?: true
    activityEndDate?: true
    amount?: true
    location?: true
  }

  export type MarketsCountAggregateInputType = {
    id?: true
    title?: true
    activityStartDate?: true
    activityEndDate?: true
    amount?: true
    location?: true
    _all?: true
  }

  export type MarketsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which markets to aggregate.
     */
    where?: marketsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of markets to fetch.
     */
    orderBy?: marketsOrderByWithRelationInput | marketsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: marketsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` markets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` markets.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned markets
    **/
    _count?: true | MarketsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: MarketsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: MarketsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: MarketsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: MarketsMaxAggregateInputType
  }

  export type GetMarketsAggregateType<T extends MarketsAggregateArgs> = {
        [P in keyof T & keyof AggregateMarkets]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateMarkets[P]>
      : GetScalarType<T[P], AggregateMarkets[P]>
  }




  export type marketsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: marketsWhereInput
    orderBy?: marketsOrderByWithAggregationInput | marketsOrderByWithAggregationInput[]
    by: MarketsScalarFieldEnum[] | MarketsScalarFieldEnum
    having?: marketsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: MarketsCountAggregateInputType | true
    _avg?: MarketsAvgAggregateInputType
    _sum?: MarketsSumAggregateInputType
    _min?: MarketsMinAggregateInputType
    _max?: MarketsMaxAggregateInputType
  }

  export type MarketsGroupByOutputType = {
    id: string
    title: string
    activityStartDate: Date
    activityEndDate: Date
    amount: Decimal
    location: string
    _count: MarketsCountAggregateOutputType | null
    _avg: MarketsAvgAggregateOutputType | null
    _sum: MarketsSumAggregateOutputType | null
    _min: MarketsMinAggregateOutputType | null
    _max: MarketsMaxAggregateOutputType | null
  }

  type GetMarketsGroupByPayload<T extends marketsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<MarketsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof MarketsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], MarketsGroupByOutputType[P]>
            : GetScalarType<T[P], MarketsGroupByOutputType[P]>
        }
      >
    >


  export type marketsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    title?: boolean
    activityStartDate?: boolean
    activityEndDate?: boolean
    amount?: boolean
    location?: boolean
  }, ExtArgs["result"]["markets"]>


  export type marketsSelectScalar = {
    id?: boolean
    title?: boolean
    activityStartDate?: boolean
    activityEndDate?: boolean
    amount?: boolean
    location?: boolean
  }


  export type $marketsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "markets"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      title: string
      activityStartDate: Date
      activityEndDate: Date
      amount: Prisma.Decimal
      location: string
    }, ExtArgs["result"]["markets"]>
    composites: {}
  }

  type marketsGetPayload<S extends boolean | null | undefined | marketsDefaultArgs> = $Result.GetResult<Prisma.$marketsPayload, S>

  type marketsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<marketsFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: MarketsCountAggregateInputType | true
    }

  export interface marketsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['markets'], meta: { name: 'markets' } }
    /**
     * Find zero or one Markets that matches the filter.
     * @param {marketsFindUniqueArgs} args - Arguments to find a Markets
     * @example
     * // Get one Markets
     * const markets = await prisma.markets.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends marketsFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, marketsFindUniqueArgs<ExtArgs>>
    ): Prisma__marketsClient<$Result.GetResult<Prisma.$marketsPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one Markets that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {marketsFindUniqueOrThrowArgs} args - Arguments to find a Markets
     * @example
     * // Get one Markets
     * const markets = await prisma.markets.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends marketsFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, marketsFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__marketsClient<$Result.GetResult<Prisma.$marketsPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first Markets that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {marketsFindFirstArgs} args - Arguments to find a Markets
     * @example
     * // Get one Markets
     * const markets = await prisma.markets.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends marketsFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, marketsFindFirstArgs<ExtArgs>>
    ): Prisma__marketsClient<$Result.GetResult<Prisma.$marketsPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first Markets that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {marketsFindFirstOrThrowArgs} args - Arguments to find a Markets
     * @example
     * // Get one Markets
     * const markets = await prisma.markets.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends marketsFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, marketsFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__marketsClient<$Result.GetResult<Prisma.$marketsPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more Markets that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {marketsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Markets
     * const markets = await prisma.markets.findMany()
     * 
     * // Get first 10 Markets
     * const markets = await prisma.markets.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const marketsWithIdOnly = await prisma.markets.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends marketsFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, marketsFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$marketsPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a Markets.
     * @param {marketsCreateArgs} args - Arguments to create a Markets.
     * @example
     * // Create one Markets
     * const Markets = await prisma.markets.create({
     *   data: {
     *     // ... data to create a Markets
     *   }
     * })
     * 
    **/
    create<T extends marketsCreateArgs<ExtArgs>>(
      args: SelectSubset<T, marketsCreateArgs<ExtArgs>>
    ): Prisma__marketsClient<$Result.GetResult<Prisma.$marketsPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many Markets.
     * @param {marketsCreateManyArgs} args - Arguments to create many Markets.
     * @example
     * // Create many Markets
     * const markets = await prisma.markets.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
    **/
    createMany<T extends marketsCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, marketsCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Markets.
     * @param {marketsDeleteArgs} args - Arguments to delete one Markets.
     * @example
     * // Delete one Markets
     * const Markets = await prisma.markets.delete({
     *   where: {
     *     // ... filter to delete one Markets
     *   }
     * })
     * 
    **/
    delete<T extends marketsDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, marketsDeleteArgs<ExtArgs>>
    ): Prisma__marketsClient<$Result.GetResult<Prisma.$marketsPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one Markets.
     * @param {marketsUpdateArgs} args - Arguments to update one Markets.
     * @example
     * // Update one Markets
     * const markets = await prisma.markets.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends marketsUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, marketsUpdateArgs<ExtArgs>>
    ): Prisma__marketsClient<$Result.GetResult<Prisma.$marketsPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more Markets.
     * @param {marketsDeleteManyArgs} args - Arguments to filter Markets to delete.
     * @example
     * // Delete a few Markets
     * const { count } = await prisma.markets.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends marketsDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, marketsDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Markets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {marketsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Markets
     * const markets = await prisma.markets.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends marketsUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, marketsUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Markets.
     * @param {marketsUpsertArgs} args - Arguments to update or create a Markets.
     * @example
     * // Update or create a Markets
     * const markets = await prisma.markets.upsert({
     *   create: {
     *     // ... data to create a Markets
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Markets we want to update
     *   }
     * })
    **/
    upsert<T extends marketsUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, marketsUpsertArgs<ExtArgs>>
    ): Prisma__marketsClient<$Result.GetResult<Prisma.$marketsPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of Markets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {marketsCountArgs} args - Arguments to filter Markets to count.
     * @example
     * // Count the number of Markets
     * const count = await prisma.markets.count({
     *   where: {
     *     // ... the filter for the Markets we want to count
     *   }
     * })
    **/
    count<T extends marketsCountArgs>(
      args?: Subset<T, marketsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], MarketsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Markets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MarketsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends MarketsAggregateArgs>(args: Subset<T, MarketsAggregateArgs>): Prisma.PrismaPromise<GetMarketsAggregateType<T>>

    /**
     * Group by Markets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {marketsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends marketsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: marketsGroupByArgs['orderBy'] }
        : { orderBy?: marketsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, marketsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetMarketsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the markets model
   */
  readonly fields: marketsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for markets.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__marketsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';


    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the markets model
   */ 
  interface marketsFieldRefs {
    readonly id: FieldRef<"markets", 'String'>
    readonly title: FieldRef<"markets", 'String'>
    readonly activityStartDate: FieldRef<"markets", 'DateTime'>
    readonly activityEndDate: FieldRef<"markets", 'DateTime'>
    readonly amount: FieldRef<"markets", 'Decimal'>
    readonly location: FieldRef<"markets", 'String'>
  }
    

  // Custom InputTypes
  /**
   * markets findUnique
   */
  export type marketsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the markets
     */
    select?: marketsSelect<ExtArgs> | null
    /**
     * Filter, which markets to fetch.
     */
    where: marketsWhereUniqueInput
  }

  /**
   * markets findUniqueOrThrow
   */
  export type marketsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the markets
     */
    select?: marketsSelect<ExtArgs> | null
    /**
     * Filter, which markets to fetch.
     */
    where: marketsWhereUniqueInput
  }

  /**
   * markets findFirst
   */
  export type marketsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the markets
     */
    select?: marketsSelect<ExtArgs> | null
    /**
     * Filter, which markets to fetch.
     */
    where?: marketsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of markets to fetch.
     */
    orderBy?: marketsOrderByWithRelationInput | marketsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for markets.
     */
    cursor?: marketsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` markets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` markets.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of markets.
     */
    distinct?: MarketsScalarFieldEnum | MarketsScalarFieldEnum[]
  }

  /**
   * markets findFirstOrThrow
   */
  export type marketsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the markets
     */
    select?: marketsSelect<ExtArgs> | null
    /**
     * Filter, which markets to fetch.
     */
    where?: marketsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of markets to fetch.
     */
    orderBy?: marketsOrderByWithRelationInput | marketsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for markets.
     */
    cursor?: marketsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` markets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` markets.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of markets.
     */
    distinct?: MarketsScalarFieldEnum | MarketsScalarFieldEnum[]
  }

  /**
   * markets findMany
   */
  export type marketsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the markets
     */
    select?: marketsSelect<ExtArgs> | null
    /**
     * Filter, which markets to fetch.
     */
    where?: marketsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of markets to fetch.
     */
    orderBy?: marketsOrderByWithRelationInput | marketsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing markets.
     */
    cursor?: marketsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` markets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` markets.
     */
    skip?: number
    distinct?: MarketsScalarFieldEnum | MarketsScalarFieldEnum[]
  }

  /**
   * markets create
   */
  export type marketsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the markets
     */
    select?: marketsSelect<ExtArgs> | null
    /**
     * The data needed to create a markets.
     */
    data: XOR<marketsCreateInput, marketsUncheckedCreateInput>
  }

  /**
   * markets createMany
   */
  export type marketsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many markets.
     */
    data: marketsCreateManyInput | marketsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * markets update
   */
  export type marketsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the markets
     */
    select?: marketsSelect<ExtArgs> | null
    /**
     * The data needed to update a markets.
     */
    data: XOR<marketsUpdateInput, marketsUncheckedUpdateInput>
    /**
     * Choose, which markets to update.
     */
    where: marketsWhereUniqueInput
  }

  /**
   * markets updateMany
   */
  export type marketsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update markets.
     */
    data: XOR<marketsUpdateManyMutationInput, marketsUncheckedUpdateManyInput>
    /**
     * Filter which markets to update
     */
    where?: marketsWhereInput
  }

  /**
   * markets upsert
   */
  export type marketsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the markets
     */
    select?: marketsSelect<ExtArgs> | null
    /**
     * The filter to search for the markets to update in case it exists.
     */
    where: marketsWhereUniqueInput
    /**
     * In case the markets found by the `where` argument doesn't exist, create a new markets with this data.
     */
    create: XOR<marketsCreateInput, marketsUncheckedCreateInput>
    /**
     * In case the markets was found with the provided `where` argument, update it with this data.
     */
    update: XOR<marketsUpdateInput, marketsUncheckedUpdateInput>
  }

  /**
   * markets delete
   */
  export type marketsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the markets
     */
    select?: marketsSelect<ExtArgs> | null
    /**
     * Filter which markets to delete.
     */
    where: marketsWhereUniqueInput
  }

  /**
   * markets deleteMany
   */
  export type marketsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which markets to delete
     */
    where?: marketsWhereInput
  }

  /**
   * markets without action
   */
  export type marketsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the markets
     */
    select?: marketsSelect<ExtArgs> | null
  }


  /**
   * Model market_desks
   */

  export type AggregateMarket_desks = {
    _count: Market_desksCountAggregateOutputType | null
    _avg: Market_desksAvgAggregateOutputType | null
    _sum: Market_desksSumAggregateOutputType | null
    _min: Market_desksMinAggregateOutputType | null
    _max: Market_desksMaxAggregateOutputType | null
  }

  export type Market_desksAvgAggregateOutputType = {
    number: number | null
    amount: Decimal | null
  }

  export type Market_desksSumAggregateOutputType = {
    number: number | null
    amount: Decimal | null
  }

  export type Market_desksMinAggregateOutputType = {
    id: string | null
    number: number | null
    title: string | null
    amount: Decimal | null
    parentMarketId: string | null
  }

  export type Market_desksMaxAggregateOutputType = {
    id: string | null
    number: number | null
    title: string | null
    amount: Decimal | null
    parentMarketId: string | null
  }

  export type Market_desksCountAggregateOutputType = {
    id: number
    number: number
    title: number
    amount: number
    parentMarketId: number
    _all: number
  }


  export type Market_desksAvgAggregateInputType = {
    number?: true
    amount?: true
  }

  export type Market_desksSumAggregateInputType = {
    number?: true
    amount?: true
  }

  export type Market_desksMinAggregateInputType = {
    id?: true
    number?: true
    title?: true
    amount?: true
    parentMarketId?: true
  }

  export type Market_desksMaxAggregateInputType = {
    id?: true
    number?: true
    title?: true
    amount?: true
    parentMarketId?: true
  }

  export type Market_desksCountAggregateInputType = {
    id?: true
    number?: true
    title?: true
    amount?: true
    parentMarketId?: true
    _all?: true
  }

  export type Market_desksAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which market_desks to aggregate.
     */
    where?: market_desksWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of market_desks to fetch.
     */
    orderBy?: market_desksOrderByWithRelationInput | market_desksOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: market_desksWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` market_desks from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` market_desks.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned market_desks
    **/
    _count?: true | Market_desksCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: Market_desksAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: Market_desksSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Market_desksMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Market_desksMaxAggregateInputType
  }

  export type GetMarket_desksAggregateType<T extends Market_desksAggregateArgs> = {
        [P in keyof T & keyof AggregateMarket_desks]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateMarket_desks[P]>
      : GetScalarType<T[P], AggregateMarket_desks[P]>
  }




  export type market_desksGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: market_desksWhereInput
    orderBy?: market_desksOrderByWithAggregationInput | market_desksOrderByWithAggregationInput[]
    by: Market_desksScalarFieldEnum[] | Market_desksScalarFieldEnum
    having?: market_desksScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Market_desksCountAggregateInputType | true
    _avg?: Market_desksAvgAggregateInputType
    _sum?: Market_desksSumAggregateInputType
    _min?: Market_desksMinAggregateInputType
    _max?: Market_desksMaxAggregateInputType
  }

  export type Market_desksGroupByOutputType = {
    id: string
    number: number
    title: string
    amount: Decimal
    parentMarketId: string
    _count: Market_desksCountAggregateOutputType | null
    _avg: Market_desksAvgAggregateOutputType | null
    _sum: Market_desksSumAggregateOutputType | null
    _min: Market_desksMinAggregateOutputType | null
    _max: Market_desksMaxAggregateOutputType | null
  }

  type GetMarket_desksGroupByPayload<T extends market_desksGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Market_desksGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Market_desksGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Market_desksGroupByOutputType[P]>
            : GetScalarType<T[P], Market_desksGroupByOutputType[P]>
        }
      >
    >


  export type market_desksSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    number?: boolean
    title?: boolean
    amount?: boolean
    parentMarketId?: boolean
  }, ExtArgs["result"]["market_desks"]>


  export type market_desksSelectScalar = {
    id?: boolean
    number?: boolean
    title?: boolean
    amount?: boolean
    parentMarketId?: boolean
  }


  export type $market_desksPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "market_desks"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      number: number
      title: string
      amount: Prisma.Decimal
      parentMarketId: string
    }, ExtArgs["result"]["market_desks"]>
    composites: {}
  }

  type market_desksGetPayload<S extends boolean | null | undefined | market_desksDefaultArgs> = $Result.GetResult<Prisma.$market_desksPayload, S>

  type market_desksCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<market_desksFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: Market_desksCountAggregateInputType | true
    }

  export interface market_desksDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['market_desks'], meta: { name: 'market_desks' } }
    /**
     * Find zero or one Market_desks that matches the filter.
     * @param {market_desksFindUniqueArgs} args - Arguments to find a Market_desks
     * @example
     * // Get one Market_desks
     * const market_desks = await prisma.market_desks.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends market_desksFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, market_desksFindUniqueArgs<ExtArgs>>
    ): Prisma__market_desksClient<$Result.GetResult<Prisma.$market_desksPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one Market_desks that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {market_desksFindUniqueOrThrowArgs} args - Arguments to find a Market_desks
     * @example
     * // Get one Market_desks
     * const market_desks = await prisma.market_desks.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends market_desksFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, market_desksFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__market_desksClient<$Result.GetResult<Prisma.$market_desksPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first Market_desks that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {market_desksFindFirstArgs} args - Arguments to find a Market_desks
     * @example
     * // Get one Market_desks
     * const market_desks = await prisma.market_desks.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends market_desksFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, market_desksFindFirstArgs<ExtArgs>>
    ): Prisma__market_desksClient<$Result.GetResult<Prisma.$market_desksPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first Market_desks that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {market_desksFindFirstOrThrowArgs} args - Arguments to find a Market_desks
     * @example
     * // Get one Market_desks
     * const market_desks = await prisma.market_desks.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends market_desksFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, market_desksFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__market_desksClient<$Result.GetResult<Prisma.$market_desksPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more Market_desks that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {market_desksFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Market_desks
     * const market_desks = await prisma.market_desks.findMany()
     * 
     * // Get first 10 Market_desks
     * const market_desks = await prisma.market_desks.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const market_desksWithIdOnly = await prisma.market_desks.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends market_desksFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, market_desksFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$market_desksPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a Market_desks.
     * @param {market_desksCreateArgs} args - Arguments to create a Market_desks.
     * @example
     * // Create one Market_desks
     * const Market_desks = await prisma.market_desks.create({
     *   data: {
     *     // ... data to create a Market_desks
     *   }
     * })
     * 
    **/
    create<T extends market_desksCreateArgs<ExtArgs>>(
      args: SelectSubset<T, market_desksCreateArgs<ExtArgs>>
    ): Prisma__market_desksClient<$Result.GetResult<Prisma.$market_desksPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many Market_desks.
     * @param {market_desksCreateManyArgs} args - Arguments to create many Market_desks.
     * @example
     * // Create many Market_desks
     * const market_desks = await prisma.market_desks.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
    **/
    createMany<T extends market_desksCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, market_desksCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Market_desks.
     * @param {market_desksDeleteArgs} args - Arguments to delete one Market_desks.
     * @example
     * // Delete one Market_desks
     * const Market_desks = await prisma.market_desks.delete({
     *   where: {
     *     // ... filter to delete one Market_desks
     *   }
     * })
     * 
    **/
    delete<T extends market_desksDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, market_desksDeleteArgs<ExtArgs>>
    ): Prisma__market_desksClient<$Result.GetResult<Prisma.$market_desksPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one Market_desks.
     * @param {market_desksUpdateArgs} args - Arguments to update one Market_desks.
     * @example
     * // Update one Market_desks
     * const market_desks = await prisma.market_desks.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends market_desksUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, market_desksUpdateArgs<ExtArgs>>
    ): Prisma__market_desksClient<$Result.GetResult<Prisma.$market_desksPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more Market_desks.
     * @param {market_desksDeleteManyArgs} args - Arguments to filter Market_desks to delete.
     * @example
     * // Delete a few Market_desks
     * const { count } = await prisma.market_desks.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends market_desksDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, market_desksDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Market_desks.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {market_desksUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Market_desks
     * const market_desks = await prisma.market_desks.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends market_desksUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, market_desksUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Market_desks.
     * @param {market_desksUpsertArgs} args - Arguments to update or create a Market_desks.
     * @example
     * // Update or create a Market_desks
     * const market_desks = await prisma.market_desks.upsert({
     *   create: {
     *     // ... data to create a Market_desks
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Market_desks we want to update
     *   }
     * })
    **/
    upsert<T extends market_desksUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, market_desksUpsertArgs<ExtArgs>>
    ): Prisma__market_desksClient<$Result.GetResult<Prisma.$market_desksPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of Market_desks.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {market_desksCountArgs} args - Arguments to filter Market_desks to count.
     * @example
     * // Count the number of Market_desks
     * const count = await prisma.market_desks.count({
     *   where: {
     *     // ... the filter for the Market_desks we want to count
     *   }
     * })
    **/
    count<T extends market_desksCountArgs>(
      args?: Subset<T, market_desksCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Market_desksCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Market_desks.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Market_desksAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Market_desksAggregateArgs>(args: Subset<T, Market_desksAggregateArgs>): Prisma.PrismaPromise<GetMarket_desksAggregateType<T>>

    /**
     * Group by Market_desks.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {market_desksGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends market_desksGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: market_desksGroupByArgs['orderBy'] }
        : { orderBy?: market_desksGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, market_desksGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetMarket_desksGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the market_desks model
   */
  readonly fields: market_desksFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for market_desks.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__market_desksClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';


    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the market_desks model
   */ 
  interface market_desksFieldRefs {
    readonly id: FieldRef<"market_desks", 'String'>
    readonly number: FieldRef<"market_desks", 'Int'>
    readonly title: FieldRef<"market_desks", 'String'>
    readonly amount: FieldRef<"market_desks", 'Decimal'>
    readonly parentMarketId: FieldRef<"market_desks", 'String'>
  }
    

  // Custom InputTypes
  /**
   * market_desks findUnique
   */
  export type market_desksFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the market_desks
     */
    select?: market_desksSelect<ExtArgs> | null
    /**
     * Filter, which market_desks to fetch.
     */
    where: market_desksWhereUniqueInput
  }

  /**
   * market_desks findUniqueOrThrow
   */
  export type market_desksFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the market_desks
     */
    select?: market_desksSelect<ExtArgs> | null
    /**
     * Filter, which market_desks to fetch.
     */
    where: market_desksWhereUniqueInput
  }

  /**
   * market_desks findFirst
   */
  export type market_desksFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the market_desks
     */
    select?: market_desksSelect<ExtArgs> | null
    /**
     * Filter, which market_desks to fetch.
     */
    where?: market_desksWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of market_desks to fetch.
     */
    orderBy?: market_desksOrderByWithRelationInput | market_desksOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for market_desks.
     */
    cursor?: market_desksWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` market_desks from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` market_desks.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of market_desks.
     */
    distinct?: Market_desksScalarFieldEnum | Market_desksScalarFieldEnum[]
  }

  /**
   * market_desks findFirstOrThrow
   */
  export type market_desksFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the market_desks
     */
    select?: market_desksSelect<ExtArgs> | null
    /**
     * Filter, which market_desks to fetch.
     */
    where?: market_desksWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of market_desks to fetch.
     */
    orderBy?: market_desksOrderByWithRelationInput | market_desksOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for market_desks.
     */
    cursor?: market_desksWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` market_desks from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` market_desks.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of market_desks.
     */
    distinct?: Market_desksScalarFieldEnum | Market_desksScalarFieldEnum[]
  }

  /**
   * market_desks findMany
   */
  export type market_desksFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the market_desks
     */
    select?: market_desksSelect<ExtArgs> | null
    /**
     * Filter, which market_desks to fetch.
     */
    where?: market_desksWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of market_desks to fetch.
     */
    orderBy?: market_desksOrderByWithRelationInput | market_desksOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing market_desks.
     */
    cursor?: market_desksWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` market_desks from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` market_desks.
     */
    skip?: number
    distinct?: Market_desksScalarFieldEnum | Market_desksScalarFieldEnum[]
  }

  /**
   * market_desks create
   */
  export type market_desksCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the market_desks
     */
    select?: market_desksSelect<ExtArgs> | null
    /**
     * The data needed to create a market_desks.
     */
    data: XOR<market_desksCreateInput, market_desksUncheckedCreateInput>
  }

  /**
   * market_desks createMany
   */
  export type market_desksCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many market_desks.
     */
    data: market_desksCreateManyInput | market_desksCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * market_desks update
   */
  export type market_desksUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the market_desks
     */
    select?: market_desksSelect<ExtArgs> | null
    /**
     * The data needed to update a market_desks.
     */
    data: XOR<market_desksUpdateInput, market_desksUncheckedUpdateInput>
    /**
     * Choose, which market_desks to update.
     */
    where: market_desksWhereUniqueInput
  }

  /**
   * market_desks updateMany
   */
  export type market_desksUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update market_desks.
     */
    data: XOR<market_desksUpdateManyMutationInput, market_desksUncheckedUpdateManyInput>
    /**
     * Filter which market_desks to update
     */
    where?: market_desksWhereInput
  }

  /**
   * market_desks upsert
   */
  export type market_desksUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the market_desks
     */
    select?: market_desksSelect<ExtArgs> | null
    /**
     * The filter to search for the market_desks to update in case it exists.
     */
    where: market_desksWhereUniqueInput
    /**
     * In case the market_desks found by the `where` argument doesn't exist, create a new market_desks with this data.
     */
    create: XOR<market_desksCreateInput, market_desksUncheckedCreateInput>
    /**
     * In case the market_desks was found with the provided `where` argument, update it with this data.
     */
    update: XOR<market_desksUpdateInput, market_desksUncheckedUpdateInput>
  }

  /**
   * market_desks delete
   */
  export type market_desksDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the market_desks
     */
    select?: market_desksSelect<ExtArgs> | null
    /**
     * Filter which market_desks to delete.
     */
    where: market_desksWhereUniqueInput
  }

  /**
   * market_desks deleteMany
   */
  export type market_desksDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which market_desks to delete
     */
    where?: market_desksWhereInput
  }

  /**
   * market_desks without action
   */
  export type market_desksDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the market_desks
     */
    select?: market_desksSelect<ExtArgs> | null
  }


  /**
   * Model reversed_markets
   */

  export type AggregateReversed_markets = {
    _count: Reversed_marketsCountAggregateOutputType | null
    _min: Reversed_marketsMinAggregateOutputType | null
    _max: Reversed_marketsMaxAggregateOutputType | null
  }

  export type Reversed_marketsMinAggregateOutputType = {
    id: string | null
    marketId: string | null
    deskId: string | null
    userId: string | null
    isPurchased: boolean | null
  }

  export type Reversed_marketsMaxAggregateOutputType = {
    id: string | null
    marketId: string | null
    deskId: string | null
    userId: string | null
    isPurchased: boolean | null
  }

  export type Reversed_marketsCountAggregateOutputType = {
    id: number
    marketId: number
    deskId: number
    userId: number
    isPurchased: number
    _all: number
  }


  export type Reversed_marketsMinAggregateInputType = {
    id?: true
    marketId?: true
    deskId?: true
    userId?: true
    isPurchased?: true
  }

  export type Reversed_marketsMaxAggregateInputType = {
    id?: true
    marketId?: true
    deskId?: true
    userId?: true
    isPurchased?: true
  }

  export type Reversed_marketsCountAggregateInputType = {
    id?: true
    marketId?: true
    deskId?: true
    userId?: true
    isPurchased?: true
    _all?: true
  }

  export type Reversed_marketsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which reversed_markets to aggregate.
     */
    where?: reversed_marketsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of reversed_markets to fetch.
     */
    orderBy?: reversed_marketsOrderByWithRelationInput | reversed_marketsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: reversed_marketsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` reversed_markets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` reversed_markets.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned reversed_markets
    **/
    _count?: true | Reversed_marketsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Reversed_marketsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Reversed_marketsMaxAggregateInputType
  }

  export type GetReversed_marketsAggregateType<T extends Reversed_marketsAggregateArgs> = {
        [P in keyof T & keyof AggregateReversed_markets]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateReversed_markets[P]>
      : GetScalarType<T[P], AggregateReversed_markets[P]>
  }




  export type reversed_marketsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: reversed_marketsWhereInput
    orderBy?: reversed_marketsOrderByWithAggregationInput | reversed_marketsOrderByWithAggregationInput[]
    by: Reversed_marketsScalarFieldEnum[] | Reversed_marketsScalarFieldEnum
    having?: reversed_marketsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Reversed_marketsCountAggregateInputType | true
    _min?: Reversed_marketsMinAggregateInputType
    _max?: Reversed_marketsMaxAggregateInputType
  }

  export type Reversed_marketsGroupByOutputType = {
    id: string
    marketId: string
    deskId: string
    userId: string
    isPurchased: boolean
    _count: Reversed_marketsCountAggregateOutputType | null
    _min: Reversed_marketsMinAggregateOutputType | null
    _max: Reversed_marketsMaxAggregateOutputType | null
  }

  type GetReversed_marketsGroupByPayload<T extends reversed_marketsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Reversed_marketsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Reversed_marketsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Reversed_marketsGroupByOutputType[P]>
            : GetScalarType<T[P], Reversed_marketsGroupByOutputType[P]>
        }
      >
    >


  export type reversed_marketsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    marketId?: boolean
    deskId?: boolean
    userId?: boolean
    isPurchased?: boolean
  }, ExtArgs["result"]["reversed_markets"]>


  export type reversed_marketsSelectScalar = {
    id?: boolean
    marketId?: boolean
    deskId?: boolean
    userId?: boolean
    isPurchased?: boolean
  }


  export type $reversed_marketsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "reversed_markets"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      marketId: string
      deskId: string
      userId: string
      isPurchased: boolean
    }, ExtArgs["result"]["reversed_markets"]>
    composites: {}
  }

  type reversed_marketsGetPayload<S extends boolean | null | undefined | reversed_marketsDefaultArgs> = $Result.GetResult<Prisma.$reversed_marketsPayload, S>

  type reversed_marketsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<reversed_marketsFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: Reversed_marketsCountAggregateInputType | true
    }

  export interface reversed_marketsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['reversed_markets'], meta: { name: 'reversed_markets' } }
    /**
     * Find zero or one Reversed_markets that matches the filter.
     * @param {reversed_marketsFindUniqueArgs} args - Arguments to find a Reversed_markets
     * @example
     * // Get one Reversed_markets
     * const reversed_markets = await prisma.reversed_markets.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends reversed_marketsFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, reversed_marketsFindUniqueArgs<ExtArgs>>
    ): Prisma__reversed_marketsClient<$Result.GetResult<Prisma.$reversed_marketsPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one Reversed_markets that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {reversed_marketsFindUniqueOrThrowArgs} args - Arguments to find a Reversed_markets
     * @example
     * // Get one Reversed_markets
     * const reversed_markets = await prisma.reversed_markets.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends reversed_marketsFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, reversed_marketsFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__reversed_marketsClient<$Result.GetResult<Prisma.$reversed_marketsPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first Reversed_markets that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {reversed_marketsFindFirstArgs} args - Arguments to find a Reversed_markets
     * @example
     * // Get one Reversed_markets
     * const reversed_markets = await prisma.reversed_markets.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends reversed_marketsFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, reversed_marketsFindFirstArgs<ExtArgs>>
    ): Prisma__reversed_marketsClient<$Result.GetResult<Prisma.$reversed_marketsPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first Reversed_markets that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {reversed_marketsFindFirstOrThrowArgs} args - Arguments to find a Reversed_markets
     * @example
     * // Get one Reversed_markets
     * const reversed_markets = await prisma.reversed_markets.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends reversed_marketsFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, reversed_marketsFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__reversed_marketsClient<$Result.GetResult<Prisma.$reversed_marketsPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more Reversed_markets that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {reversed_marketsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Reversed_markets
     * const reversed_markets = await prisma.reversed_markets.findMany()
     * 
     * // Get first 10 Reversed_markets
     * const reversed_markets = await prisma.reversed_markets.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const reversed_marketsWithIdOnly = await prisma.reversed_markets.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends reversed_marketsFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, reversed_marketsFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$reversed_marketsPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a Reversed_markets.
     * @param {reversed_marketsCreateArgs} args - Arguments to create a Reversed_markets.
     * @example
     * // Create one Reversed_markets
     * const Reversed_markets = await prisma.reversed_markets.create({
     *   data: {
     *     // ... data to create a Reversed_markets
     *   }
     * })
     * 
    **/
    create<T extends reversed_marketsCreateArgs<ExtArgs>>(
      args: SelectSubset<T, reversed_marketsCreateArgs<ExtArgs>>
    ): Prisma__reversed_marketsClient<$Result.GetResult<Prisma.$reversed_marketsPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many Reversed_markets.
     * @param {reversed_marketsCreateManyArgs} args - Arguments to create many Reversed_markets.
     * @example
     * // Create many Reversed_markets
     * const reversed_markets = await prisma.reversed_markets.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
    **/
    createMany<T extends reversed_marketsCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, reversed_marketsCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Reversed_markets.
     * @param {reversed_marketsDeleteArgs} args - Arguments to delete one Reversed_markets.
     * @example
     * // Delete one Reversed_markets
     * const Reversed_markets = await prisma.reversed_markets.delete({
     *   where: {
     *     // ... filter to delete one Reversed_markets
     *   }
     * })
     * 
    **/
    delete<T extends reversed_marketsDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, reversed_marketsDeleteArgs<ExtArgs>>
    ): Prisma__reversed_marketsClient<$Result.GetResult<Prisma.$reversed_marketsPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one Reversed_markets.
     * @param {reversed_marketsUpdateArgs} args - Arguments to update one Reversed_markets.
     * @example
     * // Update one Reversed_markets
     * const reversed_markets = await prisma.reversed_markets.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends reversed_marketsUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, reversed_marketsUpdateArgs<ExtArgs>>
    ): Prisma__reversed_marketsClient<$Result.GetResult<Prisma.$reversed_marketsPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more Reversed_markets.
     * @param {reversed_marketsDeleteManyArgs} args - Arguments to filter Reversed_markets to delete.
     * @example
     * // Delete a few Reversed_markets
     * const { count } = await prisma.reversed_markets.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends reversed_marketsDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, reversed_marketsDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Reversed_markets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {reversed_marketsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Reversed_markets
     * const reversed_markets = await prisma.reversed_markets.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends reversed_marketsUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, reversed_marketsUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Reversed_markets.
     * @param {reversed_marketsUpsertArgs} args - Arguments to update or create a Reversed_markets.
     * @example
     * // Update or create a Reversed_markets
     * const reversed_markets = await prisma.reversed_markets.upsert({
     *   create: {
     *     // ... data to create a Reversed_markets
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Reversed_markets we want to update
     *   }
     * })
    **/
    upsert<T extends reversed_marketsUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, reversed_marketsUpsertArgs<ExtArgs>>
    ): Prisma__reversed_marketsClient<$Result.GetResult<Prisma.$reversed_marketsPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of Reversed_markets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {reversed_marketsCountArgs} args - Arguments to filter Reversed_markets to count.
     * @example
     * // Count the number of Reversed_markets
     * const count = await prisma.reversed_markets.count({
     *   where: {
     *     // ... the filter for the Reversed_markets we want to count
     *   }
     * })
    **/
    count<T extends reversed_marketsCountArgs>(
      args?: Subset<T, reversed_marketsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Reversed_marketsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Reversed_markets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Reversed_marketsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Reversed_marketsAggregateArgs>(args: Subset<T, Reversed_marketsAggregateArgs>): Prisma.PrismaPromise<GetReversed_marketsAggregateType<T>>

    /**
     * Group by Reversed_markets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {reversed_marketsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends reversed_marketsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: reversed_marketsGroupByArgs['orderBy'] }
        : { orderBy?: reversed_marketsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, reversed_marketsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetReversed_marketsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the reversed_markets model
   */
  readonly fields: reversed_marketsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for reversed_markets.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__reversed_marketsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';


    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the reversed_markets model
   */ 
  interface reversed_marketsFieldRefs {
    readonly id: FieldRef<"reversed_markets", 'String'>
    readonly marketId: FieldRef<"reversed_markets", 'String'>
    readonly deskId: FieldRef<"reversed_markets", 'String'>
    readonly userId: FieldRef<"reversed_markets", 'String'>
    readonly isPurchased: FieldRef<"reversed_markets", 'Boolean'>
  }
    

  // Custom InputTypes
  /**
   * reversed_markets findUnique
   */
  export type reversed_marketsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the reversed_markets
     */
    select?: reversed_marketsSelect<ExtArgs> | null
    /**
     * Filter, which reversed_markets to fetch.
     */
    where: reversed_marketsWhereUniqueInput
  }

  /**
   * reversed_markets findUniqueOrThrow
   */
  export type reversed_marketsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the reversed_markets
     */
    select?: reversed_marketsSelect<ExtArgs> | null
    /**
     * Filter, which reversed_markets to fetch.
     */
    where: reversed_marketsWhereUniqueInput
  }

  /**
   * reversed_markets findFirst
   */
  export type reversed_marketsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the reversed_markets
     */
    select?: reversed_marketsSelect<ExtArgs> | null
    /**
     * Filter, which reversed_markets to fetch.
     */
    where?: reversed_marketsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of reversed_markets to fetch.
     */
    orderBy?: reversed_marketsOrderByWithRelationInput | reversed_marketsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for reversed_markets.
     */
    cursor?: reversed_marketsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` reversed_markets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` reversed_markets.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of reversed_markets.
     */
    distinct?: Reversed_marketsScalarFieldEnum | Reversed_marketsScalarFieldEnum[]
  }

  /**
   * reversed_markets findFirstOrThrow
   */
  export type reversed_marketsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the reversed_markets
     */
    select?: reversed_marketsSelect<ExtArgs> | null
    /**
     * Filter, which reversed_markets to fetch.
     */
    where?: reversed_marketsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of reversed_markets to fetch.
     */
    orderBy?: reversed_marketsOrderByWithRelationInput | reversed_marketsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for reversed_markets.
     */
    cursor?: reversed_marketsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` reversed_markets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` reversed_markets.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of reversed_markets.
     */
    distinct?: Reversed_marketsScalarFieldEnum | Reversed_marketsScalarFieldEnum[]
  }

  /**
   * reversed_markets findMany
   */
  export type reversed_marketsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the reversed_markets
     */
    select?: reversed_marketsSelect<ExtArgs> | null
    /**
     * Filter, which reversed_markets to fetch.
     */
    where?: reversed_marketsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of reversed_markets to fetch.
     */
    orderBy?: reversed_marketsOrderByWithRelationInput | reversed_marketsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing reversed_markets.
     */
    cursor?: reversed_marketsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` reversed_markets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` reversed_markets.
     */
    skip?: number
    distinct?: Reversed_marketsScalarFieldEnum | Reversed_marketsScalarFieldEnum[]
  }

  /**
   * reversed_markets create
   */
  export type reversed_marketsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the reversed_markets
     */
    select?: reversed_marketsSelect<ExtArgs> | null
    /**
     * The data needed to create a reversed_markets.
     */
    data: XOR<reversed_marketsCreateInput, reversed_marketsUncheckedCreateInput>
  }

  /**
   * reversed_markets createMany
   */
  export type reversed_marketsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many reversed_markets.
     */
    data: reversed_marketsCreateManyInput | reversed_marketsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * reversed_markets update
   */
  export type reversed_marketsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the reversed_markets
     */
    select?: reversed_marketsSelect<ExtArgs> | null
    /**
     * The data needed to update a reversed_markets.
     */
    data: XOR<reversed_marketsUpdateInput, reversed_marketsUncheckedUpdateInput>
    /**
     * Choose, which reversed_markets to update.
     */
    where: reversed_marketsWhereUniqueInput
  }

  /**
   * reversed_markets updateMany
   */
  export type reversed_marketsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update reversed_markets.
     */
    data: XOR<reversed_marketsUpdateManyMutationInput, reversed_marketsUncheckedUpdateManyInput>
    /**
     * Filter which reversed_markets to update
     */
    where?: reversed_marketsWhereInput
  }

  /**
   * reversed_markets upsert
   */
  export type reversed_marketsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the reversed_markets
     */
    select?: reversed_marketsSelect<ExtArgs> | null
    /**
     * The filter to search for the reversed_markets to update in case it exists.
     */
    where: reversed_marketsWhereUniqueInput
    /**
     * In case the reversed_markets found by the `where` argument doesn't exist, create a new reversed_markets with this data.
     */
    create: XOR<reversed_marketsCreateInput, reversed_marketsUncheckedCreateInput>
    /**
     * In case the reversed_markets was found with the provided `where` argument, update it with this data.
     */
    update: XOR<reversed_marketsUpdateInput, reversed_marketsUncheckedUpdateInput>
  }

  /**
   * reversed_markets delete
   */
  export type reversed_marketsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the reversed_markets
     */
    select?: reversed_marketsSelect<ExtArgs> | null
    /**
     * Filter which reversed_markets to delete.
     */
    where: reversed_marketsWhereUniqueInput
  }

  /**
   * reversed_markets deleteMany
   */
  export type reversed_marketsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which reversed_markets to delete
     */
    where?: reversed_marketsWhereInput
  }

  /**
   * reversed_markets without action
   */
  export type reversed_marketsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the reversed_markets
     */
    select?: reversed_marketsSelect<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const UsersScalarFieldEnum: {
    id: 'id',
    username: 'username',
    password: 'password',
    name: 'name',
    family: 'family',
    fatherName: 'fatherName',
    creationTime: 'creationTime',
    isDeleted: 'isDeleted',
    metaData: 'metaData',
    creatorId: 'creatorId',
    accessPermissionGroupId: 'accessPermissionGroupId'
  };

  export type UsersScalarFieldEnum = (typeof UsersScalarFieldEnum)[keyof typeof UsersScalarFieldEnum]


  export const Access_permission_groupScalarFieldEnum: {
    id: 'id',
    title: 'title',
    name: 'name',
    isDeletable: 'isDeletable',
    createDate: 'createDate'
  };

  export type Access_permission_groupScalarFieldEnum = (typeof Access_permission_groupScalarFieldEnum)[keyof typeof Access_permission_groupScalarFieldEnum]


  export const Access_permission_group_itemsScalarFieldEnum: {
    id: 'id',
    userOrParentAccessPermissionId: 'userOrParentAccessPermissionId',
    providerKey: 'providerKey',
    creatorId: 'creatorId',
    createDate: 'createDate'
  };

  export type Access_permission_group_itemsScalarFieldEnum = (typeof Access_permission_group_itemsScalarFieldEnum)[keyof typeof Access_permission_group_itemsScalarFieldEnum]


  export const SettingsScalarFieldEnum: {
    id: 'id',
    providerKey: 'providerKey',
    providerValue: 'providerValue',
    creatorId: 'creatorId',
    createDate: 'createDate'
  };

  export type SettingsScalarFieldEnum = (typeof SettingsScalarFieldEnum)[keyof typeof SettingsScalarFieldEnum]


  export const IpgsScalarFieldEnum: {
    id: 'id',
    provider: 'provider',
    merchantId: 'merchantId',
    terminalId: 'terminalId',
    terminalKey: 'terminalKey',
    isActive: 'isActive',
    creationTime: 'creationTime',
    creatorId: 'creatorId'
  };

  export type IpgsScalarFieldEnum = (typeof IpgsScalarFieldEnum)[keyof typeof IpgsScalarFieldEnum]


  export const ReuqestcodesScalarFieldEnum: {
    id: 'id',
    mobileNumber: 'mobileNumber',
    code: 'code',
    createDate: 'createDate'
  };

  export type ReuqestcodesScalarFieldEnum = (typeof ReuqestcodesScalarFieldEnum)[keyof typeof ReuqestcodesScalarFieldEnum]


  export const BaseDataScalarFieldEnum: {
    id: 'id',
    providerKey: 'providerKey',
    providerValue: 'providerValue',
    providerData: 'providerData',
    providerData_2: 'providerData_2',
    createDate: 'createDate'
  };

  export type BaseDataScalarFieldEnum = (typeof BaseDataScalarFieldEnum)[keyof typeof BaseDataScalarFieldEnum]


  export const MembersScalarFieldEnum: {
    id: 'id',
    name: 'name',
    family: 'family',
    nationalCode: 'nationalCode',
    fatherName: 'fatherName',
    disabilityStatus: 'disabilityStatus',
    disabilityDescription: 'disabilityDescription',
    partnerJob: 'partnerJob',
    educationLevel: 'educationLevel',
    maritalStatus: 'maritalStatus',
    childrenCounts: 'childrenCounts',
    birthDate: 'birthDate',
    mobileNumber: 'mobileNumber',
    address: 'address',
    username: 'username',
    password: 'password',
    status: 'status',
    creationTime: 'creationTime',
    creatorId: 'creatorId',
    isDeleted: 'isDeleted'
  };

  export type MembersScalarFieldEnum = (typeof MembersScalarFieldEnum)[keyof typeof MembersScalarFieldEnum]


  export const Members_product_itemsScalarFieldEnum: {
    id: 'id',
    parentMemberId: 'parentMemberId',
    title: 'title',
    ownProduct: 'ownProduct'
  };

  export type Members_product_itemsScalarFieldEnum = (typeof Members_product_itemsScalarFieldEnum)[keyof typeof Members_product_itemsScalarFieldEnum]


  export const ImageSliderScalarFieldEnum: {
    id: 'id',
    fileId: 'fileId',
    title: 'title',
    creationTime: 'creationTime',
    creatorId: 'creatorId'
  };

  export type ImageSliderScalarFieldEnum = (typeof ImageSliderScalarFieldEnum)[keyof typeof ImageSliderScalarFieldEnum]


  export const ProfileImageSliderScalarFieldEnum: {
    id: 'id',
    fileId: 'fileId',
    targetUrl: 'targetUrl',
    creationTime: 'creationTime',
    creatorId: 'creatorId'
  };

  export type ProfileImageSliderScalarFieldEnum = (typeof ProfileImageSliderScalarFieldEnum)[keyof typeof ProfileImageSliderScalarFieldEnum]


  export const Upload_document_templateScalarFieldEnum: {
    id: 'id',
    title: 'title',
    maximumSizeInMb: 'maximumSizeInMb',
    isRequired: 'isRequired',
    showWhen: 'showWhen',
    creationTime: 'creationTime',
    creatorId: 'creatorId'
  };

  export type Upload_document_templateScalarFieldEnum = (typeof Upload_document_templateScalarFieldEnum)[keyof typeof Upload_document_templateScalarFieldEnum]


  export const UploadedDocumentsScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    templateId: 'templateId',
    filePath: 'filePath',
    creationTime: 'creationTime'
  };

  export type UploadedDocumentsScalarFieldEnum = (typeof UploadedDocumentsScalarFieldEnum)[keyof typeof UploadedDocumentsScalarFieldEnum]


  export const RejectionTemplatesScalarFieldEnum: {
    id: 'id',
    title: 'title',
    creationTime: 'creationTime',
    creatorId: 'creatorId'
  };

  export type RejectionTemplatesScalarFieldEnum = (typeof RejectionTemplatesScalarFieldEnum)[keyof typeof RejectionTemplatesScalarFieldEnum]


  export const MarketsScalarFieldEnum: {
    id: 'id',
    title: 'title',
    activityStartDate: 'activityStartDate',
    activityEndDate: 'activityEndDate',
    amount: 'amount',
    location: 'location'
  };

  export type MarketsScalarFieldEnum = (typeof MarketsScalarFieldEnum)[keyof typeof MarketsScalarFieldEnum]


  export const Market_desksScalarFieldEnum: {
    id: 'id',
    number: 'number',
    title: 'title',
    amount: 'amount',
    parentMarketId: 'parentMarketId'
  };

  export type Market_desksScalarFieldEnum = (typeof Market_desksScalarFieldEnum)[keyof typeof Market_desksScalarFieldEnum]


  export const Reversed_marketsScalarFieldEnum: {
    id: 'id',
    marketId: 'marketId',
    deskId: 'deskId',
    userId: 'userId',
    isPurchased: 'isPurchased'
  };

  export type Reversed_marketsScalarFieldEnum = (typeof Reversed_marketsScalarFieldEnum)[keyof typeof Reversed_marketsScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  /**
   * Field references 
   */


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Decimal'
   */
  export type DecimalFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Decimal'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    
  /**
   * Deep Input Types
   */


  export type usersWhereInput = {
    AND?: usersWhereInput | usersWhereInput[]
    OR?: usersWhereInput[]
    NOT?: usersWhereInput | usersWhereInput[]
    id?: StringFilter<"users"> | string
    username?: StringNullableFilter<"users"> | string | null
    password?: StringNullableFilter<"users"> | string | null
    name?: StringNullableFilter<"users"> | string | null
    family?: StringNullableFilter<"users"> | string | null
    fatherName?: StringNullableFilter<"users"> | string | null
    creationTime?: DateTimeFilter<"users"> | Date | string
    isDeleted?: BoolFilter<"users"> | boolean
    metaData?: StringNullableFilter<"users"> | string | null
    creatorId?: StringNullableFilter<"users"> | string | null
    accessPermissionGroupId?: StringFilter<"users"> | string
    permissionGroupId?: XOR<Access_permission_groupNullableRelationFilter, access_permission_groupWhereInput> | null
  }

  export type usersOrderByWithRelationInput = {
    id?: SortOrder
    username?: SortOrderInput | SortOrder
    password?: SortOrderInput | SortOrder
    name?: SortOrderInput | SortOrder
    family?: SortOrderInput | SortOrder
    fatherName?: SortOrderInput | SortOrder
    creationTime?: SortOrder
    isDeleted?: SortOrder
    metaData?: SortOrderInput | SortOrder
    creatorId?: SortOrderInput | SortOrder
    accessPermissionGroupId?: SortOrder
    permissionGroupId?: access_permission_groupOrderByWithRelationInput
  }

  export type usersWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: usersWhereInput | usersWhereInput[]
    OR?: usersWhereInput[]
    NOT?: usersWhereInput | usersWhereInput[]
    username?: StringNullableFilter<"users"> | string | null
    password?: StringNullableFilter<"users"> | string | null
    name?: StringNullableFilter<"users"> | string | null
    family?: StringNullableFilter<"users"> | string | null
    fatherName?: StringNullableFilter<"users"> | string | null
    creationTime?: DateTimeFilter<"users"> | Date | string
    isDeleted?: BoolFilter<"users"> | boolean
    metaData?: StringNullableFilter<"users"> | string | null
    creatorId?: StringNullableFilter<"users"> | string | null
    accessPermissionGroupId?: StringFilter<"users"> | string
    permissionGroupId?: XOR<Access_permission_groupNullableRelationFilter, access_permission_groupWhereInput> | null
  }, "id">

  export type usersOrderByWithAggregationInput = {
    id?: SortOrder
    username?: SortOrderInput | SortOrder
    password?: SortOrderInput | SortOrder
    name?: SortOrderInput | SortOrder
    family?: SortOrderInput | SortOrder
    fatherName?: SortOrderInput | SortOrder
    creationTime?: SortOrder
    isDeleted?: SortOrder
    metaData?: SortOrderInput | SortOrder
    creatorId?: SortOrderInput | SortOrder
    accessPermissionGroupId?: SortOrder
    _count?: usersCountOrderByAggregateInput
    _max?: usersMaxOrderByAggregateInput
    _min?: usersMinOrderByAggregateInput
  }

  export type usersScalarWhereWithAggregatesInput = {
    AND?: usersScalarWhereWithAggregatesInput | usersScalarWhereWithAggregatesInput[]
    OR?: usersScalarWhereWithAggregatesInput[]
    NOT?: usersScalarWhereWithAggregatesInput | usersScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"users"> | string
    username?: StringNullableWithAggregatesFilter<"users"> | string | null
    password?: StringNullableWithAggregatesFilter<"users"> | string | null
    name?: StringNullableWithAggregatesFilter<"users"> | string | null
    family?: StringNullableWithAggregatesFilter<"users"> | string | null
    fatherName?: StringNullableWithAggregatesFilter<"users"> | string | null
    creationTime?: DateTimeWithAggregatesFilter<"users"> | Date | string
    isDeleted?: BoolWithAggregatesFilter<"users"> | boolean
    metaData?: StringNullableWithAggregatesFilter<"users"> | string | null
    creatorId?: StringNullableWithAggregatesFilter<"users"> | string | null
    accessPermissionGroupId?: StringWithAggregatesFilter<"users"> | string
  }

  export type access_permission_groupWhereInput = {
    AND?: access_permission_groupWhereInput | access_permission_groupWhereInput[]
    OR?: access_permission_groupWhereInput[]
    NOT?: access_permission_groupWhereInput | access_permission_groupWhereInput[]
    id?: StringFilter<"access_permission_group"> | string
    title?: StringNullableFilter<"access_permission_group"> | string | null
    name?: StringFilter<"access_permission_group"> | string
    isDeletable?: BoolFilter<"access_permission_group"> | boolean
    createDate?: DateTimeFilter<"access_permission_group"> | Date | string
    users?: UsersListRelationFilter
  }

  export type access_permission_groupOrderByWithRelationInput = {
    id?: SortOrder
    title?: SortOrderInput | SortOrder
    name?: SortOrder
    isDeletable?: SortOrder
    createDate?: SortOrder
    users?: usersOrderByRelationAggregateInput
  }

  export type access_permission_groupWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: access_permission_groupWhereInput | access_permission_groupWhereInput[]
    OR?: access_permission_groupWhereInput[]
    NOT?: access_permission_groupWhereInput | access_permission_groupWhereInput[]
    title?: StringNullableFilter<"access_permission_group"> | string | null
    name?: StringFilter<"access_permission_group"> | string
    isDeletable?: BoolFilter<"access_permission_group"> | boolean
    createDate?: DateTimeFilter<"access_permission_group"> | Date | string
    users?: UsersListRelationFilter
  }, "id">

  export type access_permission_groupOrderByWithAggregationInput = {
    id?: SortOrder
    title?: SortOrderInput | SortOrder
    name?: SortOrder
    isDeletable?: SortOrder
    createDate?: SortOrder
    _count?: access_permission_groupCountOrderByAggregateInput
    _max?: access_permission_groupMaxOrderByAggregateInput
    _min?: access_permission_groupMinOrderByAggregateInput
  }

  export type access_permission_groupScalarWhereWithAggregatesInput = {
    AND?: access_permission_groupScalarWhereWithAggregatesInput | access_permission_groupScalarWhereWithAggregatesInput[]
    OR?: access_permission_groupScalarWhereWithAggregatesInput[]
    NOT?: access_permission_groupScalarWhereWithAggregatesInput | access_permission_groupScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"access_permission_group"> | string
    title?: StringNullableWithAggregatesFilter<"access_permission_group"> | string | null
    name?: StringWithAggregatesFilter<"access_permission_group"> | string
    isDeletable?: BoolWithAggregatesFilter<"access_permission_group"> | boolean
    createDate?: DateTimeWithAggregatesFilter<"access_permission_group"> | Date | string
  }

  export type access_permission_group_itemsWhereInput = {
    AND?: access_permission_group_itemsWhereInput | access_permission_group_itemsWhereInput[]
    OR?: access_permission_group_itemsWhereInput[]
    NOT?: access_permission_group_itemsWhereInput | access_permission_group_itemsWhereInput[]
    id?: StringFilter<"access_permission_group_items"> | string
    userOrParentAccessPermissionId?: StringNullableFilter<"access_permission_group_items"> | string | null
    providerKey?: StringFilter<"access_permission_group_items"> | string
    creatorId?: StringNullableFilter<"access_permission_group_items"> | string | null
    createDate?: DateTimeFilter<"access_permission_group_items"> | Date | string
  }

  export type access_permission_group_itemsOrderByWithRelationInput = {
    id?: SortOrder
    userOrParentAccessPermissionId?: SortOrderInput | SortOrder
    providerKey?: SortOrder
    creatorId?: SortOrderInput | SortOrder
    createDate?: SortOrder
  }

  export type access_permission_group_itemsWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: access_permission_group_itemsWhereInput | access_permission_group_itemsWhereInput[]
    OR?: access_permission_group_itemsWhereInput[]
    NOT?: access_permission_group_itemsWhereInput | access_permission_group_itemsWhereInput[]
    userOrParentAccessPermissionId?: StringNullableFilter<"access_permission_group_items"> | string | null
    providerKey?: StringFilter<"access_permission_group_items"> | string
    creatorId?: StringNullableFilter<"access_permission_group_items"> | string | null
    createDate?: DateTimeFilter<"access_permission_group_items"> | Date | string
  }, "id">

  export type access_permission_group_itemsOrderByWithAggregationInput = {
    id?: SortOrder
    userOrParentAccessPermissionId?: SortOrderInput | SortOrder
    providerKey?: SortOrder
    creatorId?: SortOrderInput | SortOrder
    createDate?: SortOrder
    _count?: access_permission_group_itemsCountOrderByAggregateInput
    _max?: access_permission_group_itemsMaxOrderByAggregateInput
    _min?: access_permission_group_itemsMinOrderByAggregateInput
  }

  export type access_permission_group_itemsScalarWhereWithAggregatesInput = {
    AND?: access_permission_group_itemsScalarWhereWithAggregatesInput | access_permission_group_itemsScalarWhereWithAggregatesInput[]
    OR?: access_permission_group_itemsScalarWhereWithAggregatesInput[]
    NOT?: access_permission_group_itemsScalarWhereWithAggregatesInput | access_permission_group_itemsScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"access_permission_group_items"> | string
    userOrParentAccessPermissionId?: StringNullableWithAggregatesFilter<"access_permission_group_items"> | string | null
    providerKey?: StringWithAggregatesFilter<"access_permission_group_items"> | string
    creatorId?: StringNullableWithAggregatesFilter<"access_permission_group_items"> | string | null
    createDate?: DateTimeWithAggregatesFilter<"access_permission_group_items"> | Date | string
  }

  export type settingsWhereInput = {
    AND?: settingsWhereInput | settingsWhereInput[]
    OR?: settingsWhereInput[]
    NOT?: settingsWhereInput | settingsWhereInput[]
    id?: StringFilter<"settings"> | string
    providerKey?: StringFilter<"settings"> | string
    providerValue?: StringFilter<"settings"> | string
    creatorId?: StringNullableFilter<"settings"> | string | null
    createDate?: DateTimeFilter<"settings"> | Date | string
  }

  export type settingsOrderByWithRelationInput = {
    id?: SortOrder
    providerKey?: SortOrder
    providerValue?: SortOrder
    creatorId?: SortOrderInput | SortOrder
    createDate?: SortOrder
  }

  export type settingsWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: settingsWhereInput | settingsWhereInput[]
    OR?: settingsWhereInput[]
    NOT?: settingsWhereInput | settingsWhereInput[]
    providerKey?: StringFilter<"settings"> | string
    providerValue?: StringFilter<"settings"> | string
    creatorId?: StringNullableFilter<"settings"> | string | null
    createDate?: DateTimeFilter<"settings"> | Date | string
  }, "id">

  export type settingsOrderByWithAggregationInput = {
    id?: SortOrder
    providerKey?: SortOrder
    providerValue?: SortOrder
    creatorId?: SortOrderInput | SortOrder
    createDate?: SortOrder
    _count?: settingsCountOrderByAggregateInput
    _max?: settingsMaxOrderByAggregateInput
    _min?: settingsMinOrderByAggregateInput
  }

  export type settingsScalarWhereWithAggregatesInput = {
    AND?: settingsScalarWhereWithAggregatesInput | settingsScalarWhereWithAggregatesInput[]
    OR?: settingsScalarWhereWithAggregatesInput[]
    NOT?: settingsScalarWhereWithAggregatesInput | settingsScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"settings"> | string
    providerKey?: StringWithAggregatesFilter<"settings"> | string
    providerValue?: StringWithAggregatesFilter<"settings"> | string
    creatorId?: StringNullableWithAggregatesFilter<"settings"> | string | null
    createDate?: DateTimeWithAggregatesFilter<"settings"> | Date | string
  }

  export type ipgsWhereInput = {
    AND?: ipgsWhereInput | ipgsWhereInput[]
    OR?: ipgsWhereInput[]
    NOT?: ipgsWhereInput | ipgsWhereInput[]
    id?: StringFilter<"ipgs"> | string
    provider?: StringNullableFilter<"ipgs"> | string | null
    merchantId?: StringFilter<"ipgs"> | string
    terminalId?: StringFilter<"ipgs"> | string
    terminalKey?: StringFilter<"ipgs"> | string
    isActive?: BoolFilter<"ipgs"> | boolean
    creationTime?: DateTimeFilter<"ipgs"> | Date | string
    creatorId?: StringNullableFilter<"ipgs"> | string | null
  }

  export type ipgsOrderByWithRelationInput = {
    id?: SortOrder
    provider?: SortOrderInput | SortOrder
    merchantId?: SortOrder
    terminalId?: SortOrder
    terminalKey?: SortOrder
    isActive?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrderInput | SortOrder
  }

  export type ipgsWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: ipgsWhereInput | ipgsWhereInput[]
    OR?: ipgsWhereInput[]
    NOT?: ipgsWhereInput | ipgsWhereInput[]
    provider?: StringNullableFilter<"ipgs"> | string | null
    merchantId?: StringFilter<"ipgs"> | string
    terminalId?: StringFilter<"ipgs"> | string
    terminalKey?: StringFilter<"ipgs"> | string
    isActive?: BoolFilter<"ipgs"> | boolean
    creationTime?: DateTimeFilter<"ipgs"> | Date | string
    creatorId?: StringNullableFilter<"ipgs"> | string | null
  }, "id">

  export type ipgsOrderByWithAggregationInput = {
    id?: SortOrder
    provider?: SortOrderInput | SortOrder
    merchantId?: SortOrder
    terminalId?: SortOrder
    terminalKey?: SortOrder
    isActive?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrderInput | SortOrder
    _count?: ipgsCountOrderByAggregateInput
    _max?: ipgsMaxOrderByAggregateInput
    _min?: ipgsMinOrderByAggregateInput
  }

  export type ipgsScalarWhereWithAggregatesInput = {
    AND?: ipgsScalarWhereWithAggregatesInput | ipgsScalarWhereWithAggregatesInput[]
    OR?: ipgsScalarWhereWithAggregatesInput[]
    NOT?: ipgsScalarWhereWithAggregatesInput | ipgsScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"ipgs"> | string
    provider?: StringNullableWithAggregatesFilter<"ipgs"> | string | null
    merchantId?: StringWithAggregatesFilter<"ipgs"> | string
    terminalId?: StringWithAggregatesFilter<"ipgs"> | string
    terminalKey?: StringWithAggregatesFilter<"ipgs"> | string
    isActive?: BoolWithAggregatesFilter<"ipgs"> | boolean
    creationTime?: DateTimeWithAggregatesFilter<"ipgs"> | Date | string
    creatorId?: StringNullableWithAggregatesFilter<"ipgs"> | string | null
  }

  export type reuqestcodesWhereInput = {
    AND?: reuqestcodesWhereInput | reuqestcodesWhereInput[]
    OR?: reuqestcodesWhereInput[]
    NOT?: reuqestcodesWhereInput | reuqestcodesWhereInput[]
    id?: StringFilter<"reuqestcodes"> | string
    mobileNumber?: StringFilter<"reuqestcodes"> | string
    code?: StringFilter<"reuqestcodes"> | string
    createDate?: DateTimeFilter<"reuqestcodes"> | Date | string
  }

  export type reuqestcodesOrderByWithRelationInput = {
    id?: SortOrder
    mobileNumber?: SortOrder
    code?: SortOrder
    createDate?: SortOrder
  }

  export type reuqestcodesWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: reuqestcodesWhereInput | reuqestcodesWhereInput[]
    OR?: reuqestcodesWhereInput[]
    NOT?: reuqestcodesWhereInput | reuqestcodesWhereInput[]
    mobileNumber?: StringFilter<"reuqestcodes"> | string
    code?: StringFilter<"reuqestcodes"> | string
    createDate?: DateTimeFilter<"reuqestcodes"> | Date | string
  }, "id">

  export type reuqestcodesOrderByWithAggregationInput = {
    id?: SortOrder
    mobileNumber?: SortOrder
    code?: SortOrder
    createDate?: SortOrder
    _count?: reuqestcodesCountOrderByAggregateInput
    _max?: reuqestcodesMaxOrderByAggregateInput
    _min?: reuqestcodesMinOrderByAggregateInput
  }

  export type reuqestcodesScalarWhereWithAggregatesInput = {
    AND?: reuqestcodesScalarWhereWithAggregatesInput | reuqestcodesScalarWhereWithAggregatesInput[]
    OR?: reuqestcodesScalarWhereWithAggregatesInput[]
    NOT?: reuqestcodesScalarWhereWithAggregatesInput | reuqestcodesScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"reuqestcodes"> | string
    mobileNumber?: StringWithAggregatesFilter<"reuqestcodes"> | string
    code?: StringWithAggregatesFilter<"reuqestcodes"> | string
    createDate?: DateTimeWithAggregatesFilter<"reuqestcodes"> | Date | string
  }

  export type baseDataWhereInput = {
    AND?: baseDataWhereInput | baseDataWhereInput[]
    OR?: baseDataWhereInput[]
    NOT?: baseDataWhereInput | baseDataWhereInput[]
    id?: StringFilter<"baseData"> | string
    providerKey?: StringFilter<"baseData"> | string
    providerValue?: StringFilter<"baseData"> | string
    providerData?: StringNullableFilter<"baseData"> | string | null
    providerData_2?: StringNullableFilter<"baseData"> | string | null
    createDate?: DateTimeFilter<"baseData"> | Date | string
  }

  export type baseDataOrderByWithRelationInput = {
    id?: SortOrder
    providerKey?: SortOrder
    providerValue?: SortOrder
    providerData?: SortOrderInput | SortOrder
    providerData_2?: SortOrderInput | SortOrder
    createDate?: SortOrder
  }

  export type baseDataWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: baseDataWhereInput | baseDataWhereInput[]
    OR?: baseDataWhereInput[]
    NOT?: baseDataWhereInput | baseDataWhereInput[]
    providerKey?: StringFilter<"baseData"> | string
    providerValue?: StringFilter<"baseData"> | string
    providerData?: StringNullableFilter<"baseData"> | string | null
    providerData_2?: StringNullableFilter<"baseData"> | string | null
    createDate?: DateTimeFilter<"baseData"> | Date | string
  }, "id">

  export type baseDataOrderByWithAggregationInput = {
    id?: SortOrder
    providerKey?: SortOrder
    providerValue?: SortOrder
    providerData?: SortOrderInput | SortOrder
    providerData_2?: SortOrderInput | SortOrder
    createDate?: SortOrder
    _count?: baseDataCountOrderByAggregateInput
    _max?: baseDataMaxOrderByAggregateInput
    _min?: baseDataMinOrderByAggregateInput
  }

  export type baseDataScalarWhereWithAggregatesInput = {
    AND?: baseDataScalarWhereWithAggregatesInput | baseDataScalarWhereWithAggregatesInput[]
    OR?: baseDataScalarWhereWithAggregatesInput[]
    NOT?: baseDataScalarWhereWithAggregatesInput | baseDataScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"baseData"> | string
    providerKey?: StringWithAggregatesFilter<"baseData"> | string
    providerValue?: StringWithAggregatesFilter<"baseData"> | string
    providerData?: StringNullableWithAggregatesFilter<"baseData"> | string | null
    providerData_2?: StringNullableWithAggregatesFilter<"baseData"> | string | null
    createDate?: DateTimeWithAggregatesFilter<"baseData"> | Date | string
  }

  export type membersWhereInput = {
    AND?: membersWhereInput | membersWhereInput[]
    OR?: membersWhereInput[]
    NOT?: membersWhereInput | membersWhereInput[]
    id?: StringFilter<"members"> | string
    name?: StringNullableFilter<"members"> | string | null
    family?: StringNullableFilter<"members"> | string | null
    nationalCode?: StringNullableFilter<"members"> | string | null
    fatherName?: StringNullableFilter<"members"> | string | null
    disabilityStatus?: IntNullableFilter<"members"> | number | null
    disabilityDescription?: StringNullableFilter<"members"> | string | null
    partnerJob?: StringNullableFilter<"members"> | string | null
    educationLevel?: IntNullableFilter<"members"> | number | null
    maritalStatus?: IntNullableFilter<"members"> | number | null
    childrenCounts?: IntNullableFilter<"members"> | number | null
    birthDate?: StringNullableFilter<"members"> | string | null
    mobileNumber?: StringFilter<"members"> | string
    address?: StringNullableFilter<"members"> | string | null
    username?: StringNullableFilter<"members"> | string | null
    password?: StringNullableFilter<"members"> | string | null
    status?: IntNullableFilter<"members"> | number | null
    creationTime?: DateTimeFilter<"members"> | Date | string
    creatorId?: StringNullableFilter<"members"> | string | null
    isDeleted?: BoolFilter<"members"> | boolean
  }

  export type membersOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrderInput | SortOrder
    family?: SortOrderInput | SortOrder
    nationalCode?: SortOrderInput | SortOrder
    fatherName?: SortOrderInput | SortOrder
    disabilityStatus?: SortOrderInput | SortOrder
    disabilityDescription?: SortOrderInput | SortOrder
    partnerJob?: SortOrderInput | SortOrder
    educationLevel?: SortOrderInput | SortOrder
    maritalStatus?: SortOrderInput | SortOrder
    childrenCounts?: SortOrderInput | SortOrder
    birthDate?: SortOrderInput | SortOrder
    mobileNumber?: SortOrder
    address?: SortOrderInput | SortOrder
    username?: SortOrderInput | SortOrder
    password?: SortOrderInput | SortOrder
    status?: SortOrderInput | SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrderInput | SortOrder
    isDeleted?: SortOrder
  }

  export type membersWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: membersWhereInput | membersWhereInput[]
    OR?: membersWhereInput[]
    NOT?: membersWhereInput | membersWhereInput[]
    name?: StringNullableFilter<"members"> | string | null
    family?: StringNullableFilter<"members"> | string | null
    nationalCode?: StringNullableFilter<"members"> | string | null
    fatherName?: StringNullableFilter<"members"> | string | null
    disabilityStatus?: IntNullableFilter<"members"> | number | null
    disabilityDescription?: StringNullableFilter<"members"> | string | null
    partnerJob?: StringNullableFilter<"members"> | string | null
    educationLevel?: IntNullableFilter<"members"> | number | null
    maritalStatus?: IntNullableFilter<"members"> | number | null
    childrenCounts?: IntNullableFilter<"members"> | number | null
    birthDate?: StringNullableFilter<"members"> | string | null
    mobileNumber?: StringFilter<"members"> | string
    address?: StringNullableFilter<"members"> | string | null
    username?: StringNullableFilter<"members"> | string | null
    password?: StringNullableFilter<"members"> | string | null
    status?: IntNullableFilter<"members"> | number | null
    creationTime?: DateTimeFilter<"members"> | Date | string
    creatorId?: StringNullableFilter<"members"> | string | null
    isDeleted?: BoolFilter<"members"> | boolean
  }, "id">

  export type membersOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrderInput | SortOrder
    family?: SortOrderInput | SortOrder
    nationalCode?: SortOrderInput | SortOrder
    fatherName?: SortOrderInput | SortOrder
    disabilityStatus?: SortOrderInput | SortOrder
    disabilityDescription?: SortOrderInput | SortOrder
    partnerJob?: SortOrderInput | SortOrder
    educationLevel?: SortOrderInput | SortOrder
    maritalStatus?: SortOrderInput | SortOrder
    childrenCounts?: SortOrderInput | SortOrder
    birthDate?: SortOrderInput | SortOrder
    mobileNumber?: SortOrder
    address?: SortOrderInput | SortOrder
    username?: SortOrderInput | SortOrder
    password?: SortOrderInput | SortOrder
    status?: SortOrderInput | SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrderInput | SortOrder
    isDeleted?: SortOrder
    _count?: membersCountOrderByAggregateInput
    _avg?: membersAvgOrderByAggregateInput
    _max?: membersMaxOrderByAggregateInput
    _min?: membersMinOrderByAggregateInput
    _sum?: membersSumOrderByAggregateInput
  }

  export type membersScalarWhereWithAggregatesInput = {
    AND?: membersScalarWhereWithAggregatesInput | membersScalarWhereWithAggregatesInput[]
    OR?: membersScalarWhereWithAggregatesInput[]
    NOT?: membersScalarWhereWithAggregatesInput | membersScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"members"> | string
    name?: StringNullableWithAggregatesFilter<"members"> | string | null
    family?: StringNullableWithAggregatesFilter<"members"> | string | null
    nationalCode?: StringNullableWithAggregatesFilter<"members"> | string | null
    fatherName?: StringNullableWithAggregatesFilter<"members"> | string | null
    disabilityStatus?: IntNullableWithAggregatesFilter<"members"> | number | null
    disabilityDescription?: StringNullableWithAggregatesFilter<"members"> | string | null
    partnerJob?: StringNullableWithAggregatesFilter<"members"> | string | null
    educationLevel?: IntNullableWithAggregatesFilter<"members"> | number | null
    maritalStatus?: IntNullableWithAggregatesFilter<"members"> | number | null
    childrenCounts?: IntNullableWithAggregatesFilter<"members"> | number | null
    birthDate?: StringNullableWithAggregatesFilter<"members"> | string | null
    mobileNumber?: StringWithAggregatesFilter<"members"> | string
    address?: StringNullableWithAggregatesFilter<"members"> | string | null
    username?: StringNullableWithAggregatesFilter<"members"> | string | null
    password?: StringNullableWithAggregatesFilter<"members"> | string | null
    status?: IntNullableWithAggregatesFilter<"members"> | number | null
    creationTime?: DateTimeWithAggregatesFilter<"members"> | Date | string
    creatorId?: StringNullableWithAggregatesFilter<"members"> | string | null
    isDeleted?: BoolWithAggregatesFilter<"members"> | boolean
  }

  export type members_product_itemsWhereInput = {
    AND?: members_product_itemsWhereInput | members_product_itemsWhereInput[]
    OR?: members_product_itemsWhereInput[]
    NOT?: members_product_itemsWhereInput | members_product_itemsWhereInput[]
    id?: StringFilter<"members_product_items"> | string
    parentMemberId?: StringFilter<"members_product_items"> | string
    title?: StringFilter<"members_product_items"> | string
    ownProduct?: BoolFilter<"members_product_items"> | boolean
  }

  export type members_product_itemsOrderByWithRelationInput = {
    id?: SortOrder
    parentMemberId?: SortOrder
    title?: SortOrder
    ownProduct?: SortOrder
  }

  export type members_product_itemsWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: members_product_itemsWhereInput | members_product_itemsWhereInput[]
    OR?: members_product_itemsWhereInput[]
    NOT?: members_product_itemsWhereInput | members_product_itemsWhereInput[]
    parentMemberId?: StringFilter<"members_product_items"> | string
    title?: StringFilter<"members_product_items"> | string
    ownProduct?: BoolFilter<"members_product_items"> | boolean
  }, "id">

  export type members_product_itemsOrderByWithAggregationInput = {
    id?: SortOrder
    parentMemberId?: SortOrder
    title?: SortOrder
    ownProduct?: SortOrder
    _count?: members_product_itemsCountOrderByAggregateInput
    _max?: members_product_itemsMaxOrderByAggregateInput
    _min?: members_product_itemsMinOrderByAggregateInput
  }

  export type members_product_itemsScalarWhereWithAggregatesInput = {
    AND?: members_product_itemsScalarWhereWithAggregatesInput | members_product_itemsScalarWhereWithAggregatesInput[]
    OR?: members_product_itemsScalarWhereWithAggregatesInput[]
    NOT?: members_product_itemsScalarWhereWithAggregatesInput | members_product_itemsScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"members_product_items"> | string
    parentMemberId?: StringWithAggregatesFilter<"members_product_items"> | string
    title?: StringWithAggregatesFilter<"members_product_items"> | string
    ownProduct?: BoolWithAggregatesFilter<"members_product_items"> | boolean
  }

  export type imageSliderWhereInput = {
    AND?: imageSliderWhereInput | imageSliderWhereInput[]
    OR?: imageSliderWhereInput[]
    NOT?: imageSliderWhereInput | imageSliderWhereInput[]
    id?: StringFilter<"imageSlider"> | string
    fileId?: StringFilter<"imageSlider"> | string
    title?: StringFilter<"imageSlider"> | string
    creationTime?: DateTimeFilter<"imageSlider"> | Date | string
    creatorId?: StringNullableFilter<"imageSlider"> | string | null
  }

  export type imageSliderOrderByWithRelationInput = {
    id?: SortOrder
    fileId?: SortOrder
    title?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrderInput | SortOrder
  }

  export type imageSliderWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: imageSliderWhereInput | imageSliderWhereInput[]
    OR?: imageSliderWhereInput[]
    NOT?: imageSliderWhereInput | imageSliderWhereInput[]
    fileId?: StringFilter<"imageSlider"> | string
    title?: StringFilter<"imageSlider"> | string
    creationTime?: DateTimeFilter<"imageSlider"> | Date | string
    creatorId?: StringNullableFilter<"imageSlider"> | string | null
  }, "id">

  export type imageSliderOrderByWithAggregationInput = {
    id?: SortOrder
    fileId?: SortOrder
    title?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrderInput | SortOrder
    _count?: imageSliderCountOrderByAggregateInput
    _max?: imageSliderMaxOrderByAggregateInput
    _min?: imageSliderMinOrderByAggregateInput
  }

  export type imageSliderScalarWhereWithAggregatesInput = {
    AND?: imageSliderScalarWhereWithAggregatesInput | imageSliderScalarWhereWithAggregatesInput[]
    OR?: imageSliderScalarWhereWithAggregatesInput[]
    NOT?: imageSliderScalarWhereWithAggregatesInput | imageSliderScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"imageSlider"> | string
    fileId?: StringWithAggregatesFilter<"imageSlider"> | string
    title?: StringWithAggregatesFilter<"imageSlider"> | string
    creationTime?: DateTimeWithAggregatesFilter<"imageSlider"> | Date | string
    creatorId?: StringNullableWithAggregatesFilter<"imageSlider"> | string | null
  }

  export type profileImageSliderWhereInput = {
    AND?: profileImageSliderWhereInput | profileImageSliderWhereInput[]
    OR?: profileImageSliderWhereInput[]
    NOT?: profileImageSliderWhereInput | profileImageSliderWhereInput[]
    id?: StringFilter<"profileImageSlider"> | string
    fileId?: StringFilter<"profileImageSlider"> | string
    targetUrl?: StringNullableFilter<"profileImageSlider"> | string | null
    creationTime?: DateTimeFilter<"profileImageSlider"> | Date | string
    creatorId?: StringNullableFilter<"profileImageSlider"> | string | null
  }

  export type profileImageSliderOrderByWithRelationInput = {
    id?: SortOrder
    fileId?: SortOrder
    targetUrl?: SortOrderInput | SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrderInput | SortOrder
  }

  export type profileImageSliderWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: profileImageSliderWhereInput | profileImageSliderWhereInput[]
    OR?: profileImageSliderWhereInput[]
    NOT?: profileImageSliderWhereInput | profileImageSliderWhereInput[]
    fileId?: StringFilter<"profileImageSlider"> | string
    targetUrl?: StringNullableFilter<"profileImageSlider"> | string | null
    creationTime?: DateTimeFilter<"profileImageSlider"> | Date | string
    creatorId?: StringNullableFilter<"profileImageSlider"> | string | null
  }, "id">

  export type profileImageSliderOrderByWithAggregationInput = {
    id?: SortOrder
    fileId?: SortOrder
    targetUrl?: SortOrderInput | SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrderInput | SortOrder
    _count?: profileImageSliderCountOrderByAggregateInput
    _max?: profileImageSliderMaxOrderByAggregateInput
    _min?: profileImageSliderMinOrderByAggregateInput
  }

  export type profileImageSliderScalarWhereWithAggregatesInput = {
    AND?: profileImageSliderScalarWhereWithAggregatesInput | profileImageSliderScalarWhereWithAggregatesInput[]
    OR?: profileImageSliderScalarWhereWithAggregatesInput[]
    NOT?: profileImageSliderScalarWhereWithAggregatesInput | profileImageSliderScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"profileImageSlider"> | string
    fileId?: StringWithAggregatesFilter<"profileImageSlider"> | string
    targetUrl?: StringNullableWithAggregatesFilter<"profileImageSlider"> | string | null
    creationTime?: DateTimeWithAggregatesFilter<"profileImageSlider"> | Date | string
    creatorId?: StringNullableWithAggregatesFilter<"profileImageSlider"> | string | null
  }

  export type upload_document_templateWhereInput = {
    AND?: upload_document_templateWhereInput | upload_document_templateWhereInput[]
    OR?: upload_document_templateWhereInput[]
    NOT?: upload_document_templateWhereInput | upload_document_templateWhereInput[]
    id?: StringFilter<"upload_document_template"> | string
    title?: StringFilter<"upload_document_template"> | string
    maximumSizeInMb?: IntFilter<"upload_document_template"> | number
    isRequired?: BoolFilter<"upload_document_template"> | boolean
    showWhen?: StringNullableFilter<"upload_document_template"> | string | null
    creationTime?: DateTimeFilter<"upload_document_template"> | Date | string
    creatorId?: StringNullableFilter<"upload_document_template"> | string | null
  }

  export type upload_document_templateOrderByWithRelationInput = {
    id?: SortOrder
    title?: SortOrder
    maximumSizeInMb?: SortOrder
    isRequired?: SortOrder
    showWhen?: SortOrderInput | SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrderInput | SortOrder
  }

  export type upload_document_templateWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: upload_document_templateWhereInput | upload_document_templateWhereInput[]
    OR?: upload_document_templateWhereInput[]
    NOT?: upload_document_templateWhereInput | upload_document_templateWhereInput[]
    title?: StringFilter<"upload_document_template"> | string
    maximumSizeInMb?: IntFilter<"upload_document_template"> | number
    isRequired?: BoolFilter<"upload_document_template"> | boolean
    showWhen?: StringNullableFilter<"upload_document_template"> | string | null
    creationTime?: DateTimeFilter<"upload_document_template"> | Date | string
    creatorId?: StringNullableFilter<"upload_document_template"> | string | null
  }, "id">

  export type upload_document_templateOrderByWithAggregationInput = {
    id?: SortOrder
    title?: SortOrder
    maximumSizeInMb?: SortOrder
    isRequired?: SortOrder
    showWhen?: SortOrderInput | SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrderInput | SortOrder
    _count?: upload_document_templateCountOrderByAggregateInput
    _avg?: upload_document_templateAvgOrderByAggregateInput
    _max?: upload_document_templateMaxOrderByAggregateInput
    _min?: upload_document_templateMinOrderByAggregateInput
    _sum?: upload_document_templateSumOrderByAggregateInput
  }

  export type upload_document_templateScalarWhereWithAggregatesInput = {
    AND?: upload_document_templateScalarWhereWithAggregatesInput | upload_document_templateScalarWhereWithAggregatesInput[]
    OR?: upload_document_templateScalarWhereWithAggregatesInput[]
    NOT?: upload_document_templateScalarWhereWithAggregatesInput | upload_document_templateScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"upload_document_template"> | string
    title?: StringWithAggregatesFilter<"upload_document_template"> | string
    maximumSizeInMb?: IntWithAggregatesFilter<"upload_document_template"> | number
    isRequired?: BoolWithAggregatesFilter<"upload_document_template"> | boolean
    showWhen?: StringNullableWithAggregatesFilter<"upload_document_template"> | string | null
    creationTime?: DateTimeWithAggregatesFilter<"upload_document_template"> | Date | string
    creatorId?: StringNullableWithAggregatesFilter<"upload_document_template"> | string | null
  }

  export type uploadedDocumentsWhereInput = {
    AND?: uploadedDocumentsWhereInput | uploadedDocumentsWhereInput[]
    OR?: uploadedDocumentsWhereInput[]
    NOT?: uploadedDocumentsWhereInput | uploadedDocumentsWhereInput[]
    id?: StringFilter<"uploadedDocuments"> | string
    userId?: StringFilter<"uploadedDocuments"> | string
    templateId?: StringFilter<"uploadedDocuments"> | string
    filePath?: StringFilter<"uploadedDocuments"> | string
    creationTime?: DateTimeFilter<"uploadedDocuments"> | Date | string
  }

  export type uploadedDocumentsOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    templateId?: SortOrder
    filePath?: SortOrder
    creationTime?: SortOrder
  }

  export type uploadedDocumentsWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: uploadedDocumentsWhereInput | uploadedDocumentsWhereInput[]
    OR?: uploadedDocumentsWhereInput[]
    NOT?: uploadedDocumentsWhereInput | uploadedDocumentsWhereInput[]
    userId?: StringFilter<"uploadedDocuments"> | string
    templateId?: StringFilter<"uploadedDocuments"> | string
    filePath?: StringFilter<"uploadedDocuments"> | string
    creationTime?: DateTimeFilter<"uploadedDocuments"> | Date | string
  }, "id">

  export type uploadedDocumentsOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    templateId?: SortOrder
    filePath?: SortOrder
    creationTime?: SortOrder
    _count?: uploadedDocumentsCountOrderByAggregateInput
    _max?: uploadedDocumentsMaxOrderByAggregateInput
    _min?: uploadedDocumentsMinOrderByAggregateInput
  }

  export type uploadedDocumentsScalarWhereWithAggregatesInput = {
    AND?: uploadedDocumentsScalarWhereWithAggregatesInput | uploadedDocumentsScalarWhereWithAggregatesInput[]
    OR?: uploadedDocumentsScalarWhereWithAggregatesInput[]
    NOT?: uploadedDocumentsScalarWhereWithAggregatesInput | uploadedDocumentsScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"uploadedDocuments"> | string
    userId?: StringWithAggregatesFilter<"uploadedDocuments"> | string
    templateId?: StringWithAggregatesFilter<"uploadedDocuments"> | string
    filePath?: StringWithAggregatesFilter<"uploadedDocuments"> | string
    creationTime?: DateTimeWithAggregatesFilter<"uploadedDocuments"> | Date | string
  }

  export type rejectionTemplatesWhereInput = {
    AND?: rejectionTemplatesWhereInput | rejectionTemplatesWhereInput[]
    OR?: rejectionTemplatesWhereInput[]
    NOT?: rejectionTemplatesWhereInput | rejectionTemplatesWhereInput[]
    id?: StringFilter<"rejectionTemplates"> | string
    title?: StringFilter<"rejectionTemplates"> | string
    creationTime?: DateTimeFilter<"rejectionTemplates"> | Date | string
    creatorId?: StringNullableFilter<"rejectionTemplates"> | string | null
  }

  export type rejectionTemplatesOrderByWithRelationInput = {
    id?: SortOrder
    title?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrderInput | SortOrder
  }

  export type rejectionTemplatesWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: rejectionTemplatesWhereInput | rejectionTemplatesWhereInput[]
    OR?: rejectionTemplatesWhereInput[]
    NOT?: rejectionTemplatesWhereInput | rejectionTemplatesWhereInput[]
    title?: StringFilter<"rejectionTemplates"> | string
    creationTime?: DateTimeFilter<"rejectionTemplates"> | Date | string
    creatorId?: StringNullableFilter<"rejectionTemplates"> | string | null
  }, "id">

  export type rejectionTemplatesOrderByWithAggregationInput = {
    id?: SortOrder
    title?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrderInput | SortOrder
    _count?: rejectionTemplatesCountOrderByAggregateInput
    _max?: rejectionTemplatesMaxOrderByAggregateInput
    _min?: rejectionTemplatesMinOrderByAggregateInput
  }

  export type rejectionTemplatesScalarWhereWithAggregatesInput = {
    AND?: rejectionTemplatesScalarWhereWithAggregatesInput | rejectionTemplatesScalarWhereWithAggregatesInput[]
    OR?: rejectionTemplatesScalarWhereWithAggregatesInput[]
    NOT?: rejectionTemplatesScalarWhereWithAggregatesInput | rejectionTemplatesScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"rejectionTemplates"> | string
    title?: StringWithAggregatesFilter<"rejectionTemplates"> | string
    creationTime?: DateTimeWithAggregatesFilter<"rejectionTemplates"> | Date | string
    creatorId?: StringNullableWithAggregatesFilter<"rejectionTemplates"> | string | null
  }

  export type marketsWhereInput = {
    AND?: marketsWhereInput | marketsWhereInput[]
    OR?: marketsWhereInput[]
    NOT?: marketsWhereInput | marketsWhereInput[]
    id?: StringFilter<"markets"> | string
    title?: StringFilter<"markets"> | string
    activityStartDate?: DateTimeFilter<"markets"> | Date | string
    activityEndDate?: DateTimeFilter<"markets"> | Date | string
    amount?: DecimalFilter<"markets"> | Decimal | DecimalJsLike | number | string
    location?: StringFilter<"markets"> | string
  }

  export type marketsOrderByWithRelationInput = {
    id?: SortOrder
    title?: SortOrder
    activityStartDate?: SortOrder
    activityEndDate?: SortOrder
    amount?: SortOrder
    location?: SortOrder
  }

  export type marketsWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: marketsWhereInput | marketsWhereInput[]
    OR?: marketsWhereInput[]
    NOT?: marketsWhereInput | marketsWhereInput[]
    title?: StringFilter<"markets"> | string
    activityStartDate?: DateTimeFilter<"markets"> | Date | string
    activityEndDate?: DateTimeFilter<"markets"> | Date | string
    amount?: DecimalFilter<"markets"> | Decimal | DecimalJsLike | number | string
    location?: StringFilter<"markets"> | string
  }, "id">

  export type marketsOrderByWithAggregationInput = {
    id?: SortOrder
    title?: SortOrder
    activityStartDate?: SortOrder
    activityEndDate?: SortOrder
    amount?: SortOrder
    location?: SortOrder
    _count?: marketsCountOrderByAggregateInput
    _avg?: marketsAvgOrderByAggregateInput
    _max?: marketsMaxOrderByAggregateInput
    _min?: marketsMinOrderByAggregateInput
    _sum?: marketsSumOrderByAggregateInput
  }

  export type marketsScalarWhereWithAggregatesInput = {
    AND?: marketsScalarWhereWithAggregatesInput | marketsScalarWhereWithAggregatesInput[]
    OR?: marketsScalarWhereWithAggregatesInput[]
    NOT?: marketsScalarWhereWithAggregatesInput | marketsScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"markets"> | string
    title?: StringWithAggregatesFilter<"markets"> | string
    activityStartDate?: DateTimeWithAggregatesFilter<"markets"> | Date | string
    activityEndDate?: DateTimeWithAggregatesFilter<"markets"> | Date | string
    amount?: DecimalWithAggregatesFilter<"markets"> | Decimal | DecimalJsLike | number | string
    location?: StringWithAggregatesFilter<"markets"> | string
  }

  export type market_desksWhereInput = {
    AND?: market_desksWhereInput | market_desksWhereInput[]
    OR?: market_desksWhereInput[]
    NOT?: market_desksWhereInput | market_desksWhereInput[]
    id?: StringFilter<"market_desks"> | string
    number?: IntFilter<"market_desks"> | number
    title?: StringFilter<"market_desks"> | string
    amount?: DecimalFilter<"market_desks"> | Decimal | DecimalJsLike | number | string
    parentMarketId?: StringFilter<"market_desks"> | string
  }

  export type market_desksOrderByWithRelationInput = {
    id?: SortOrder
    number?: SortOrder
    title?: SortOrder
    amount?: SortOrder
    parentMarketId?: SortOrder
  }

  export type market_desksWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: market_desksWhereInput | market_desksWhereInput[]
    OR?: market_desksWhereInput[]
    NOT?: market_desksWhereInput | market_desksWhereInput[]
    number?: IntFilter<"market_desks"> | number
    title?: StringFilter<"market_desks"> | string
    amount?: DecimalFilter<"market_desks"> | Decimal | DecimalJsLike | number | string
    parentMarketId?: StringFilter<"market_desks"> | string
  }, "id">

  export type market_desksOrderByWithAggregationInput = {
    id?: SortOrder
    number?: SortOrder
    title?: SortOrder
    amount?: SortOrder
    parentMarketId?: SortOrder
    _count?: market_desksCountOrderByAggregateInput
    _avg?: market_desksAvgOrderByAggregateInput
    _max?: market_desksMaxOrderByAggregateInput
    _min?: market_desksMinOrderByAggregateInput
    _sum?: market_desksSumOrderByAggregateInput
  }

  export type market_desksScalarWhereWithAggregatesInput = {
    AND?: market_desksScalarWhereWithAggregatesInput | market_desksScalarWhereWithAggregatesInput[]
    OR?: market_desksScalarWhereWithAggregatesInput[]
    NOT?: market_desksScalarWhereWithAggregatesInput | market_desksScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"market_desks"> | string
    number?: IntWithAggregatesFilter<"market_desks"> | number
    title?: StringWithAggregatesFilter<"market_desks"> | string
    amount?: DecimalWithAggregatesFilter<"market_desks"> | Decimal | DecimalJsLike | number | string
    parentMarketId?: StringWithAggregatesFilter<"market_desks"> | string
  }

  export type reversed_marketsWhereInput = {
    AND?: reversed_marketsWhereInput | reversed_marketsWhereInput[]
    OR?: reversed_marketsWhereInput[]
    NOT?: reversed_marketsWhereInput | reversed_marketsWhereInput[]
    id?: StringFilter<"reversed_markets"> | string
    marketId?: StringFilter<"reversed_markets"> | string
    deskId?: StringFilter<"reversed_markets"> | string
    userId?: StringFilter<"reversed_markets"> | string
    isPurchased?: BoolFilter<"reversed_markets"> | boolean
  }

  export type reversed_marketsOrderByWithRelationInput = {
    id?: SortOrder
    marketId?: SortOrder
    deskId?: SortOrder
    userId?: SortOrder
    isPurchased?: SortOrder
  }

  export type reversed_marketsWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: reversed_marketsWhereInput | reversed_marketsWhereInput[]
    OR?: reversed_marketsWhereInput[]
    NOT?: reversed_marketsWhereInput | reversed_marketsWhereInput[]
    marketId?: StringFilter<"reversed_markets"> | string
    deskId?: StringFilter<"reversed_markets"> | string
    userId?: StringFilter<"reversed_markets"> | string
    isPurchased?: BoolFilter<"reversed_markets"> | boolean
  }, "id">

  export type reversed_marketsOrderByWithAggregationInput = {
    id?: SortOrder
    marketId?: SortOrder
    deskId?: SortOrder
    userId?: SortOrder
    isPurchased?: SortOrder
    _count?: reversed_marketsCountOrderByAggregateInput
    _max?: reversed_marketsMaxOrderByAggregateInput
    _min?: reversed_marketsMinOrderByAggregateInput
  }

  export type reversed_marketsScalarWhereWithAggregatesInput = {
    AND?: reversed_marketsScalarWhereWithAggregatesInput | reversed_marketsScalarWhereWithAggregatesInput[]
    OR?: reversed_marketsScalarWhereWithAggregatesInput[]
    NOT?: reversed_marketsScalarWhereWithAggregatesInput | reversed_marketsScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"reversed_markets"> | string
    marketId?: StringWithAggregatesFilter<"reversed_markets"> | string
    deskId?: StringWithAggregatesFilter<"reversed_markets"> | string
    userId?: StringWithAggregatesFilter<"reversed_markets"> | string
    isPurchased?: BoolWithAggregatesFilter<"reversed_markets"> | boolean
  }

  export type usersCreateInput = {
    id?: string
    username?: string | null
    password?: string | null
    name?: string | null
    family?: string | null
    fatherName?: string | null
    creationTime?: Date | string
    isDeleted?: boolean
    metaData?: string | null
    creatorId?: string | null
    permissionGroupId?: access_permission_groupCreateNestedOneWithoutUsersInput
  }

  export type usersUncheckedCreateInput = {
    id?: string
    username?: string | null
    password?: string | null
    name?: string | null
    family?: string | null
    fatherName?: string | null
    creationTime?: Date | string
    isDeleted?: boolean
    metaData?: string | null
    creatorId?: string | null
    accessPermissionGroupId: string
  }

  export type usersUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    family?: NullableStringFieldUpdateOperationsInput | string | null
    fatherName?: NullableStringFieldUpdateOperationsInput | string | null
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    metaData?: NullableStringFieldUpdateOperationsInput | string | null
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
    permissionGroupId?: access_permission_groupUpdateOneWithoutUsersNestedInput
  }

  export type usersUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    family?: NullableStringFieldUpdateOperationsInput | string | null
    fatherName?: NullableStringFieldUpdateOperationsInput | string | null
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    metaData?: NullableStringFieldUpdateOperationsInput | string | null
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
    accessPermissionGroupId?: StringFieldUpdateOperationsInput | string
  }

  export type usersCreateManyInput = {
    id?: string
    username?: string | null
    password?: string | null
    name?: string | null
    family?: string | null
    fatherName?: string | null
    creationTime?: Date | string
    isDeleted?: boolean
    metaData?: string | null
    creatorId?: string | null
    accessPermissionGroupId: string
  }

  export type usersUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    family?: NullableStringFieldUpdateOperationsInput | string | null
    fatherName?: NullableStringFieldUpdateOperationsInput | string | null
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    metaData?: NullableStringFieldUpdateOperationsInput | string | null
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type usersUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    family?: NullableStringFieldUpdateOperationsInput | string | null
    fatherName?: NullableStringFieldUpdateOperationsInput | string | null
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    metaData?: NullableStringFieldUpdateOperationsInput | string | null
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
    accessPermissionGroupId?: StringFieldUpdateOperationsInput | string
  }

  export type access_permission_groupCreateInput = {
    id?: string
    title?: string | null
    name: string
    isDeletable: boolean
    createDate?: Date | string
    users?: usersCreateNestedManyWithoutPermissionGroupIdInput
  }

  export type access_permission_groupUncheckedCreateInput = {
    id?: string
    title?: string | null
    name: string
    isDeletable: boolean
    createDate?: Date | string
    users?: usersUncheckedCreateNestedManyWithoutPermissionGroupIdInput
  }

  export type access_permission_groupUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: NullableStringFieldUpdateOperationsInput | string | null
    name?: StringFieldUpdateOperationsInput | string
    isDeletable?: BoolFieldUpdateOperationsInput | boolean
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
    users?: usersUpdateManyWithoutPermissionGroupIdNestedInput
  }

  export type access_permission_groupUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: NullableStringFieldUpdateOperationsInput | string | null
    name?: StringFieldUpdateOperationsInput | string
    isDeletable?: BoolFieldUpdateOperationsInput | boolean
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
    users?: usersUncheckedUpdateManyWithoutPermissionGroupIdNestedInput
  }

  export type access_permission_groupCreateManyInput = {
    id?: string
    title?: string | null
    name: string
    isDeletable: boolean
    createDate?: Date | string
  }

  export type access_permission_groupUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: NullableStringFieldUpdateOperationsInput | string | null
    name?: StringFieldUpdateOperationsInput | string
    isDeletable?: BoolFieldUpdateOperationsInput | boolean
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type access_permission_groupUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: NullableStringFieldUpdateOperationsInput | string | null
    name?: StringFieldUpdateOperationsInput | string
    isDeletable?: BoolFieldUpdateOperationsInput | boolean
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type access_permission_group_itemsCreateInput = {
    id?: string
    userOrParentAccessPermissionId?: string | null
    providerKey: string
    creatorId?: string | null
    createDate?: Date | string
  }

  export type access_permission_group_itemsUncheckedCreateInput = {
    id?: string
    userOrParentAccessPermissionId?: string | null
    providerKey: string
    creatorId?: string | null
    createDate?: Date | string
  }

  export type access_permission_group_itemsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    userOrParentAccessPermissionId?: NullableStringFieldUpdateOperationsInput | string | null
    providerKey?: StringFieldUpdateOperationsInput | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type access_permission_group_itemsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    userOrParentAccessPermissionId?: NullableStringFieldUpdateOperationsInput | string | null
    providerKey?: StringFieldUpdateOperationsInput | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type access_permission_group_itemsCreateManyInput = {
    id?: string
    userOrParentAccessPermissionId?: string | null
    providerKey: string
    creatorId?: string | null
    createDate?: Date | string
  }

  export type access_permission_group_itemsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    userOrParentAccessPermissionId?: NullableStringFieldUpdateOperationsInput | string | null
    providerKey?: StringFieldUpdateOperationsInput | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type access_permission_group_itemsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    userOrParentAccessPermissionId?: NullableStringFieldUpdateOperationsInput | string | null
    providerKey?: StringFieldUpdateOperationsInput | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type settingsCreateInput = {
    id?: string
    providerKey: string
    providerValue: string
    creatorId?: string | null
    createDate?: Date | string
  }

  export type settingsUncheckedCreateInput = {
    id?: string
    providerKey: string
    providerValue: string
    creatorId?: string | null
    createDate?: Date | string
  }

  export type settingsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    providerKey?: StringFieldUpdateOperationsInput | string
    providerValue?: StringFieldUpdateOperationsInput | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type settingsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    providerKey?: StringFieldUpdateOperationsInput | string
    providerValue?: StringFieldUpdateOperationsInput | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type settingsCreateManyInput = {
    id?: string
    providerKey: string
    providerValue: string
    creatorId?: string | null
    createDate?: Date | string
  }

  export type settingsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    providerKey?: StringFieldUpdateOperationsInput | string
    providerValue?: StringFieldUpdateOperationsInput | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type settingsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    providerKey?: StringFieldUpdateOperationsInput | string
    providerValue?: StringFieldUpdateOperationsInput | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ipgsCreateInput = {
    id?: string
    provider?: string | null
    merchantId: string
    terminalId: string
    terminalKey: string
    isActive: boolean
    creationTime?: Date | string
    creatorId?: string | null
  }

  export type ipgsUncheckedCreateInput = {
    id?: string
    provider?: string | null
    merchantId: string
    terminalId: string
    terminalKey: string
    isActive: boolean
    creationTime?: Date | string
    creatorId?: string | null
  }

  export type ipgsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    merchantId?: StringFieldUpdateOperationsInput | string
    terminalId?: StringFieldUpdateOperationsInput | string
    terminalKey?: StringFieldUpdateOperationsInput | string
    isActive?: BoolFieldUpdateOperationsInput | boolean
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ipgsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    merchantId?: StringFieldUpdateOperationsInput | string
    terminalId?: StringFieldUpdateOperationsInput | string
    terminalKey?: StringFieldUpdateOperationsInput | string
    isActive?: BoolFieldUpdateOperationsInput | boolean
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ipgsCreateManyInput = {
    id?: string
    provider?: string | null
    merchantId: string
    terminalId: string
    terminalKey: string
    isActive: boolean
    creationTime?: Date | string
    creatorId?: string | null
  }

  export type ipgsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    merchantId?: StringFieldUpdateOperationsInput | string
    terminalId?: StringFieldUpdateOperationsInput | string
    terminalKey?: StringFieldUpdateOperationsInput | string
    isActive?: BoolFieldUpdateOperationsInput | boolean
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ipgsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    merchantId?: StringFieldUpdateOperationsInput | string
    terminalId?: StringFieldUpdateOperationsInput | string
    terminalKey?: StringFieldUpdateOperationsInput | string
    isActive?: BoolFieldUpdateOperationsInput | boolean
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type reuqestcodesCreateInput = {
    id?: string
    mobileNumber: string
    code: string
    createDate?: Date | string
  }

  export type reuqestcodesUncheckedCreateInput = {
    id?: string
    mobileNumber: string
    code: string
    createDate?: Date | string
  }

  export type reuqestcodesUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    mobileNumber?: StringFieldUpdateOperationsInput | string
    code?: StringFieldUpdateOperationsInput | string
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type reuqestcodesUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    mobileNumber?: StringFieldUpdateOperationsInput | string
    code?: StringFieldUpdateOperationsInput | string
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type reuqestcodesCreateManyInput = {
    id?: string
    mobileNumber: string
    code: string
    createDate?: Date | string
  }

  export type reuqestcodesUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    mobileNumber?: StringFieldUpdateOperationsInput | string
    code?: StringFieldUpdateOperationsInput | string
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type reuqestcodesUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    mobileNumber?: StringFieldUpdateOperationsInput | string
    code?: StringFieldUpdateOperationsInput | string
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type baseDataCreateInput = {
    id?: string
    providerKey: string
    providerValue: string
    providerData?: string | null
    providerData_2?: string | null
    createDate?: Date | string
  }

  export type baseDataUncheckedCreateInput = {
    id?: string
    providerKey: string
    providerValue: string
    providerData?: string | null
    providerData_2?: string | null
    createDate?: Date | string
  }

  export type baseDataUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    providerKey?: StringFieldUpdateOperationsInput | string
    providerValue?: StringFieldUpdateOperationsInput | string
    providerData?: NullableStringFieldUpdateOperationsInput | string | null
    providerData_2?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type baseDataUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    providerKey?: StringFieldUpdateOperationsInput | string
    providerValue?: StringFieldUpdateOperationsInput | string
    providerData?: NullableStringFieldUpdateOperationsInput | string | null
    providerData_2?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type baseDataCreateManyInput = {
    id?: string
    providerKey: string
    providerValue: string
    providerData?: string | null
    providerData_2?: string | null
    createDate?: Date | string
  }

  export type baseDataUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    providerKey?: StringFieldUpdateOperationsInput | string
    providerValue?: StringFieldUpdateOperationsInput | string
    providerData?: NullableStringFieldUpdateOperationsInput | string | null
    providerData_2?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type baseDataUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    providerKey?: StringFieldUpdateOperationsInput | string
    providerValue?: StringFieldUpdateOperationsInput | string
    providerData?: NullableStringFieldUpdateOperationsInput | string | null
    providerData_2?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type membersCreateInput = {
    id?: string
    name?: string | null
    family?: string | null
    nationalCode?: string | null
    fatherName?: string | null
    disabilityStatus?: number | null
    disabilityDescription?: string | null
    partnerJob?: string | null
    educationLevel?: number | null
    maritalStatus?: number | null
    childrenCounts?: number | null
    birthDate?: string | null
    mobileNumber: string
    address?: string | null
    username?: string | null
    password?: string | null
    status?: number | null
    creationTime?: Date | string
    creatorId?: string | null
    isDeleted?: boolean
  }

  export type membersUncheckedCreateInput = {
    id?: string
    name?: string | null
    family?: string | null
    nationalCode?: string | null
    fatherName?: string | null
    disabilityStatus?: number | null
    disabilityDescription?: string | null
    partnerJob?: string | null
    educationLevel?: number | null
    maritalStatus?: number | null
    childrenCounts?: number | null
    birthDate?: string | null
    mobileNumber: string
    address?: string | null
    username?: string | null
    password?: string | null
    status?: number | null
    creationTime?: Date | string
    creatorId?: string | null
    isDeleted?: boolean
  }

  export type membersUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    family?: NullableStringFieldUpdateOperationsInput | string | null
    nationalCode?: NullableStringFieldUpdateOperationsInput | string | null
    fatherName?: NullableStringFieldUpdateOperationsInput | string | null
    disabilityStatus?: NullableIntFieldUpdateOperationsInput | number | null
    disabilityDescription?: NullableStringFieldUpdateOperationsInput | string | null
    partnerJob?: NullableStringFieldUpdateOperationsInput | string | null
    educationLevel?: NullableIntFieldUpdateOperationsInput | number | null
    maritalStatus?: NullableIntFieldUpdateOperationsInput | number | null
    childrenCounts?: NullableIntFieldUpdateOperationsInput | number | null
    birthDate?: NullableStringFieldUpdateOperationsInput | string | null
    mobileNumber?: StringFieldUpdateOperationsInput | string
    address?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    status?: NullableIntFieldUpdateOperationsInput | number | null
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
  }

  export type membersUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    family?: NullableStringFieldUpdateOperationsInput | string | null
    nationalCode?: NullableStringFieldUpdateOperationsInput | string | null
    fatherName?: NullableStringFieldUpdateOperationsInput | string | null
    disabilityStatus?: NullableIntFieldUpdateOperationsInput | number | null
    disabilityDescription?: NullableStringFieldUpdateOperationsInput | string | null
    partnerJob?: NullableStringFieldUpdateOperationsInput | string | null
    educationLevel?: NullableIntFieldUpdateOperationsInput | number | null
    maritalStatus?: NullableIntFieldUpdateOperationsInput | number | null
    childrenCounts?: NullableIntFieldUpdateOperationsInput | number | null
    birthDate?: NullableStringFieldUpdateOperationsInput | string | null
    mobileNumber?: StringFieldUpdateOperationsInput | string
    address?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    status?: NullableIntFieldUpdateOperationsInput | number | null
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
  }

  export type membersCreateManyInput = {
    id?: string
    name?: string | null
    family?: string | null
    nationalCode?: string | null
    fatherName?: string | null
    disabilityStatus?: number | null
    disabilityDescription?: string | null
    partnerJob?: string | null
    educationLevel?: number | null
    maritalStatus?: number | null
    childrenCounts?: number | null
    birthDate?: string | null
    mobileNumber: string
    address?: string | null
    username?: string | null
    password?: string | null
    status?: number | null
    creationTime?: Date | string
    creatorId?: string | null
    isDeleted?: boolean
  }

  export type membersUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    family?: NullableStringFieldUpdateOperationsInput | string | null
    nationalCode?: NullableStringFieldUpdateOperationsInput | string | null
    fatherName?: NullableStringFieldUpdateOperationsInput | string | null
    disabilityStatus?: NullableIntFieldUpdateOperationsInput | number | null
    disabilityDescription?: NullableStringFieldUpdateOperationsInput | string | null
    partnerJob?: NullableStringFieldUpdateOperationsInput | string | null
    educationLevel?: NullableIntFieldUpdateOperationsInput | number | null
    maritalStatus?: NullableIntFieldUpdateOperationsInput | number | null
    childrenCounts?: NullableIntFieldUpdateOperationsInput | number | null
    birthDate?: NullableStringFieldUpdateOperationsInput | string | null
    mobileNumber?: StringFieldUpdateOperationsInput | string
    address?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    status?: NullableIntFieldUpdateOperationsInput | number | null
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
  }

  export type membersUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    family?: NullableStringFieldUpdateOperationsInput | string | null
    nationalCode?: NullableStringFieldUpdateOperationsInput | string | null
    fatherName?: NullableStringFieldUpdateOperationsInput | string | null
    disabilityStatus?: NullableIntFieldUpdateOperationsInput | number | null
    disabilityDescription?: NullableStringFieldUpdateOperationsInput | string | null
    partnerJob?: NullableStringFieldUpdateOperationsInput | string | null
    educationLevel?: NullableIntFieldUpdateOperationsInput | number | null
    maritalStatus?: NullableIntFieldUpdateOperationsInput | number | null
    childrenCounts?: NullableIntFieldUpdateOperationsInput | number | null
    birthDate?: NullableStringFieldUpdateOperationsInput | string | null
    mobileNumber?: StringFieldUpdateOperationsInput | string
    address?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    status?: NullableIntFieldUpdateOperationsInput | number | null
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
  }

  export type members_product_itemsCreateInput = {
    id?: string
    parentMemberId: string
    title: string
    ownProduct: boolean
  }

  export type members_product_itemsUncheckedCreateInput = {
    id?: string
    parentMemberId: string
    title: string
    ownProduct: boolean
  }

  export type members_product_itemsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    parentMemberId?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    ownProduct?: BoolFieldUpdateOperationsInput | boolean
  }

  export type members_product_itemsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    parentMemberId?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    ownProduct?: BoolFieldUpdateOperationsInput | boolean
  }

  export type members_product_itemsCreateManyInput = {
    id?: string
    parentMemberId: string
    title: string
    ownProduct: boolean
  }

  export type members_product_itemsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    parentMemberId?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    ownProduct?: BoolFieldUpdateOperationsInput | boolean
  }

  export type members_product_itemsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    parentMemberId?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    ownProduct?: BoolFieldUpdateOperationsInput | boolean
  }

  export type imageSliderCreateInput = {
    id?: string
    fileId: string
    title: string
    creationTime?: Date | string
    creatorId?: string | null
  }

  export type imageSliderUncheckedCreateInput = {
    id?: string
    fileId: string
    title: string
    creationTime?: Date | string
    creatorId?: string | null
  }

  export type imageSliderUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    fileId?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type imageSliderUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    fileId?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type imageSliderCreateManyInput = {
    id?: string
    fileId: string
    title: string
    creationTime?: Date | string
    creatorId?: string | null
  }

  export type imageSliderUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    fileId?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type imageSliderUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    fileId?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type profileImageSliderCreateInput = {
    id?: string
    fileId: string
    targetUrl?: string | null
    creationTime?: Date | string
    creatorId?: string | null
  }

  export type profileImageSliderUncheckedCreateInput = {
    id?: string
    fileId: string
    targetUrl?: string | null
    creationTime?: Date | string
    creatorId?: string | null
  }

  export type profileImageSliderUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    fileId?: StringFieldUpdateOperationsInput | string
    targetUrl?: NullableStringFieldUpdateOperationsInput | string | null
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type profileImageSliderUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    fileId?: StringFieldUpdateOperationsInput | string
    targetUrl?: NullableStringFieldUpdateOperationsInput | string | null
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type profileImageSliderCreateManyInput = {
    id?: string
    fileId: string
    targetUrl?: string | null
    creationTime?: Date | string
    creatorId?: string | null
  }

  export type profileImageSliderUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    fileId?: StringFieldUpdateOperationsInput | string
    targetUrl?: NullableStringFieldUpdateOperationsInput | string | null
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type profileImageSliderUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    fileId?: StringFieldUpdateOperationsInput | string
    targetUrl?: NullableStringFieldUpdateOperationsInput | string | null
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type upload_document_templateCreateInput = {
    id?: string
    title: string
    maximumSizeInMb: number
    isRequired: boolean
    showWhen?: string | null
    creationTime?: Date | string
    creatorId?: string | null
  }

  export type upload_document_templateUncheckedCreateInput = {
    id?: string
    title: string
    maximumSizeInMb: number
    isRequired: boolean
    showWhen?: string | null
    creationTime?: Date | string
    creatorId?: string | null
  }

  export type upload_document_templateUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    maximumSizeInMb?: IntFieldUpdateOperationsInput | number
    isRequired?: BoolFieldUpdateOperationsInput | boolean
    showWhen?: NullableStringFieldUpdateOperationsInput | string | null
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type upload_document_templateUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    maximumSizeInMb?: IntFieldUpdateOperationsInput | number
    isRequired?: BoolFieldUpdateOperationsInput | boolean
    showWhen?: NullableStringFieldUpdateOperationsInput | string | null
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type upload_document_templateCreateManyInput = {
    id?: string
    title: string
    maximumSizeInMb: number
    isRequired: boolean
    showWhen?: string | null
    creationTime?: Date | string
    creatorId?: string | null
  }

  export type upload_document_templateUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    maximumSizeInMb?: IntFieldUpdateOperationsInput | number
    isRequired?: BoolFieldUpdateOperationsInput | boolean
    showWhen?: NullableStringFieldUpdateOperationsInput | string | null
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type upload_document_templateUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    maximumSizeInMb?: IntFieldUpdateOperationsInput | number
    isRequired?: BoolFieldUpdateOperationsInput | boolean
    showWhen?: NullableStringFieldUpdateOperationsInput | string | null
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type uploadedDocumentsCreateInput = {
    id?: string
    userId: string
    templateId: string
    filePath: string
    creationTime?: Date | string
  }

  export type uploadedDocumentsUncheckedCreateInput = {
    id?: string
    userId: string
    templateId: string
    filePath: string
    creationTime?: Date | string
  }

  export type uploadedDocumentsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    templateId?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type uploadedDocumentsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    templateId?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type uploadedDocumentsCreateManyInput = {
    id?: string
    userId: string
    templateId: string
    filePath: string
    creationTime?: Date | string
  }

  export type uploadedDocumentsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    templateId?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type uploadedDocumentsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    templateId?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type rejectionTemplatesCreateInput = {
    id?: string
    title: string
    creationTime?: Date | string
    creatorId?: string | null
  }

  export type rejectionTemplatesUncheckedCreateInput = {
    id?: string
    title: string
    creationTime?: Date | string
    creatorId?: string | null
  }

  export type rejectionTemplatesUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type rejectionTemplatesUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type rejectionTemplatesCreateManyInput = {
    id?: string
    title: string
    creationTime?: Date | string
    creatorId?: string | null
  }

  export type rejectionTemplatesUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type rejectionTemplatesUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type marketsCreateInput = {
    id?: string
    title: string
    activityStartDate: Date | string
    activityEndDate: Date | string
    amount: Decimal | DecimalJsLike | number | string
    location: string
  }

  export type marketsUncheckedCreateInput = {
    id?: string
    title: string
    activityStartDate: Date | string
    activityEndDate: Date | string
    amount: Decimal | DecimalJsLike | number | string
    location: string
  }

  export type marketsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    activityStartDate?: DateTimeFieldUpdateOperationsInput | Date | string
    activityEndDate?: DateTimeFieldUpdateOperationsInput | Date | string
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    location?: StringFieldUpdateOperationsInput | string
  }

  export type marketsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    activityStartDate?: DateTimeFieldUpdateOperationsInput | Date | string
    activityEndDate?: DateTimeFieldUpdateOperationsInput | Date | string
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    location?: StringFieldUpdateOperationsInput | string
  }

  export type marketsCreateManyInput = {
    id?: string
    title: string
    activityStartDate: Date | string
    activityEndDate: Date | string
    amount: Decimal | DecimalJsLike | number | string
    location: string
  }

  export type marketsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    activityStartDate?: DateTimeFieldUpdateOperationsInput | Date | string
    activityEndDate?: DateTimeFieldUpdateOperationsInput | Date | string
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    location?: StringFieldUpdateOperationsInput | string
  }

  export type marketsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    activityStartDate?: DateTimeFieldUpdateOperationsInput | Date | string
    activityEndDate?: DateTimeFieldUpdateOperationsInput | Date | string
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    location?: StringFieldUpdateOperationsInput | string
  }

  export type market_desksCreateInput = {
    id?: string
    number: number
    title: string
    amount: Decimal | DecimalJsLike | number | string
    parentMarketId: string
  }

  export type market_desksUncheckedCreateInput = {
    id?: string
    number: number
    title: string
    amount: Decimal | DecimalJsLike | number | string
    parentMarketId: string
  }

  export type market_desksUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    number?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    parentMarketId?: StringFieldUpdateOperationsInput | string
  }

  export type market_desksUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    number?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    parentMarketId?: StringFieldUpdateOperationsInput | string
  }

  export type market_desksCreateManyInput = {
    id?: string
    number: number
    title: string
    amount: Decimal | DecimalJsLike | number | string
    parentMarketId: string
  }

  export type market_desksUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    number?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    parentMarketId?: StringFieldUpdateOperationsInput | string
  }

  export type market_desksUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    number?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    parentMarketId?: StringFieldUpdateOperationsInput | string
  }

  export type reversed_marketsCreateInput = {
    id?: string
    marketId: string
    deskId: string
    userId: string
    isPurchased: boolean
  }

  export type reversed_marketsUncheckedCreateInput = {
    id?: string
    marketId: string
    deskId: string
    userId: string
    isPurchased: boolean
  }

  export type reversed_marketsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    marketId?: StringFieldUpdateOperationsInput | string
    deskId?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    isPurchased?: BoolFieldUpdateOperationsInput | boolean
  }

  export type reversed_marketsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    marketId?: StringFieldUpdateOperationsInput | string
    deskId?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    isPurchased?: BoolFieldUpdateOperationsInput | boolean
  }

  export type reversed_marketsCreateManyInput = {
    id?: string
    marketId: string
    deskId: string
    userId: string
    isPurchased: boolean
  }

  export type reversed_marketsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    marketId?: StringFieldUpdateOperationsInput | string
    deskId?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    isPurchased?: BoolFieldUpdateOperationsInput | boolean
  }

  export type reversed_marketsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    marketId?: StringFieldUpdateOperationsInput | string
    deskId?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    isPurchased?: BoolFieldUpdateOperationsInput | boolean
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type BoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type Access_permission_groupNullableRelationFilter = {
    is?: access_permission_groupWhereInput | null
    isNot?: access_permission_groupWhereInput | null
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type usersCountOrderByAggregateInput = {
    id?: SortOrder
    username?: SortOrder
    password?: SortOrder
    name?: SortOrder
    family?: SortOrder
    fatherName?: SortOrder
    creationTime?: SortOrder
    isDeleted?: SortOrder
    metaData?: SortOrder
    creatorId?: SortOrder
    accessPermissionGroupId?: SortOrder
  }

  export type usersMaxOrderByAggregateInput = {
    id?: SortOrder
    username?: SortOrder
    password?: SortOrder
    name?: SortOrder
    family?: SortOrder
    fatherName?: SortOrder
    creationTime?: SortOrder
    isDeleted?: SortOrder
    metaData?: SortOrder
    creatorId?: SortOrder
    accessPermissionGroupId?: SortOrder
  }

  export type usersMinOrderByAggregateInput = {
    id?: SortOrder
    username?: SortOrder
    password?: SortOrder
    name?: SortOrder
    family?: SortOrder
    fatherName?: SortOrder
    creationTime?: SortOrder
    isDeleted?: SortOrder
    metaData?: SortOrder
    creatorId?: SortOrder
    accessPermissionGroupId?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type BoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type UsersListRelationFilter = {
    every?: usersWhereInput
    some?: usersWhereInput
    none?: usersWhereInput
  }

  export type usersOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type access_permission_groupCountOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    name?: SortOrder
    isDeletable?: SortOrder
    createDate?: SortOrder
  }

  export type access_permission_groupMaxOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    name?: SortOrder
    isDeletable?: SortOrder
    createDate?: SortOrder
  }

  export type access_permission_groupMinOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    name?: SortOrder
    isDeletable?: SortOrder
    createDate?: SortOrder
  }

  export type access_permission_group_itemsCountOrderByAggregateInput = {
    id?: SortOrder
    userOrParentAccessPermissionId?: SortOrder
    providerKey?: SortOrder
    creatorId?: SortOrder
    createDate?: SortOrder
  }

  export type access_permission_group_itemsMaxOrderByAggregateInput = {
    id?: SortOrder
    userOrParentAccessPermissionId?: SortOrder
    providerKey?: SortOrder
    creatorId?: SortOrder
    createDate?: SortOrder
  }

  export type access_permission_group_itemsMinOrderByAggregateInput = {
    id?: SortOrder
    userOrParentAccessPermissionId?: SortOrder
    providerKey?: SortOrder
    creatorId?: SortOrder
    createDate?: SortOrder
  }

  export type settingsCountOrderByAggregateInput = {
    id?: SortOrder
    providerKey?: SortOrder
    providerValue?: SortOrder
    creatorId?: SortOrder
    createDate?: SortOrder
  }

  export type settingsMaxOrderByAggregateInput = {
    id?: SortOrder
    providerKey?: SortOrder
    providerValue?: SortOrder
    creatorId?: SortOrder
    createDate?: SortOrder
  }

  export type settingsMinOrderByAggregateInput = {
    id?: SortOrder
    providerKey?: SortOrder
    providerValue?: SortOrder
    creatorId?: SortOrder
    createDate?: SortOrder
  }

  export type ipgsCountOrderByAggregateInput = {
    id?: SortOrder
    provider?: SortOrder
    merchantId?: SortOrder
    terminalId?: SortOrder
    terminalKey?: SortOrder
    isActive?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrder
  }

  export type ipgsMaxOrderByAggregateInput = {
    id?: SortOrder
    provider?: SortOrder
    merchantId?: SortOrder
    terminalId?: SortOrder
    terminalKey?: SortOrder
    isActive?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrder
  }

  export type ipgsMinOrderByAggregateInput = {
    id?: SortOrder
    provider?: SortOrder
    merchantId?: SortOrder
    terminalId?: SortOrder
    terminalKey?: SortOrder
    isActive?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrder
  }

  export type reuqestcodesCountOrderByAggregateInput = {
    id?: SortOrder
    mobileNumber?: SortOrder
    code?: SortOrder
    createDate?: SortOrder
  }

  export type reuqestcodesMaxOrderByAggregateInput = {
    id?: SortOrder
    mobileNumber?: SortOrder
    code?: SortOrder
    createDate?: SortOrder
  }

  export type reuqestcodesMinOrderByAggregateInput = {
    id?: SortOrder
    mobileNumber?: SortOrder
    code?: SortOrder
    createDate?: SortOrder
  }

  export type baseDataCountOrderByAggregateInput = {
    id?: SortOrder
    providerKey?: SortOrder
    providerValue?: SortOrder
    providerData?: SortOrder
    providerData_2?: SortOrder
    createDate?: SortOrder
  }

  export type baseDataMaxOrderByAggregateInput = {
    id?: SortOrder
    providerKey?: SortOrder
    providerValue?: SortOrder
    providerData?: SortOrder
    providerData_2?: SortOrder
    createDate?: SortOrder
  }

  export type baseDataMinOrderByAggregateInput = {
    id?: SortOrder
    providerKey?: SortOrder
    providerValue?: SortOrder
    providerData?: SortOrder
    providerData_2?: SortOrder
    createDate?: SortOrder
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type membersCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    family?: SortOrder
    nationalCode?: SortOrder
    fatherName?: SortOrder
    disabilityStatus?: SortOrder
    disabilityDescription?: SortOrder
    partnerJob?: SortOrder
    educationLevel?: SortOrder
    maritalStatus?: SortOrder
    childrenCounts?: SortOrder
    birthDate?: SortOrder
    mobileNumber?: SortOrder
    address?: SortOrder
    username?: SortOrder
    password?: SortOrder
    status?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrder
    isDeleted?: SortOrder
  }

  export type membersAvgOrderByAggregateInput = {
    disabilityStatus?: SortOrder
    educationLevel?: SortOrder
    maritalStatus?: SortOrder
    childrenCounts?: SortOrder
    status?: SortOrder
  }

  export type membersMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    family?: SortOrder
    nationalCode?: SortOrder
    fatherName?: SortOrder
    disabilityStatus?: SortOrder
    disabilityDescription?: SortOrder
    partnerJob?: SortOrder
    educationLevel?: SortOrder
    maritalStatus?: SortOrder
    childrenCounts?: SortOrder
    birthDate?: SortOrder
    mobileNumber?: SortOrder
    address?: SortOrder
    username?: SortOrder
    password?: SortOrder
    status?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrder
    isDeleted?: SortOrder
  }

  export type membersMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    family?: SortOrder
    nationalCode?: SortOrder
    fatherName?: SortOrder
    disabilityStatus?: SortOrder
    disabilityDescription?: SortOrder
    partnerJob?: SortOrder
    educationLevel?: SortOrder
    maritalStatus?: SortOrder
    childrenCounts?: SortOrder
    birthDate?: SortOrder
    mobileNumber?: SortOrder
    address?: SortOrder
    username?: SortOrder
    password?: SortOrder
    status?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrder
    isDeleted?: SortOrder
  }

  export type membersSumOrderByAggregateInput = {
    disabilityStatus?: SortOrder
    educationLevel?: SortOrder
    maritalStatus?: SortOrder
    childrenCounts?: SortOrder
    status?: SortOrder
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type members_product_itemsCountOrderByAggregateInput = {
    id?: SortOrder
    parentMemberId?: SortOrder
    title?: SortOrder
    ownProduct?: SortOrder
  }

  export type members_product_itemsMaxOrderByAggregateInput = {
    id?: SortOrder
    parentMemberId?: SortOrder
    title?: SortOrder
    ownProduct?: SortOrder
  }

  export type members_product_itemsMinOrderByAggregateInput = {
    id?: SortOrder
    parentMemberId?: SortOrder
    title?: SortOrder
    ownProduct?: SortOrder
  }

  export type imageSliderCountOrderByAggregateInput = {
    id?: SortOrder
    fileId?: SortOrder
    title?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrder
  }

  export type imageSliderMaxOrderByAggregateInput = {
    id?: SortOrder
    fileId?: SortOrder
    title?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrder
  }

  export type imageSliderMinOrderByAggregateInput = {
    id?: SortOrder
    fileId?: SortOrder
    title?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrder
  }

  export type profileImageSliderCountOrderByAggregateInput = {
    id?: SortOrder
    fileId?: SortOrder
    targetUrl?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrder
  }

  export type profileImageSliderMaxOrderByAggregateInput = {
    id?: SortOrder
    fileId?: SortOrder
    targetUrl?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrder
  }

  export type profileImageSliderMinOrderByAggregateInput = {
    id?: SortOrder
    fileId?: SortOrder
    targetUrl?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrder
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type upload_document_templateCountOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    maximumSizeInMb?: SortOrder
    isRequired?: SortOrder
    showWhen?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrder
  }

  export type upload_document_templateAvgOrderByAggregateInput = {
    maximumSizeInMb?: SortOrder
  }

  export type upload_document_templateMaxOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    maximumSizeInMb?: SortOrder
    isRequired?: SortOrder
    showWhen?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrder
  }

  export type upload_document_templateMinOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    maximumSizeInMb?: SortOrder
    isRequired?: SortOrder
    showWhen?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrder
  }

  export type upload_document_templateSumOrderByAggregateInput = {
    maximumSizeInMb?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type uploadedDocumentsCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    templateId?: SortOrder
    filePath?: SortOrder
    creationTime?: SortOrder
  }

  export type uploadedDocumentsMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    templateId?: SortOrder
    filePath?: SortOrder
    creationTime?: SortOrder
  }

  export type uploadedDocumentsMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    templateId?: SortOrder
    filePath?: SortOrder
    creationTime?: SortOrder
  }

  export type rejectionTemplatesCountOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrder
  }

  export type rejectionTemplatesMaxOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrder
  }

  export type rejectionTemplatesMinOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    creationTime?: SortOrder
    creatorId?: SortOrder
  }

  export type DecimalFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[]
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[]
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
  }

  export type marketsCountOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    activityStartDate?: SortOrder
    activityEndDate?: SortOrder
    amount?: SortOrder
    location?: SortOrder
  }

  export type marketsAvgOrderByAggregateInput = {
    amount?: SortOrder
  }

  export type marketsMaxOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    activityStartDate?: SortOrder
    activityEndDate?: SortOrder
    amount?: SortOrder
    location?: SortOrder
  }

  export type marketsMinOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    activityStartDate?: SortOrder
    activityEndDate?: SortOrder
    amount?: SortOrder
    location?: SortOrder
  }

  export type marketsSumOrderByAggregateInput = {
    amount?: SortOrder
  }

  export type DecimalWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[]
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[]
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalWithAggregatesFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedDecimalFilter<$PrismaModel>
    _sum?: NestedDecimalFilter<$PrismaModel>
    _min?: NestedDecimalFilter<$PrismaModel>
    _max?: NestedDecimalFilter<$PrismaModel>
  }

  export type market_desksCountOrderByAggregateInput = {
    id?: SortOrder
    number?: SortOrder
    title?: SortOrder
    amount?: SortOrder
    parentMarketId?: SortOrder
  }

  export type market_desksAvgOrderByAggregateInput = {
    number?: SortOrder
    amount?: SortOrder
  }

  export type market_desksMaxOrderByAggregateInput = {
    id?: SortOrder
    number?: SortOrder
    title?: SortOrder
    amount?: SortOrder
    parentMarketId?: SortOrder
  }

  export type market_desksMinOrderByAggregateInput = {
    id?: SortOrder
    number?: SortOrder
    title?: SortOrder
    amount?: SortOrder
    parentMarketId?: SortOrder
  }

  export type market_desksSumOrderByAggregateInput = {
    number?: SortOrder
    amount?: SortOrder
  }

  export type reversed_marketsCountOrderByAggregateInput = {
    id?: SortOrder
    marketId?: SortOrder
    deskId?: SortOrder
    userId?: SortOrder
    isPurchased?: SortOrder
  }

  export type reversed_marketsMaxOrderByAggregateInput = {
    id?: SortOrder
    marketId?: SortOrder
    deskId?: SortOrder
    userId?: SortOrder
    isPurchased?: SortOrder
  }

  export type reversed_marketsMinOrderByAggregateInput = {
    id?: SortOrder
    marketId?: SortOrder
    deskId?: SortOrder
    userId?: SortOrder
    isPurchased?: SortOrder
  }

  export type access_permission_groupCreateNestedOneWithoutUsersInput = {
    create?: XOR<access_permission_groupCreateWithoutUsersInput, access_permission_groupUncheckedCreateWithoutUsersInput>
    connectOrCreate?: access_permission_groupCreateOrConnectWithoutUsersInput
    connect?: access_permission_groupWhereUniqueInput
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type BoolFieldUpdateOperationsInput = {
    set?: boolean
  }

  export type access_permission_groupUpdateOneWithoutUsersNestedInput = {
    create?: XOR<access_permission_groupCreateWithoutUsersInput, access_permission_groupUncheckedCreateWithoutUsersInput>
    connectOrCreate?: access_permission_groupCreateOrConnectWithoutUsersInput
    upsert?: access_permission_groupUpsertWithoutUsersInput
    disconnect?: access_permission_groupWhereInput | boolean
    delete?: access_permission_groupWhereInput | boolean
    connect?: access_permission_groupWhereUniqueInput
    update?: XOR<XOR<access_permission_groupUpdateToOneWithWhereWithoutUsersInput, access_permission_groupUpdateWithoutUsersInput>, access_permission_groupUncheckedUpdateWithoutUsersInput>
  }

  export type usersCreateNestedManyWithoutPermissionGroupIdInput = {
    create?: XOR<usersCreateWithoutPermissionGroupIdInput, usersUncheckedCreateWithoutPermissionGroupIdInput> | usersCreateWithoutPermissionGroupIdInput[] | usersUncheckedCreateWithoutPermissionGroupIdInput[]
    connectOrCreate?: usersCreateOrConnectWithoutPermissionGroupIdInput | usersCreateOrConnectWithoutPermissionGroupIdInput[]
    createMany?: usersCreateManyPermissionGroupIdInputEnvelope
    connect?: usersWhereUniqueInput | usersWhereUniqueInput[]
  }

  export type usersUncheckedCreateNestedManyWithoutPermissionGroupIdInput = {
    create?: XOR<usersCreateWithoutPermissionGroupIdInput, usersUncheckedCreateWithoutPermissionGroupIdInput> | usersCreateWithoutPermissionGroupIdInput[] | usersUncheckedCreateWithoutPermissionGroupIdInput[]
    connectOrCreate?: usersCreateOrConnectWithoutPermissionGroupIdInput | usersCreateOrConnectWithoutPermissionGroupIdInput[]
    createMany?: usersCreateManyPermissionGroupIdInputEnvelope
    connect?: usersWhereUniqueInput | usersWhereUniqueInput[]
  }

  export type usersUpdateManyWithoutPermissionGroupIdNestedInput = {
    create?: XOR<usersCreateWithoutPermissionGroupIdInput, usersUncheckedCreateWithoutPermissionGroupIdInput> | usersCreateWithoutPermissionGroupIdInput[] | usersUncheckedCreateWithoutPermissionGroupIdInput[]
    connectOrCreate?: usersCreateOrConnectWithoutPermissionGroupIdInput | usersCreateOrConnectWithoutPermissionGroupIdInput[]
    upsert?: usersUpsertWithWhereUniqueWithoutPermissionGroupIdInput | usersUpsertWithWhereUniqueWithoutPermissionGroupIdInput[]
    createMany?: usersCreateManyPermissionGroupIdInputEnvelope
    set?: usersWhereUniqueInput | usersWhereUniqueInput[]
    disconnect?: usersWhereUniqueInput | usersWhereUniqueInput[]
    delete?: usersWhereUniqueInput | usersWhereUniqueInput[]
    connect?: usersWhereUniqueInput | usersWhereUniqueInput[]
    update?: usersUpdateWithWhereUniqueWithoutPermissionGroupIdInput | usersUpdateWithWhereUniqueWithoutPermissionGroupIdInput[]
    updateMany?: usersUpdateManyWithWhereWithoutPermissionGroupIdInput | usersUpdateManyWithWhereWithoutPermissionGroupIdInput[]
    deleteMany?: usersScalarWhereInput | usersScalarWhereInput[]
  }

  export type usersUncheckedUpdateManyWithoutPermissionGroupIdNestedInput = {
    create?: XOR<usersCreateWithoutPermissionGroupIdInput, usersUncheckedCreateWithoutPermissionGroupIdInput> | usersCreateWithoutPermissionGroupIdInput[] | usersUncheckedCreateWithoutPermissionGroupIdInput[]
    connectOrCreate?: usersCreateOrConnectWithoutPermissionGroupIdInput | usersCreateOrConnectWithoutPermissionGroupIdInput[]
    upsert?: usersUpsertWithWhereUniqueWithoutPermissionGroupIdInput | usersUpsertWithWhereUniqueWithoutPermissionGroupIdInput[]
    createMany?: usersCreateManyPermissionGroupIdInputEnvelope
    set?: usersWhereUniqueInput | usersWhereUniqueInput[]
    disconnect?: usersWhereUniqueInput | usersWhereUniqueInput[]
    delete?: usersWhereUniqueInput | usersWhereUniqueInput[]
    connect?: usersWhereUniqueInput | usersWhereUniqueInput[]
    update?: usersUpdateWithWhereUniqueWithoutPermissionGroupIdInput | usersUpdateWithWhereUniqueWithoutPermissionGroupIdInput[]
    updateMany?: usersUpdateManyWithWhereWithoutPermissionGroupIdInput | usersUpdateManyWithWhereWithoutPermissionGroupIdInput[]
    deleteMany?: usersScalarWhereInput | usersScalarWhereInput[]
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type DecimalFieldUpdateOperationsInput = {
    set?: Decimal | DecimalJsLike | number | string
    increment?: Decimal | DecimalJsLike | number | string
    decrement?: Decimal | DecimalJsLike | number | string
    multiply?: Decimal | DecimalJsLike | number | string
    divide?: Decimal | DecimalJsLike | number | string
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedBoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedBoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedDecimalFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[]
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[]
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
  }

  export type NestedDecimalWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[]
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[]
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalWithAggregatesFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedDecimalFilter<$PrismaModel>
    _sum?: NestedDecimalFilter<$PrismaModel>
    _min?: NestedDecimalFilter<$PrismaModel>
    _max?: NestedDecimalFilter<$PrismaModel>
  }

  export type access_permission_groupCreateWithoutUsersInput = {
    id?: string
    title?: string | null
    name: string
    isDeletable: boolean
    createDate?: Date | string
  }

  export type access_permission_groupUncheckedCreateWithoutUsersInput = {
    id?: string
    title?: string | null
    name: string
    isDeletable: boolean
    createDate?: Date | string
  }

  export type access_permission_groupCreateOrConnectWithoutUsersInput = {
    where: access_permission_groupWhereUniqueInput
    create: XOR<access_permission_groupCreateWithoutUsersInput, access_permission_groupUncheckedCreateWithoutUsersInput>
  }

  export type access_permission_groupUpsertWithoutUsersInput = {
    update: XOR<access_permission_groupUpdateWithoutUsersInput, access_permission_groupUncheckedUpdateWithoutUsersInput>
    create: XOR<access_permission_groupCreateWithoutUsersInput, access_permission_groupUncheckedCreateWithoutUsersInput>
    where?: access_permission_groupWhereInput
  }

  export type access_permission_groupUpdateToOneWithWhereWithoutUsersInput = {
    where?: access_permission_groupWhereInput
    data: XOR<access_permission_groupUpdateWithoutUsersInput, access_permission_groupUncheckedUpdateWithoutUsersInput>
  }

  export type access_permission_groupUpdateWithoutUsersInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: NullableStringFieldUpdateOperationsInput | string | null
    name?: StringFieldUpdateOperationsInput | string
    isDeletable?: BoolFieldUpdateOperationsInput | boolean
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type access_permission_groupUncheckedUpdateWithoutUsersInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: NullableStringFieldUpdateOperationsInput | string | null
    name?: StringFieldUpdateOperationsInput | string
    isDeletable?: BoolFieldUpdateOperationsInput | boolean
    createDate?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type usersCreateWithoutPermissionGroupIdInput = {
    id?: string
    username?: string | null
    password?: string | null
    name?: string | null
    family?: string | null
    fatherName?: string | null
    creationTime?: Date | string
    isDeleted?: boolean
    metaData?: string | null
    creatorId?: string | null
  }

  export type usersUncheckedCreateWithoutPermissionGroupIdInput = {
    id?: string
    username?: string | null
    password?: string | null
    name?: string | null
    family?: string | null
    fatherName?: string | null
    creationTime?: Date | string
    isDeleted?: boolean
    metaData?: string | null
    creatorId?: string | null
  }

  export type usersCreateOrConnectWithoutPermissionGroupIdInput = {
    where: usersWhereUniqueInput
    create: XOR<usersCreateWithoutPermissionGroupIdInput, usersUncheckedCreateWithoutPermissionGroupIdInput>
  }

  export type usersCreateManyPermissionGroupIdInputEnvelope = {
    data: usersCreateManyPermissionGroupIdInput | usersCreateManyPermissionGroupIdInput[]
    skipDuplicates?: boolean
  }

  export type usersUpsertWithWhereUniqueWithoutPermissionGroupIdInput = {
    where: usersWhereUniqueInput
    update: XOR<usersUpdateWithoutPermissionGroupIdInput, usersUncheckedUpdateWithoutPermissionGroupIdInput>
    create: XOR<usersCreateWithoutPermissionGroupIdInput, usersUncheckedCreateWithoutPermissionGroupIdInput>
  }

  export type usersUpdateWithWhereUniqueWithoutPermissionGroupIdInput = {
    where: usersWhereUniqueInput
    data: XOR<usersUpdateWithoutPermissionGroupIdInput, usersUncheckedUpdateWithoutPermissionGroupIdInput>
  }

  export type usersUpdateManyWithWhereWithoutPermissionGroupIdInput = {
    where: usersScalarWhereInput
    data: XOR<usersUpdateManyMutationInput, usersUncheckedUpdateManyWithoutPermissionGroupIdInput>
  }

  export type usersScalarWhereInput = {
    AND?: usersScalarWhereInput | usersScalarWhereInput[]
    OR?: usersScalarWhereInput[]
    NOT?: usersScalarWhereInput | usersScalarWhereInput[]
    id?: StringFilter<"users"> | string
    username?: StringNullableFilter<"users"> | string | null
    password?: StringNullableFilter<"users"> | string | null
    name?: StringNullableFilter<"users"> | string | null
    family?: StringNullableFilter<"users"> | string | null
    fatherName?: StringNullableFilter<"users"> | string | null
    creationTime?: DateTimeFilter<"users"> | Date | string
    isDeleted?: BoolFilter<"users"> | boolean
    metaData?: StringNullableFilter<"users"> | string | null
    creatorId?: StringNullableFilter<"users"> | string | null
    accessPermissionGroupId?: StringFilter<"users"> | string
  }

  export type usersCreateManyPermissionGroupIdInput = {
    id?: string
    username?: string | null
    password?: string | null
    name?: string | null
    family?: string | null
    fatherName?: string | null
    creationTime?: Date | string
    isDeleted?: boolean
    metaData?: string | null
    creatorId?: string | null
  }

  export type usersUpdateWithoutPermissionGroupIdInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    family?: NullableStringFieldUpdateOperationsInput | string | null
    fatherName?: NullableStringFieldUpdateOperationsInput | string | null
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    metaData?: NullableStringFieldUpdateOperationsInput | string | null
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type usersUncheckedUpdateWithoutPermissionGroupIdInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    family?: NullableStringFieldUpdateOperationsInput | string | null
    fatherName?: NullableStringFieldUpdateOperationsInput | string | null
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    metaData?: NullableStringFieldUpdateOperationsInput | string | null
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type usersUncheckedUpdateManyWithoutPermissionGroupIdInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    family?: NullableStringFieldUpdateOperationsInput | string | null
    fatherName?: NullableStringFieldUpdateOperationsInput | string | null
    creationTime?: DateTimeFieldUpdateOperationsInput | Date | string
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    metaData?: NullableStringFieldUpdateOperationsInput | string | null
    creatorId?: NullableStringFieldUpdateOperationsInput | string | null
  }



  /**
   * Aliases for legacy arg types
   */
    /**
     * @deprecated Use Access_permission_groupCountOutputTypeDefaultArgs instead
     */
    export type Access_permission_groupCountOutputTypeArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = Access_permission_groupCountOutputTypeDefaultArgs<ExtArgs>
    /**
     * @deprecated Use usersDefaultArgs instead
     */
    export type usersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = usersDefaultArgs<ExtArgs>
    /**
     * @deprecated Use access_permission_groupDefaultArgs instead
     */
    export type access_permission_groupArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = access_permission_groupDefaultArgs<ExtArgs>
    /**
     * @deprecated Use access_permission_group_itemsDefaultArgs instead
     */
    export type access_permission_group_itemsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = access_permission_group_itemsDefaultArgs<ExtArgs>
    /**
     * @deprecated Use settingsDefaultArgs instead
     */
    export type settingsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = settingsDefaultArgs<ExtArgs>
    /**
     * @deprecated Use ipgsDefaultArgs instead
     */
    export type ipgsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = ipgsDefaultArgs<ExtArgs>
    /**
     * @deprecated Use reuqestcodesDefaultArgs instead
     */
    export type reuqestcodesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = reuqestcodesDefaultArgs<ExtArgs>
    /**
     * @deprecated Use baseDataDefaultArgs instead
     */
    export type baseDataArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = baseDataDefaultArgs<ExtArgs>
    /**
     * @deprecated Use membersDefaultArgs instead
     */
    export type membersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = membersDefaultArgs<ExtArgs>
    /**
     * @deprecated Use members_product_itemsDefaultArgs instead
     */
    export type members_product_itemsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = members_product_itemsDefaultArgs<ExtArgs>
    /**
     * @deprecated Use imageSliderDefaultArgs instead
     */
    export type imageSliderArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = imageSliderDefaultArgs<ExtArgs>
    /**
     * @deprecated Use profileImageSliderDefaultArgs instead
     */
    export type profileImageSliderArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = profileImageSliderDefaultArgs<ExtArgs>
    /**
     * @deprecated Use upload_document_templateDefaultArgs instead
     */
    export type upload_document_templateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = upload_document_templateDefaultArgs<ExtArgs>
    /**
     * @deprecated Use uploadedDocumentsDefaultArgs instead
     */
    export type uploadedDocumentsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = uploadedDocumentsDefaultArgs<ExtArgs>
    /**
     * @deprecated Use rejectionTemplatesDefaultArgs instead
     */
    export type rejectionTemplatesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = rejectionTemplatesDefaultArgs<ExtArgs>
    /**
     * @deprecated Use marketsDefaultArgs instead
     */
    export type marketsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = marketsDefaultArgs<ExtArgs>
    /**
     * @deprecated Use market_desksDefaultArgs instead
     */
    export type market_desksArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = market_desksDefaultArgs<ExtArgs>
    /**
     * @deprecated Use reversed_marketsDefaultArgs instead
     */
    export type reversed_marketsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = reversed_marketsDefaultArgs<ExtArgs>

  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}