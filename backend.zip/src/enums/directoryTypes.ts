export enum DirectoryTypes{
    ProjectAttachments= 'project-attachments'
}