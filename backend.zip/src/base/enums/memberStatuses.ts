export enum MemberStatuses{
  WaitingForAccept = 1,
  Accepted = 2,
}