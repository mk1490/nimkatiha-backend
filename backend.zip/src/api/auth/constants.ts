﻿export const jwtConstants = {
    privateKey: 'M@tink14901490'
}